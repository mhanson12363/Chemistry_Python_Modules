import numpy as np
import matplotlib
import matplotlib.pyplot as plt
from matplotlib.widgets import TextBox, Button

#constants
R = 8.314 #J/(mol*K)

#initial values
a = 1
b = 1
c = 1
d = 1
Ai = 1
Bi = 1
Ci = 1
Di = 1
Keq = 1
T = 298.15 #K
step = 0.001

x_axis_mode = 'A'

def rxn_calcs(a, b, c, d, Ai, Bi, Ci, Di, Keq, T, step):
    try:
        if Bi/b >= Ai/a: # A is L.R. 
            N = int((Ai+min(a/c*Ci,a/d*Di)-2*step)/step)+1
            if N <= 1:
                raise ValueError
            As = np.linspace(step, Ai+min(a/c*Ci,a/d*Di)-step, N)
            Bs = np.zeros(N)
            Cs = np.zeros(N)
            Ds = np.zeros(N) #empty but right shape
            for i in range(N):
                Bs[i] = Bi-b/a*(Ai-As[i]) #reaction stoichiometry; if A is consumed then B is consumed
                Cs[i] = Ci+c/a*(Ai-As[i]) #reaction stoichiometry; if A is consumed then C is produced
                Ds[i] = Di+d/a*(Ai-As[i]) #reaction stoichiometry; if A is consumed then D is produced
        if Ai/a > Bi/b: # B is L.R. 
            N = int((Bi+min(b/c*Ci, b/d*Di)-2*step)/step)+1
            if N <= 1:
                raise ValueError
            Bs = np.linspace(step, Bi+min(b/c*Ci,b/d*Di)-step, N)
            As = np.zeros(N)
            Cs = np.zeros(N)
            Ds = np.zeros(N) #empty but right shape
            for i in range(N):
                As[i] = Ai-a/b*(Bi-Bs[i]) #reaction stoichiometry; if B is consumed then A is consumed
                Cs[i] = Ci+c/b*(Bi-Bs[i]) #reaction stoichiometry; if A is consumed then C is produced
                Ds[i] = Di+d/b*(Bi-Bs[i]) #reaction stoichiometry; if A is consumed then C is produced
        Qs = np.zeros(N)
        dGs = np.zeros(N)
        Gs = np.zeros(N)
        for i in range(N):
            Qs[i] = ((Cs[i]**c)*(Ds[i]**d))/((As[i]**a)*(Bs[i]**b)) #regular equilibrium constant expression
        for i in range(N):
            dGs[i] = 8.314*T/1000*np.log(Qs[i]/Keq) #written in kJ/mol
        if (min(dGs) > 0 and max(dGs) > 0) or (min(dGs) < 0 and max(dGs) < 0):
            raise ValueError
        min_index = np.argmin(np.abs(dGs)) #finds closest value to Delta G=0
        for i in range(N-min_index-1):
            Gs[min_index+i+1] = Gs[min_index+i] - step*dGs[min_index+i+1] #estimates points after equilibrium
        for i in range(min_index):
            Gs[min_index-i-1] = Gs[min_index-i] + step*dGs[min_index-i-1] #estimates points before equilibrium
        return As, Bs, Cs, Ds, Qs, dGs, Gs
    except ValueError:
        print('Error encountered in calculation. Please ensure the concentrations give enough points for the calcualtion')
        print('and that the step size is small enough for the concentrations used.' + '\n')

def plot_all(ax1, ax2, ax3):
    try:
        global As, Bs, Cs, Ds, Qs, dGs, Gs
        As, Bs, Cs, Ds, Qs, dGs, Gs = rxn_calcs(a, b, c, d, Ai, Bi, Ci, Di, Keq, T, step)
        for ax in [ax1, ax2, ax3]:
           ax.clear()
        if x_axis_mode == 'A':
            x_vals = As
            x_label = r'[A] (M)'
        elif x_axis_mode == 'B':
            x_vals = Bs
            x_label = r'[B] (M)'
        elif x_axis_mode == 'C':
            x_vals = Cs
            x_label = r'[C] (M)'
        elif x_axis_mode == 'D':
            x_vals = Ds 
            x_label = r'[D] (M)'

        ax1.plot([0, max(x_vals)], [Keq, Keq], color = 'b', linewidth = 2, linestyle = '--', label = '$K_{eq}$')
        ax1.plot(x_vals, Qs, color = 'darkorange', linewidth = 2, label = 'Q')
        ax1.set_xlabel(x_label)
        ax1.set_ylabel(r'$Q$')
        ax1.set(xlim = [min(x_vals), max(x_vals)], ylim = [0.1*Keq, 5*Keq])
        ax1.tick_params(labelsize=16)
        ax1.legend()
        ax1.grid()

        ax2.plot([0,max(x_vals)],[0,0], color='b', linewidth = 2, linestyle='--', label=r'$\Delta G_{rxn} = 0$')
        ax2.plot(x_vals, dGs, color = 'darkorange', linewidth = 2, label = r'$\Delta G_{rxn}$')
        ax2.set_xlabel(x_label)
        ax2.set_ylabel(r'$\Delta G_{rxn}$ (kJ/mol)')
        ax2.set(xlim = [min(x_vals),max(x_vals)], ylim = [1.05*min(dGs),1.05*max(dGs)] )
        ax2.tick_params(labelsize=16)
        ax2.legend()
        ax2.grid()

        ax3.plot([0,max(x_vals)],[0,0],color='b', linewidth = 2, linestyle='--', label='Relative $G = 0$')
        ax3.plot(x_vals, Gs, color='darkorange', linewidth = 2, label = 'Relative $G$')
        ax3.set_xlabel(x_label)
        ax3.set_ylabel(r'Relative $G$ (kJ/mol)')
        ax3.set(xlim = [min(x_vals),max(x_vals)], ylim = [-0.05*max(Gs),1.05*max(Gs)] )
        ax3.tick_params(labelsize=16)
        ax3.legend()
        ax3.grid()

        plt.draw()
    except:
        print('Error updating plots; nothing has been changed.' + '\n') 

def submit(text):
    global Keq, T, a, b, c, d, Ai, Bi, Ci, Di, step
    try:
        Keq = float(text_box_Keq.text)
        T = float(text_box_T.text)
        a = float(text_box_a.text)
        Ai = float(text_box_Ai.text)
        b = float(text_box_b.text)
        Bi = float(text_box_Bi.text)
        c = float(text_box_c.text)
        Ci = float(text_box_Ci.text)
        d = float(text_box_d.text)
        Di = float(text_box_Di.text)
        step = float(text_box_step.text)
        if Keq <= 0 or T <= 0 or a <= 0 or b <= 0 or c <= 0 or d <= 0 or Ai < 0 or Bi < 0 or Ci < 0 or Di < 0 or step <= 0:
            raise ValueError
        if Ai == 0 and Bi == 0 and Ci == 0 and Di == 0:
            raise ValueError
        plot_all(ax1, ax2, ax3)
    except:
        print('The values of a, b, c, d, the initial concentrations, the equilibrium constant, and the temperature must be positive.')
        print('At most one concentration can be 0 for the reactants and products simultaneously.')

def button(event):
    global x_axis_mode
    counter = 0
    if x_axis_mode == 'D' and counter == 0:
        x_axis_mode = 'A'
        counter += 1
    if x_axis_mode == 'C' and counter == 0:
        x_axis_mode = 'D'
        counter += 1
    if x_axis_mode == 'B' and counter == 0:
        x_axis_mode = 'C'
        counter += 1
    if x_axis_mode == 'A' and counter == 0:
        x_axis_mode = 'B'
        counter += 1
    plot_all(ax1, ax2, ax3)

fig, (ax1, ax2, ax3) = plt.subplots(1,3, figsize = (15,6))
fig.subplots_adjust(bottom=0.3, wspace = 0.5)
plot_all(ax1, ax2, ax3)

xstart = 0.075 # used for making the box positions more easily
xstep = 0.15

#Keq textbox
axbox = plt.axes([xstart,0.025,0.05,0.06])
text_box_Keq = TextBox(axbox, r'$K_{eq}$', initial = str(Keq), label_pad = 0.05)

#T textbox
axbox_T = plt.axes([xstart, 0.125, 0.05, 0.06])
text_box_T = TextBox(axbox_T, r'$T$(K)', initial=str(T), label_pad = 0.05)

#a textbox
axbox_a = plt.axes([xstart+xstep, 0.125, 0.05, 0.06])
text_box_a = TextBox(axbox_a, r'$a$', initial = str(a), label_pad = 0.05)

#Ai textbox
axbox_Ai = plt.axes([xstart+xstep, 0.025, 0.05, 0.06])
text_box_Ai = TextBox(axbox_Ai, r'$[A]_i$', initial = str(Ai), label_pad = 0.05)

#b textbox
axbox_b = plt.axes([xstart+2*xstep, 0.125, 0.05, 0.06])
text_box_b = TextBox(axbox_b, r'$b$', initial = str(b), label_pad = 0.05)

#Bi textbox
axbox_Bi = plt.axes([xstart+2*xstep, 0.025, 0.05, 0.06])
text_box_Bi = TextBox(axbox_Bi, r'$[B]_i$', initial = str(Bi), label_pad = 0.05)

#c textbox
axbox_c = plt.axes([xstart+3*xstep, 0.125, 0.05, 0.06])
text_box_c = TextBox(axbox_c, r'$c$', initial = str(c), label_pad = 0.05)

#Ci textbox
axbox_Ci = plt.axes([xstart+3*xstep, 0.025, 0.05, 0.06])
text_box_Ci = TextBox(axbox_Ci, r'$[C]_i$', initial = str(Ci), label_pad = 0.05)

#d textbox
axbox_d = plt.axes([xstart+4*xstep, 0.125, 0.05, 0.06])
text_box_d = TextBox(axbox_d, r'$d$', initial = str(d), label_pad = 0.05)

#Di textbox
axbox_Di = plt.axes([xstart+4*xstep, 0.025, 0.05, 0.06])
text_box_Di = TextBox(axbox_Di, r'$[D]_i$', initial = str(Di), label_pad = 0.05)

#Conc step textbox
axbox_step = plt.axes([xstart+5.5*xstep, 0.125, 0.05, 0.06])
text_box_step = TextBox(axbox_step, r'Concentration step (M)', initial = str(step), label_pad = 0.05)

#button
ax_button = plt.axes([xstart+5*xstep, 0.025, 0.1, 0.05])
btn = Button(ax_button, 'Cycle x-axis', color = 'whitesmoke', hovercolor = 'lightgrey')

# text
ax_text = fig.add_axes([0.435, 0.92, 0.15, 0.05])
ax_text.axis('off')
ax_text.text(0, 0.0, r"$a$A + $b$B $\longrightarrow c$C + $d$D", fontsize = 16)

text_box_Keq.on_submit(submit)
text_box_T.on_submit(submit)
text_box_a.on_submit(submit)
text_box_b.on_submit(submit)
text_box_c.on_submit(submit)
text_box_d.on_submit(submit)
text_box_Ai.on_submit(submit)
text_box_Bi.on_submit(submit)
text_box_Ci.on_submit(submit)
text_box_Di.on_submit(submit)
text_box_step.on_submit(submit)
btn.on_clicked(button)

plt.show()
