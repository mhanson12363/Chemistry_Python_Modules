import numpy as np
import matplotlib.pyplot as plt
from matplotlib import cm
from matplotlib.widgets import Slider, Button, TextBox
from mpl_toolkits.mplot3d import Axes3D

# Constants
R = 0.08206 #(L*atm)/(K*mol)
n = 1.0 # mol

def update(event):
    try:
        n = float(txtBox.text)
        if n <= 0:
            raise ValueError
        ax.clear()
        P_grid = n*R*T_grid/V_grid # atm 
        surf = ax.plot_surface(V_grid, T_grid, P_grid, cmap = 'viridis', edgecolor = 'k', lw=0.01, alpha = 1, shade = True, antialiased=True)
        surf.set_clim(vmin=P_grid.min(), vmax=P_grid.max())
        cbar.update_normal(surf)
        ax.set_xlim(np.amin(V_grid), np.amax(V_grid))
        ax.set_ylim(np.amin(T_grid), np.amax(T_grid))
        ax.set_zlim(0.9*np.amin(P_grid), np.amax(P_grid)*1.1)
        P_point = (n*R*T_slider.val)/V_slider.val
        point, = ax.plot([V_slider.val], [T_slider.val], [P_point], 'ko', markersize = 8, zorder = 4)
        p_text.set_text(f"P = {P_point:.2f} atm")
        ax.set_xlabel(r'$V$ (L)')
        ax.set_ylabel(r'$T$ (K)')
        ax.set_zlabel(r'$P$ (atm)')
        fig.canvas.draw_idle()
    except ValueError:
        print('The moles of gas must be a positive number.')

def view_x(event): # used to reset the view along the x axis
    ax.view_init(elev=0, azim=0)
    fig.canvas.draw_idle()

def view_y(event): # used to reset the view along the y axis
    ax.view_init(elev=0, azim=270)
    fig.canvas.draw_idle()

def view_z(event): # used to reset the view along the z axis
    ax.view_init(elev=90, azim=-90)
    fig.canvas.draw_idle()

# Grids
V = np.linspace(1,5,101) # L
T = np.linspace(0,500,101) # K
V_grid, T_grid = np.meshgrid(V,T)
P_grid = (n*R*T_grid)/V_grid # atm

# Initial plot
fig = plt.figure(figsize=(10,8))
ax = fig.add_subplot(projection = '3d')
surf = ax.plot_surface(V_grid, T_grid, P_grid, cmap = 'viridis', edgecolor = 'k', lw=0.01, alpha = 1, shade = True, antialiased=True)
ax.set_xlim(np.amin(V_grid), np.amax(V_grid))
ax.set_ylim(np.amin(T_grid), np.amax(T_grid))
ax.set_zlim(0.9*np.amin(P_grid), np.amax(P_grid)*1.1)
ax.set_xlabel(r'$V$ (L)')
ax.set_ylabel(r'$T$ (K)')
ax.set_zlabel(r'$P$ (atm)')
cbar = fig.colorbar(surf, shrink=0.5, pad = 0.1, label='Pressure (atm)')
surf.set_clim(vmin=P_grid.min(), vmax=P_grid.max())

#initial values for plotted point
V_point = 3
T_point = 300
P_point = (n*R*T_point)/V_point
point, = ax.plot([V_point], [T_point], [P_point], 'ko', markersize = 8, zorder = 4)

#P value on figure
p_text = fig.text(
    0.85, 0.05,
    f"$P$ = {P_point:.2f} atm",
    fontsize = 12,
    color = 'k',
    ha = 'left')

#V slider stuff
sliderax = fig.add_axes([0.35, 0.01, 0.4, 0.05])
V_slider = Slider(
    sliderax,
    label = r'$V$ (L)',
    valmin = 1,
    valmax = np.amax(V_grid),
    valinit = V_point,
    valstep = (max(V)-min(V))/101 )

#T slider stuff
T_slider_ax = fig.add_axes([0.35, 0.05, 0.4, 0.05])
T_slider = Slider(
    T_slider_ax,
    label = r'$T$ (K)',
    valmin = 1,
    valmax = np.amax(T_grid),
    valinit = T_point,
    valstep = (max(T)-min(T))/101 )

# Mole box
graphBox = fig.add_axes([0.15, 0.03, 0.1, 0.05])
txtBox = TextBox(graphBox, '$n$ (mol) ', initial = n)
txtBox.on_submit(update)

# Button axes
ax_x = plt.axes([0.15, 0.9, 0.1, 0.05])
ax_y = plt.axes([0.40, 0.9, 0.1, 0.05])
ax_z = plt.axes([0.65, 0.9, 0.1, 0.05])

btn_x = Button(ax_x, 'View X')
btn_y = Button(ax_y, 'View Y')
btn_z = Button(ax_z, 'View Z')

btn_x.on_clicked(view_x)
btn_y.on_clicked(view_y)
btn_z.on_clicked(view_z)

V_slider.on_changed(update)
T_slider.on_changed(update)

plt.show()

