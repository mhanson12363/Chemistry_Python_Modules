import numpy as np #import numpy package for handling arrays
import matplotlib.pyplot as plt #import matplotlib package for handling plotting
from matplotlib.widgets import Button, Slider, TextBox #lets us make the desired widgets

Ea = 150 #initial activation energy
Ea_uncat = 100 #initial uncatalyzed activation energy
Ereact = 200 #initial energy of reactants (kJ/mol)
Eprod = 0 #intitial energy of products (kJ/mol)
w = 250 #width parameter for Gaussian function; big makes it wide, small makes it narrow
Emax = 500
coord = np.linspace(0,100,1001) #gives reaction coordinate as a % of reaction progress

# The function to be called anytime a slider's or text box's value changes
def update(val):
    global Ea, Ea_uncat, Ereact, Eprod, w, Emax
    try:
        Ea = Ea_slider.val
        Ea_uncat = Ea_uncat_slider.val
        Ereact = Ereact_slider.val
        Eprod = Eprod_slider.val
        w = w_slider.val
        Emax = int(text_box.text)
        if Emax < Ea or Emax < Ereact or Emax < Eprod or Emax < Ea_uncat:
            raise ValueError
        Ea_slider.ax.set_xlim(0, Emax)
        Ea_slider.valmax = Emax
        Ea_uncat_slider.ax.set_xlim(0, Emax)
        Ea_uncat_slider.valmax = Emax
        Ereact_slider.ax.set_xlim(0, Emax)
        Ereact_slider.valmax = Emax
        Eprod_slider.ax.set_xlim(0, Emax)
        Eprod_slider.valmax = Emax 
        if w <= 0:
            raise ValueError
        if Ereact+Ea < Eprod: # activation energy needs to be enough to reach the products!
            Ea = Eprod-Ereact
            Ea_slider.set_val(Eprod-Ereact)
        if Ereact+Ea_uncat < Eprod: # activation energy needs to be enough to reach the products!
            Ea_uncat = Eprod-Ereact
            Ea_uncat_slider.set_val(Eprod-Ereact)
        if Ea < Ea_uncat:
            Ea = Ea_uncat
            Ea_slider.set_val(Ea_uncat)
        curve, curve_uncat = data(Ereact, Eprod, Ea, Ea_uncat, w)
        ax.set_ylim([-0.05*max(max(curve),max(curve_uncat)), 1.05*max(max(curve),max(curve_uncat))])
        line.set_ydata(curve)
        line2.set_ydata(curve_uncat)
    except ValueError:
        print("The maximum energy for sliders must be higher than the current largest value used on the sliders.")

def data(Ereact, Eprod, Ea, Ea_uncat, w):
    Gaussian1 = Ea*np.exp(-(coord-50)**2/w)+Ereact #Gaussian for the first part of the curve
    Gaussian2 = (Ea+Ereact-Eprod)*np.exp(-(coord-50)**2/w) + Eprod #Gaussian for the second part of the curve
    Gaussian3 = Ea_uncat*np.exp(-(coord-50)**2/w)+Ereact #Gaussian for the first part of the curve
    Gaussian4 = (Ea_uncat+Ereact-Eprod)*np.exp(-(coord-50)**2/w) + Eprod #Gaussian for the second part of the curve
    curve = Gaussian1 #starts off by making the curve the whole of the first Gaussian
    index = np.where(coord == 50)[0][0] #finds where the peak is
    curve[index::] = Gaussian2[index::] #makes the last half of the curve the second Gaussian
    curve_uncat = Gaussian3 #starts off by making the curve the whole of the first Gaussian
    curve_uncat[index::] = Gaussian4[index::] #makes the last half of the curve the second Gaussian
    return curve, curve_uncat

#Initializing data
coord = np.linspace(0,100,1001) #gives reaction coordinate as a %
curve, curve_uncat = data(Ereact, Eprod, Ea, Ea_uncat, w)

#Initial plot
fig, ax = plt.subplots(figsize=(12,8))
fig.subplots_adjust(bottom=0.3)
line, = ax.plot(coord,curve,color='b', linewidth = 2, label='Catalyzed Reaction')
line2, = ax.plot(coord,curve_uncat,color='red', linewidth = 2, linestyle = '--', label='Uncatalyzed Reaction')
#matplotlib.rcParams.update({'font.size': 16})
ax.set_xlabel('Reaction progress (%)')
ax.set_ylabel('Energy (kJ/mol)')
ax.set_xlim([0, 100])
ax.set_ylim([-0.05*max(max(curve),max(curve_uncat)), 1.05*max(max(curve),max(curve_uncat))])
plt.grid()
plt.legend()

#Slider for the Ea values
sliderax = fig.add_axes([0.15,0.15,0.3,0.05]) #written in terms of fractions of the window; x start, y start, x width, y width
Ea_slider = Slider(
    sliderax,
    label=r'$E_a$ (kJ/mol)',
    valmin=0,
    valmax=Emax,
    valinit=Ea,
    valstep = 1,
    facecolor = 'b',
    track_color = 'b')

sliderax2 = fig.add_axes([0.15,0.1,0.3,0.05]) #written in terms of fractions of the window; x start, y start, x width, y width
Ea_uncat_slider = Slider(
    sliderax2,
    label=r'$E_a$ Uncatalyzed (kJ/mol)',
    valmin=0,
    valmax=Emax,
    valinit=Ea_uncat,
    valstep = 1,
    facecolor = 'b',
    track_color = 'b')

w_ax = fig.add_axes([0.15,0.05,0.3,0.05]) #written in terms of fractions of the window; x start, y start, x width, y width
w_slider = Slider(
    w_ax,
    label=r'$w$',
    valmin=1,
    valmax=500,
    valstep = 1,
    valinit=w,
    facecolor = 'b',
    track_color = 'b')

Ereact_ax = fig.add_axes([0.6,0.15,0.3,0.05]) #written in terms of fractions of the window; x start, y start, x width, y width
Ereact_slider = Slider(
    Ereact_ax,
    label=r'$E_{react}$ (kJ/mol)',
    valmin=0,
    valmax=Emax,
    valstep = 1,
    valinit=Ereact,
    facecolor = 'b',
    track_color = 'b')

Eprod_ax = fig.add_axes([0.6,0.1,0.3,0.05]) #written in terms of fractions of the window; x start, y start, x width, y width
Eprod_slider = Slider(
    Eprod_ax,
    label=r'$E_{prod}$ (kJ/mol)',
    valmin=0,
    valmax=Emax,
    valstep = 1,
    valinit=Eprod,
    facecolor = 'b',
    track_color = 'b')

axbox = plt.axes([0.6,0.05,0.1,0.05])
text_box = TextBox(axbox, r'Slider Max', initial = Emax, label_pad = 0.05)

# register the update function with each slider and text box
Ea_slider.on_changed(update)
Ea_uncat_slider.on_changed(update)
Ereact_slider.on_changed(update)
Eprod_slider.on_changed(update)
w_slider.on_changed(update)
text_box.on_submit(update)

plt.show()
