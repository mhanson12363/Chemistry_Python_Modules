import numpy as np
import matplotlib.pyplot as plt
from matplotlib import cm
from matplotlib.widgets import Slider, Button, TextBox
from mpl_toolkits.mplot3d import Axes3D

valid = False #initializes so the first call will happen
token = 0 #just initializes at a benign value
def get_token(): #allows neatly looping the program and 'talking' to the user
    valid = False #intitialized as False so the program will seek a valid value
    while valid == False: #keeps looping this until the user provides a valid token
        try: #only works if the user puts something that can be interpreted as an integer
            token = int(input('Which option would you like to use? Enter 0 for options: '))
            if (token in [i+1 for i in range(2)]):
                valid = True
            if token == 0: #lists out the options
                print('The following options are available for plots illustrating the activation energy:' + '\n')
                print('Enter 1:' + ' '*5 + 'Ideal gas law surface plot')
                print('Enter 2:' + ' '*5 + 'Van Der Waals gas surface plot and comparison')
                print('Enter -1:' + ' '*4 + 'Ends the program' + '\n')
            if (token not in [i+1 for i in range(2)]) and (token != -1):
                valid = False
                print('Please enter a valid integer from 1-2 or -1 to quit the program.' + '\n')
            if token == -1:
                valid = True #lets the loop inside the function end
                print('Terminating program')
        except: #yells at the user for putting in an invalid entry
            valid = False
            print('Please enter a valid integer from 1-2 or -1 to quit the program.' + '\n')
    return token, valid

#tells the user the options right away so they don't have to ask for them
print('The following options are available for plots illustrating the activation energy:' + '\n')
print('Enter 1:' + ' '*5 + 'Ideal gas law surface plot')
print('Enter 2:' + ' '*5 + 'Van Der Waals gas surface plot and comparison')
print('Enter -1:' + ' '*4 + 'Ends the program' + '\n')

while (valid or valid == False) and (token != -1): #runs the programs until the user decides to kill the process by setting token = -1
    token, valid = get_token() #continues the loop
    if token == 1:
    #############
    # Program 1 #
    #############
        # Constants
        R = 0.08206 #(L*atm)/(K*mol)
        n = 1.0 # mol

        def update(event):
            try:
                n = float(txtBox.text)
                if n <= 0:
                    raise ValueError
                ax.clear()
                P_grid = n*R*T_grid/V_grid # atm 
                surf = ax.plot_surface(V_grid, T_grid, P_grid, cmap = 'viridis', edgecolor = 'k', lw=0.01, alpha = 1, shade = True, antialiased=True)
                surf.set_clim(vmin=P_grid.min(), vmax=P_grid.max())
                cbar.update_normal(surf)
                ax.set_xlim(np.amin(V_grid), np.amax(V_grid))
                ax.set_ylim(np.amin(T_grid), np.amax(T_grid))
                ax.set_zlim(0.9*np.amin(P_grid), np.amax(P_grid)*1.1)
                P_point = (n*R*T_slider.val)/V_slider.val
                point, = ax.plot([V_slider.val], [T_slider.val], [P_point], 'ko', markersize = 8, zorder = 4)
                p_text.set_text(f"P = {P_point:.2f} atm")
                ax.set_xlabel(r'$V$ (L)')
                ax.set_ylabel(r'$T$ (K)')
                ax.set_zlabel(r'$P$ (atm)')
                fig.canvas.draw_idle()
            except ValueError:
                print('The moles of gas must be a positive number.')

        def view_x(event): # used to reset the view along the x axis
            ax.view_init(elev=0, azim=0)
            fig.canvas.draw_idle()

        def view_y(event): # used to reset the view along the y axis
            ax.view_init(elev=0, azim=270)
            fig.canvas.draw_idle()

        def view_z(event): # used to reset the view along the z axis
            ax.view_init(elev=90, azim=-90)
            fig.canvas.draw_idle()

        # Grids
        V = np.linspace(1,5,101) # L
        T = np.linspace(0,500,101) # K
        V_grid, T_grid = np.meshgrid(V,T)
        P_grid = (n*R*T_grid)/V_grid # atm

        # Initial plot
        fig = plt.figure(figsize=(10,8))
        ax = fig.add_subplot(projection = '3d')
        surf = ax.plot_surface(V_grid, T_grid, P_grid, cmap = 'viridis', edgecolor = 'k', lw=0.01, alpha = 1, shade = True, antialiased=True)
        ax.set_xlim(np.amin(V_grid), np.amax(V_grid))
        ax.set_ylim(np.amin(T_grid), np.amax(T_grid))
        ax.set_zlim(0.9*np.amin(P_grid), np.amax(P_grid)*1.1)
        ax.set_xlabel(r'$V$ (L)')
        ax.set_ylabel(r'$T$ (K)')
        ax.set_zlabel(r'$P$ (atm)')
        cbar = fig.colorbar(surf, shrink=0.5, pad = 0.1, label='Pressure (atm)')
        surf.set_clim(vmin=P_grid.min(), vmax=P_grid.max())

        #initial values for plotted point
        V_point = 3
        T_point = 300
        P_point = (n*R*T_point)/V_point
        point, = ax.plot([V_point], [T_point], [P_point], 'ko', markersize = 8, zorder = 4)

        #P value on figure
        p_text = fig.text(
            0.85, 0.05,
            f"$P$ = {P_point:.2f} atm",
            fontsize = 12,
            color = 'k',
            ha = 'left')

        #V slider stuff
        sliderax = fig.add_axes([0.35, 0.01, 0.4, 0.05])
        V_slider = Slider(
            sliderax,
            label = r'$V$ (L)',
            valmin = 1,
            valmax = np.amax(V_grid),
            valinit = V_point,
            valstep = (max(V)-min(V))/101 )

        #T slider stuff
        T_slider_ax = fig.add_axes([0.35, 0.05, 0.4, 0.05])
        T_slider = Slider(
            T_slider_ax,
            label = r'$T$ (K)',
            valmin = 1,
            valmax = np.amax(T_grid),
            valinit = T_point,
            valstep = (max(T)-min(T))/101 )

        # Mole box
        graphBox = fig.add_axes([0.15, 0.03, 0.1, 0.05])
        txtBox = TextBox(graphBox, '$n$ (mol) ', initial = n)
        txtBox.on_submit(update)

        # Button axes
        ax_x = plt.axes([0.15, 0.9, 0.1, 0.05])
        ax_y = plt.axes([0.40, 0.9, 0.1, 0.05])
        ax_z = plt.axes([0.65, 0.9, 0.1, 0.05])

        btn_x = Button(ax_x, 'View X')
        btn_y = Button(ax_y, 'View Y')
        btn_z = Button(ax_z, 'View Z')

        btn_x.on_clicked(view_x)
        btn_y.on_clicked(view_y)
        btn_z.on_clicked(view_z)

        V_slider.on_changed(update)
        T_slider.on_changed(update)

        plt.show()
    #################
    # Program 1 end #
    #################

    if token == 2:
    #############
    # Program 2 #
    #############
        # Constants
        R = 0.08206 #(L*atm)/(K*mol)
        n = 1.0 # mol
        a = 1.37 # L^2 atm/mol 
        b = 0.0387 # L/mol
        mode = True # True = plot VDW surface, False = plot difference from ideal gas

        def update(event):
            try:
                if mode:
                    n = float(txtBox.text)
                    a = float(txtBox2.text)
                    b = float(txtBox3.text)
                    if n <= 0:
                        raise ValueError
                    ax.clear()
                    P_grid = (R*T_grid)/(V_grid/n - b) - a*n**2/V**2 # atm
                    surf = ax.plot_surface(V_grid, T_grid, P_grid, cmap = 'viridis', edgecolor = 'k', lw=0.01, alpha = 1, shade = True, antialiased=True)
                    surf.set_clim(vmin=P_grid.min(), vmax=P_grid.max())
                    cbar.update_normal(surf)
                    ax.set_xlim(np.amin(V_grid), np.amax(V_grid))
                    ax.set_ylim(np.amin(T_grid), np.amax(T_grid))
                    ax.set_zlim(0.9*np.amin(P_grid), np.amax(P_grid)*1.1)
                    P_point = (R*T_slider.val)/(V_slider.val/n - b) - a*n**2/V_slider.val**2
                    point, = ax.plot([V_slider.val], [T_slider.val], [P_point], 'ko', markersize = 8, zorder = 4)
                    p_text.set_text(fr"$P = ${P_point:.2f} atm")
                    ax.set_xlabel(r'$V$ (L)')
                    ax.set_ylabel(r'$T$ (K)')
                    ax.set_zlabel(r'$P$ (atm)')
                    fig.canvas.draw_idle()
                if mode == False:
                    n = float(txtBox.text)
                    a = float(txtBox2.text)
                    b = float(txtBox3.text)
                    if n <= 0:
                        raise ValueError
                    ax.clear()
                    P_grid = (R*T_grid)/(V_grid/n - b) - a*n**2/V**2 - (R*T_grid)/(V_grid/n) # atm; difference btw VDW and ideal gas
                    surf = ax.plot_surface(V_grid, T_grid, P_grid, cmap = 'viridis', edgecolor = 'k', lw=0.01, alpha = 1, shade = True, antialiased=True)
                    surf.set_clim(vmin=P_grid.min(), vmax=P_grid.max())
                    cbar.update_normal(surf)
                    cbar.set_label('Pressure deviation from ideal (atm)')
                    ax.set_xlim(np.amin(V_grid), np.amax(V_grid))
                    ax.set_ylim(np.amin(T_grid), np.amax(T_grid))
                    ax.set_zlim(1.1*np.amin(P_grid), np.amax(P_grid)*1.1)
                    P_point = (R*T_slider.val)/(V_slider.val/n - b) - a*n**2/V_slider.val**2 - (R*T_slider.val)/(V_slider.val/n)
                    point, = ax.plot([V_slider.val], [T_slider.val], [P_point], 'ko', markersize = 8, zorder = 4)
                    p_text.set_text(r"$\Delta P_{VDW-Ideal} = $ " + f"{P_point:.2f} atm")
                    ax.set_xlabel(r'$V$')
                    ax.set_ylabel(r'$T$')
                    ax.set_zlabel(r'$\Delta P_{VDW-Ideal}$')
                    fig.canvas.draw_idle()
            except ValueError:
                print('The moles of gas must be a positive number.')

        def view_x(event): # used to reset the view along the x axis
            ax.view_init(elev=0, azim=0)
            fig.canvas.draw_idle()

        def view_y(event): # used to reset the view along the y axis
            ax.view_init(elev=0, azim=270)
            fig.canvas.draw_idle()

        def view_z(event): # used to reset the view along the z axis
            ax.view_init(elev=90, azim=-90)
            fig.canvas.draw_idle()

        def swap(event):
            global mode
            mode = not mode
            update(1)

        # Grids
        V = np.linspace(1,5,101) # L
        T = np.linspace(0,500,101) # K
        V_grid, T_grid = np.meshgrid(V,T)
        P_grid = (R*T_grid)/(V_grid/n - b) - a*n**2/V**2 # atm

        # Initial plot
        fig = plt.figure(figsize=(10,8))
        ax = fig.add_subplot(projection = '3d')
        surf = ax.plot_surface(V_grid, T_grid, P_grid, cmap = 'viridis', edgecolor = 'k', lw=0.01, alpha = 1, shade = True, antialiased=True)
        ax.set_xlim(np.amin(V_grid), np.amax(V_grid))
        ax.set_ylim(np.amin(T_grid), np.amax(T_grid))
        ax.set_zlim(0.9*np.amin(P_grid), np.amax(P_grid)*1.1)
        ax.set_xlabel(r'$V$ (L)')
        ax.set_ylabel(r'$T$ (K)')
        ax.set_zlabel(r'$P$ (atm)')
        cbar = fig.colorbar(surf, shrink=0.5, pad = 0.1, label='Pressure (atm)')
        surf.set_clim(vmin=P_grid.min(), vmax=P_grid.max())

        #initial values for plotted point
        V_point = 3
        T_point = 300
        P_point = (n*R*T_point)/V_point
        point, = ax.plot([V_point], [T_point], [P_point], 'ko', markersize = 8, zorder = 4)

        #P value on figure
        p_text = fig.text(
            0.75, 0.05,
            fr"$P = ${P_point:.2f} atm",
            fontsize = 12,
            color = 'k',
            ha = 'left')

        #V slider stuff
        sliderax = fig.add_axes([0.3, 0.01, 0.4, 0.05])
        V_slider = Slider(
            sliderax,
            label = r'$V$ (L)',
            valmin = 1,
            valmax = np.amax(V_grid),
            valinit = V_point,
            valstep = (max(V)-min(V))/101 )

        #T slider stuff
        T_slider_ax = fig.add_axes([0.3, 0.05, 0.4, 0.05])
        T_slider = Slider(
            T_slider_ax,
            label = r'$T$ (K)',
            valmin = 1,
            valmax = np.amax(T_grid),
            valinit = T_point,
            valstep = (max(T)-min(T))/101 )

        # Mole box
        graphBox = fig.add_axes([0.1, 0.03, 0.1, 0.05])
        txtBox = TextBox(graphBox, r'$n$ (mol) ', initial = n)
        txtBox.on_submit(update)

        # a box
        graphBox2 = fig.add_axes([0.8, 0.125, 0.1, 0.05])
        txtBox2 = TextBox(graphBox2, r'$a$ (L$^2$atm/mol$^2$) ', initial = a)
        txtBox2.on_submit(update)

        # b box
        graphBox3 = fig.add_axes([0.8, 0.2, 0.1, 0.05])
        txtBox3 = TextBox(graphBox3, r'$b$ (L/mol) ', initial = b)
        txtBox3.on_submit(update)

        # Button axes
        ax_x = plt.axes([0.1, 0.9, 0.1, 0.05])
        ax_y = plt.axes([0.3, 0.9, 0.1, 0.05])
        ax_z = plt.axes([0.5, 0.9, 0.1, 0.05])
        ax_swap = plt.axes([0.8, 0.9, 0.1, 0.05])

        btn_x = Button(ax_x, 'View X')
        btn_y = Button(ax_y, 'View Y')
        btn_z = Button(ax_z, 'View Z')
        btn_swap = Button(ax_swap, 'Swap Mode')

        btn_x.on_clicked(view_x)
        btn_y.on_clicked(view_y)
        btn_z.on_clicked(view_z)
        btn_swap.on_clicked(swap)

        V_slider.on_changed(update)
        T_slider.on_changed(update)

        plt.show()
    #################
    # Program 2 end #
    #################
