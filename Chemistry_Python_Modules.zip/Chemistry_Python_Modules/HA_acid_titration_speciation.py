import numpy as np #import Numpy Package
import matplotlib.pyplot as plt #import matplotlib Package
from matplotlib.widgets import Button, Slider, TextBox

pka = 5.0 #initial
V_a = 10.0 #volume of acid being titrated (mL)
C_a = 0.1 #concentration of acid (M)
C_b = 0.1 #concentration of base (M)

# The function to be called anytime a slider's value changes
def update(val):
    global pka, V_a, C_a, C_b
    try: 
        pka = pka_slider.val
        V_a = float(txtBox1.text)
        C_a = float(txtBox2.text)
        C_b = float(txtBox3.text)
        if V_a <= 0 or C_a <= 0 or C_b <= 0:
            raise ValueError
        V_b, C_HA, C_Amin = data(pka, V_a, C_a, C_b)
        ax1.set_xlim([0, 2*V_a*C_a/C_b])
        line.set_xdata(V_b)
        line2.set_xdata(V_b)
        line2.set_ydata(C_HA)
        line3.set_xdata(V_b)
        line3.set_ydata(C_Amin)
        ax2.set_xlim([0, 2*V_a*C_a/C_b])
        ax2.set_ylim([-0.05*C_a, 1.05*C_a])
    except ValueError:
        print("Please use valid positive values for the volume of acid and the concentration of acid and base.")

def data(pka, V_a, C_a, C_b):
    pH = pH = np.linspace(0,14+np.log10(C_b),200) # range is set so it doesn't blow up!
    H = 10**(-pH) #concentration of H+ (M)
    OH = (10**(-14))/H #concentration of OH- (M)
    Ka=10**(-pka)
    d = H + Ka #denominator of proportions
    A_A = Ka/d #proportion in form A-
    phi_n = A_A - ((H - OH)/C_a) #numerator of Harris' formula
    phi_d = 1 + ((H - OH)/C_b) #denominator of Harris' formula
    phi = phi_n / phi_d # ratio from Harris' formula
    V_b = (phi*C_a*V_a)/C_b #Volume of base added that matches the pH based on Harris' formula

    C_HA = C_a*V_a/(V_a+V_b)*(1+10**(pH-pka))**-1 # speciation based on HH equation
    C_Amin = C_a*V_a/(V_a+V_b) - C_HA # using the total equation
    return V_b, C_HA, C_Amin

#Initializing data
pH = np.linspace(0,13,200) #using the pH values to figure out the volume added; range is set so it doesn't blow up!
H = 10**(-pH) #concentration of H+ (M)
OH = (10**(-14))/H #concentration of OH- (M)
V_b, C_HA, C_Amin  = data(pka, V_a, C_a, C_b)

#Initial plot
fig, (ax1,ax2) = plt.subplots(1,2,figsize=(15,6))
fig.subplots_adjust(bottom=0.3)
line, = ax1.plot(V_b,pH,color='b', linewidth = 2, label='Titration Curve')
ax1.set_xlabel(r'$V$ base added (mL)')
ax1.set_ylabel('pH')
ax1.set_xlim([0, 2*V_a*C_a/C_b])
ax1.grid()
line2, = ax2.plot(V_b, C_HA, color='r', linewidth = 2, label=r'[HA] (M)')
line3, = ax2.plot(V_b, C_Amin, color='r', linewidth = 2, linestyle = '--', label=r'[A$^-$] (M)')
ax2.set_xlabel(r'$V$ base added (mL)')
ax2.set_ylabel('Species Concentration (M)')
ax2.set_xlim([0, 2*V_a*C_a/C_b])
ax2.set_ylim([-0.05*C_a, 1.05*C_a])
ax2.grid()
ax2.legend()

#Slider for the pKa values
sliderax = fig.add_axes([0.1,0.1,0.6,0.05]) #written in terms of fractions of the window; x start, y start, x width, y width
pka_slider = Slider(
    sliderax,
    label=r'p$K_a$',
    valmin=0,
    valmax=13,
    valinit=5)

#Textbox for volume of acid'
graphBox1 = fig.add_axes([0.85, 0.15, 0.1, 0.05])
txtBox1 = TextBox(graphBox1, '$V$ acid (mL) ', initial = 10.0)
txtBox1.on_submit(update)

#Textbox for concentration of acid'
graphBox2 = fig.add_axes([0.85, 0.1, 0.1, 0.05])
txtBox2 = TextBox(graphBox2, '[Acid] (M) ', initial = 0.1)
txtBox2.on_submit(update)

#Textbox for concentration of base'
graphBox3 = fig.add_axes([0.85, 0.05, 0.1, 0.05])
txtBox3 = TextBox(graphBox3, '[Base] (M) ', initial = 0.1)
txtBox3.on_submit(update)

# register the update function with each slider
pka_slider.on_changed(update)

plt.show()
