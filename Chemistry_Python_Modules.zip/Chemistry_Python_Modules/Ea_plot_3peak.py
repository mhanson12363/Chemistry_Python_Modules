import numpy as np #import np Package
import matplotlib.pyplot as plt #import matplotlib Package
from matplotlib.widgets import Button, Slider, TextBox

Ea1 = 150 #initial activation energy for 1st step
Ea2 = 150 #initial activation energy for 2nd step
Ea3 = 100 #initial activation energy for 3rd step
Einter1 = 100 #energy of the first intermediate species
Einter2 = 150 #energy of the second intermediate species
Ereact = 0 #Relative energy of reactant (kJ/mol)
Eprod = 100 #Relative energy of product (kJ/mol)
w = 30 #width parameter for Gaussian function
Emax = 500 

# The function to be called anytime a slider's value changes
def update(val):
    global Ea1, Ea2, Ea3, Einter1, Einter2, Ereact, Eprod, w, Emax
    try:
        Ea1 = Ea1_slider.val
        Ea2 = Ea2_slider.val
        Ea3 = Ea3_slider.val
        Einter1 = Einter1_slider.val
        Einter2 = Einter2_slider.val
        Ereact = Ereact_slider.val
        Eprod = Eprod_slider.val
        w = w_slider.val
        Emax = int(text_box.text)
        if Emax < Ea1 or Emax < Ea2 or Emax < Ea3 or Emax < Ereact or Emax < Eprod:
            raise ValueError
        Ea1_slider.ax.set_xlim(0, Emax)
        Ea1_slider.valmax = Emax
        Ea2_slider.ax.set_xlim(0, Emax)
        Ea2_slider.valmax = Emax
        Ea3_slider.ax.set_xlim(0, Emax)
        Ea3_slider.valmax = Emax
        Einter1_slider.ax.set_xlim(0, Emax)
        Einter1_slider.valmax = Emax
        Einter2_slider.ax.set_xlim(0, Emax)
        Einter2_slider.valmax = Emax
        Ereact_slider.ax.set_xlim(0, Emax)
        Ereact_slider.valmax = Emax
        Eprod_slider.ax.set_xlim(0, Emax)
        Eprod_slider.valmax = Emax 
        if Einter1 > Ea1+Ereact:
            Einter1 = Ea1+Ereact
            Einter1_slider.set_val(Ea1+Ereact)
        if Einter1+Ea2 < Einter1: # activation energy needs to be enough to reach the intermediate!
            Ea2 = Einter2-Einter1
            Ea2_slider.set_val(Einter2-Einter1)
        if Einter2 > Ea2+Einter1:
            Einter2 = Ea2+Einter1
            Einter2_slider.set_val(Ea2+Einter1)
        if Einter2+Ea3 < Eprod: # activation energy needs to be enough to reach the intermediate!
            Ea3 = Eprod-Einter2
            Ea3_slider.set_val(Eprod-Einter2)
        curve = data(Ereact, Eprod, Ea1, Ea2, Ea3, Einter1, Einter2, w)
        ax.set_ylim([-0.05*max(curve), 1.05*max(curve)])
        line.set_ydata(curve)
    except ValueError:
        print("The maximum energy for sliders must be higher than the current largest value used on the sliders.")

def data(Ereact, Eprod, Ea1, Ea2, Ea3, Einter1, Einter2, w):
    Gaussian1 = Ea1*np.exp(-(coord-25)**2/w)+Ereact #Gaussian for the first part of the curve
    Gaussian2 = (Ea1+Ereact-Einter1)*np.exp(-(coord-25)**2/w) #first Gaussian for the second part of the curve
    Gaussian3 = Ea2*np.exp(-(coord-50)**2/w)+Einter1 #second Gaussian for the second part of the curve
    Gaussian4 = (Ea2+Einter1-Einter2)*np.exp(-(coord-50)**2/w) #first Gaussian for the third part of the curve
    Gaussian5 = Ea3*np.exp(-(coord-75)**2/w) + Einter2 #second Gaussian for the third part of the curve
    Gaussian6 = (Ea3+Einter2-Eprod)*np.exp(-(coord-75)**2/w)+Eprod #Gaussian for the final part of the curve
    peak1_index = np.where(coord == 25)[0][0] #finds peak of first Gaussian
    peak2_index = np.where(coord == 50)[0][0] #finds peak of second Gaussian
    peak3_index = np.where(coord == 75)[0][0] #finds peak of last Gaussian
    curve = np.zeros(len(coord))
    curve[0:peak1_index] = Gaussian1[0:peak1_index] #starts off by making the first bit of the curve
    curve[peak1_index:peak2_index] = Gaussian2[peak1_index:peak2_index] + Gaussian3[peak1_index:peak2_index] #makes the second part of the curve a mixture of Gaussians
    curve[peak2_index:peak3_index] = Gaussian4[peak2_index:peak3_index] + Gaussian5[peak2_index:peak3_index] #makes the third part of the curve a mixture of Gaussians
    curve[peak3_index::] = Gaussian6[peak3_index::] #makes the final piece of the curve the final Gaussian
    return curve

#Initializing data
coord = np.linspace(0,100,1001) #gives reaction coordinate as a %
curve = data(Ereact, Eprod, Ea1, Ea2, Ea3, Einter1, Einter2, w)

#Initial plot
fig, ax = plt.subplots(figsize=(10,8))
fig.subplots_adjust(bottom=0.3)
line, = ax.plot(coord,curve,color='b', linewidth = 2, label='Arrhenius Curve')
#matplotlib.rcParams.update({'font.size': 16})
ax.set_xlabel('Reaction progress (%)')
ax.set_ylabel('Energy (kJ/mol)')
ax.set_xlim([0, 100])
ax.set_ylim([-0.05*max(curve), 1.05*max(curve)])
plt.grid()

#Sliders for the Ea values
sliderax = fig.add_axes([0.15,0.2,0.3,0.05]) #written in terms of fractions of the window; x start, y start, x width, y width
Ea1_slider = Slider(
    sliderax,
    label=r'$E_{a1}$ (kJ/mol)',
    valmin=0,
    valmax=Emax,
    valinit=Ea1,
    valstep = 1,
    facecolor = 'b',
    track_color = 'b')

sliderax2 = fig.add_axes([0.15,0.15,0.3,0.05]) #written in terms of fractions of the window; x start, y start, x width, y width
Ea2_slider = Slider(
    sliderax2,
    label=r'$E_{a2}$ (kJ/mol)',
    valmin=0,
    valmax=Emax,
    valinit=Ea2,
    valstep = 1,
    facecolor = 'b',
    track_color = 'b')

sliderax3 = fig.add_axes([0.15,0.1,0.3,0.05]) #written in terms of fractions of the window; x start, y start, x width, y width
Ea3_slider = Slider(
    sliderax3,
    label=r'$E_{a3}$ (kJ/mol)',
    valmin=0,
    valmax=Emax,
    valinit=Ea3,
    valstep = 1,
    facecolor = 'b',
    track_color = 'b')

w_ax = fig.add_axes([0.15,0.05,0.3,0.05]) #written in terms of fractions of the window; x start, y start, x width, y width
w_slider = Slider(
    w_ax,
    label=r'$w$',
    valmin=1,
    valmax=60,
    valstep = 1,
    valinit=w,
    facecolor = 'b',
    track_color = 'b')

Einter1_ax = fig.add_axes([0.6,0.2,0.3,0.05]) #written in terms of fractions of the window; x start, y start, x width, y width
Einter1_slider = Slider(
    Einter1_ax,
    label=r'$E_{inter1}$ (kJ/mol)',
    valmin=0,
    valmax=500,
    valinit=Einter1,
    valstep = 1,
    facecolor = 'b',
    track_color = 'b')

Einter2_ax = fig.add_axes([0.6,0.15,0.3,0.05]) #written in terms of fractions of the window; x start, y start, x width, y width
Einter2_slider = Slider(
    Einter2_ax,
    label=r'$E_{inter2}$ (kJ/mol)',
    valmin=0,
    valmax=Emax,
    valinit=Einter2,
    valstep = 1,
    facecolor = 'b',
    track_color = 'b')

Ereact_ax = fig.add_axes([0.6,0.1,0.3,0.05]) #written in terms of fractions of the window; x start, y start, x width, y width
Ereact_slider = Slider(
    Ereact_ax,
    label=r'$E_{react}$ (kJ/mol)',
    valmin=0,
    valmax=500,
    valstep = 1,
    valinit=Ereact,
    facecolor = 'b',
    track_color = 'b')

Eprod_ax = fig.add_axes([0.6,0.05,0.3,0.05]) #written in terms of fractions of the window; x start, y start, x width, y width
Eprod_slider = Slider(
    Eprod_ax,
    label=r'$E_{prod}$ (kJ/mol)',
    valmin=0,
    valmax=Emax,
    valstep = 1,
    valinit=Eprod,
    facecolor = 'b',
    track_color = 'b')

axbox = plt.axes([0.6,0,0.1,0.05])
text_box = TextBox(axbox, r'Slider Max', initial = Emax, label_pad = 0.05)

# register the update function with each slider
Ea1_slider.on_changed(update)
Ea2_slider.on_changed(update)
Ea3_slider.on_changed(update)
Einter1_slider.on_changed(update)
Einter2_slider.on_changed(update)
Ereact_slider.on_changed(update)
Eprod_slider.on_changed(update)
w_slider.on_changed(update)
text_box.on_submit(update)

plt.show()


