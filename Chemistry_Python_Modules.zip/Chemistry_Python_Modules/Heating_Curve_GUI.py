import numpy as np
import matplotlib
import matplotlib.pyplot as plt
from matplotlib.widgets import TextBox, Button

params ={'mass (g) ': 100,
         'Molar mass (g/mol) ': 18.015,
         r'$c_{(s)}$ (J/g°C) ': 2.1,
         r'$c_{(l)}$ (J/g°C) ': 4.184,
         r'$c_{(g)}$ (J/g°C) ': 2.0,
         r'$T_{melt}$ (°C) ': 0,
         r'$T_{boil}$ (°C) ': 100,
         r'$\Delta H_{fus}^\circ$ (J/mol) ': 6010,
         r'$\Delta H_{vap}^\circ$ (J/mol) ': 40660,
         r'$T_{min}$ (°C) ': -20,
         r'$T_{max}$ (°C) ': 120}

fig, ax = plt.subplots(figsize=(10, 6))
plt.subplots_adjust(left=0.3)

x_position = 0.15
y_start = 0.13
y_step = 0.06
y_sep = 0.5

text_boxes = {}
box_positions = {'mass (g) ': (x_position, y_start+(10+4*y_sep)*y_step, 0.06, 0.05),
                 'Molar mass (g/mol) ': (x_position, y_start+(9+4*y_sep)*y_step, 0.06, 0.05),
                 r'$c_{(s)}$ (J/g°C) ': (x_position, y_start+(8+3*y_sep)*y_step, 0.06, 0.05),
                 r'$c_{(l)}$ (J/g°C) ': (x_position, y_start+(7+3*y_sep)*y_step, 0.06, 0.05),
                 r'$c_{(g)}$ (J/g°C) ': (x_position, y_start+(6+3*y_sep)*y_step, 0.06, 0.05),
                 r'$T_{melt}$ (°C) ': (x_position, y_start+(5+2*y_sep)*y_step, 0.06, 0.05),
                 r'$T_{boil}$ (°C) ': (x_position, y_start+(4+2*y_sep)*y_step, 0.06, 0.05),
                 r'$\Delta H_{fus}^\circ$ (J/mol) ': (x_position, y_start+(3+y_sep)*y_step, 0.06, 0.05),
                 r'$\Delta H_{vap}^\circ$ (J/mol) ': (x_position, y_start+(2+y_sep)*y_step, 0.06, 0.05),
                 r'$T_{min}$ (°C) ': (x_position, y_start+y_step, 0.06, 0.05),
                 r'$T_{max}$ (°C) ': (x_position, y_start, 0.06, 0.05),}

for key, pos in box_positions.items():
    ax_box = plt.axes(pos)
    text_box = TextBox(ax_box, key, initial=str(params[key]))
    text_boxes[key] = text_box

def simulate_phase_curve(params):
    T_values = []
    q_values = []
    q_total = 0
    heating_periods = {} # holds the heat involved in heating each phase up
    phase_transitions = {} # holds the heat involved in the phase transitions
    q_values.append(q_total)
    T_values.append(params[r'$T_{min}$ (°C) ']) # first point on the graph

    if params[r'$T_{min}$ (°C) '] <= params[r'$T_{melt}$ (°C) ']: # if we start at or below the melting point (assumes we need to melt if we start at it)
        if params[r'$T_{max}$ (°C) '] >= params[r'$T_{melt}$ (°C) ']: # if the substance will melt
            q_total += params['mass (g) ']*params[r'$c_{(s)}$ (J/g°C) ']*(params[r'$T_{melt}$ (°C) ']-params[r'$T_{min}$ (°C) ']) # heat up to M.P. 
            q_values.append(q_total)
            T_values.append(params[r'$T_{melt}$ (°C) '])
            heating_periods['Heating solid'] = params['mass (g) ']*params[r'$c_{(s)}$ (J/g°C) ']*(params[r'$T_{melt}$ (°C) ']-params[r'$T_{min}$ (°C) '])
            q_total += params['mass (g) ']/params['Molar mass (g/mol) ']*params[r'$\Delta H_{fus}^\circ$ (J/mol) '] # heating through the M.P.
            q_values.append(q_total)
            T_values.append(params[r'$T_{melt}$ (°C) '])
            phase_transitions['Melting'] = params['mass (g) ']/params['Molar mass (g/mol) ']*params[r'$\Delta H_{fus}^\circ$ (J/mol) ']
            
            if params[r'$T_{max}$ (°C) '] < params[r'$T_{boil}$ (°C) ']: # we will heat the melted liquid but not boil it
                q_total += params['mass (g) ']*params[r'$c_{(l)}$ (J/g°C) ']*(params[r'$T_{max}$ (°C) ']-params[r'$T_{melt}$ (°C) ']) # heat up to max
                q_values.append(q_total)
                T_values.append(params[r'$T_{max}$ (°C) '])
                heating_periods['Heating liquid'] = params['mass (g) ']*params[r'$c_{(l)}$ (J/g°C) ']*(params[r'$T_{max}$ (°C) ']-params[r'$T_{melt}$ (°C) '])
            else: # we will heat the melted liquid and then boil it and heat the vapor (if necessary) 
                q_total += params['mass (g) ']*params[r'$c_{(l)}$ (J/g°C) ']*(params[r'$T_{boil}$ (°C) ']-params[r'$T_{melt}$ (°C) ']) # heat up to B.P. 
                q_values.append(q_total)
                T_values.append(params[r'$T_{boil}$ (°C) '])
                heating_periods['Heating liquid'] = params['mass (g) ']*params[r'$c_{(l)}$ (J/g°C) ']*(params[r'$T_{boil}$ (°C) ']-params[r'$T_{melt}$ (°C) '])
                q_total += params['mass (g) ']/params['Molar mass (g/mol) ']*params[r'$\Delta H_{vap}^\circ$ (J/mol) '] # heating through the B.P.
                q_values.append(q_total)
                T_values.append(params[r'$T_{boil}$ (°C) '])
                phase_transitions['Boiling'] = params['mass (g) ']/params['Molar mass (g/mol) ']*params[r'$\Delta H_{vap}^\circ$ (J/mol) '] 
                q_total += params['mass (g) ']*params[r'$c_{(g)}$ (J/g°C) ']*(params[r'$T_{max}$ (°C) ']-params[r'$T_{boil}$ (°C) ']) # heat up vapor, if necessary
                q_values.append(q_total)
                T_values.append(params[r'$T_{max}$ (°C) '])
                heating_periods['Heating vapor'] = params['mass (g) ']*params[r'$c_{(g)}$ (J/g°C) ']*(params[r'$T_{max}$ (°C) ']-params[r'$T_{boil}$ (°C) '])
                
        else: # the substance never even melts
            q_total += params['mass (g) ']*params[r'$c_{(s)}$ (J/g°C) ']*(params[r'$T_{melt}$ (°C) ']-params[r'$T_{min}$ (°C) '])
            q_values.append(q_total)
            T_values.append(params[r'$T_{max}$ (°C) '])
            heating_periods['Heating solid'] = params['mass (g) ']*params[r'$c_{(s)}$ (J/g°C) ']*(params[r'$T_{melt}$ (°C) ']-params[r'$T_{min}$ (°C) '])

    if params[r'$T_{min}$ (°C) '] > params[r'$T_{melt}$ (°C) '] and params[r'$T_{min}$ (°C) '] <= params[r'$T_{boil}$ (°C) ']: # start at or below boiling but above melting
        if params[r'$T_{max}$ (°C) '] >= params[r'$T_{boil}$ (°C) ']: # we will heat the liquid and then boil it and heat the vapor (if necessary) 
            q_total += params['mass (g) ']*params[r'$c_{(l)}$ (J/g°C) ']*(params[r'$T_{boil}$ (°C) ']-params[r'$T_{min}$ (°C) ']) # heat up to B.P. 
            q_values.append(q_total)
            T_values.append(params[r'$T_{boil}$ (°C) '])
            heating_periods['Heating liquid'] = params['mass (g) ']*params[r'$c_{(l)}$ (J/g°C) ']*(params[r'$T_{boil}$ (°C) ']-params[r'$T_{min}$ (°C) '])
            q_total += params['mass (g) ']/params['Molar mass (g/mol) ']*params[r'$\Delta H_{vap}^\circ$ (J/mol) '] # heating through the B.P.
            q_values.append(q_total)
            T_values.append(params[r'$T_{boil}$ (°C) '])
            phase_transitions['Boiling'] = params['mass (g) ']/params['Molar mass (g/mol) ']*params[r'$\Delta H_{vap}^\circ$ (J/mol) ']
            q_total += params['mass (g) ']*params[r'$c_{(g)}$ (J/g°C) ']*(params[r'$T_{max}$ (°C) ']-params[r'$T_{boil}$ (°C) ']) # heat up vapor, if necessary
            q_values.append(q_total)
            T_values.append(params[r'$T_{max}$ (°C) '])
            heating_periods['Heating vapor'] = params['mass (g) ']*params[r'$c_{(g)}$ (J/g°C) ']*(params[r'$T_{max}$ (°C) ']-params[r'$T_{boil}$ (°C) '])
        else: # we will heat the liquid but not boil it
            q_total += params['mass (g) ']*params[r'$c_{(l)}$ (J/g°C) ']*(params[r'$T_{max}$ (°C) ']-params[r'$T_{min}$ (°C) ']) # heat up the liquid 
            q_values.append(q_total)
            T_values.append(params[r'$T_{boil}$ (°C) '])
            heating_periods['Heating liquid'] = params['mass (g) ']*params[r'$c_{(l)}$ (J/g°C) ']*(params[r'$T_{max}$ (°C) ']-params[r'$T_{min}$ (°C) '])

    if params[r'$T_{min}$ (°C) '] > params[r'$T_{boil}$ (°C) ']: # start with vapor and heat it up
        q_total += params['mass (g) ']*params[r'$c_{(g)}$ (J/g°C) ']*(params[r'$T_{max}$ (°C) ']-params[r'$T_{min}$ (°C) ']) # heat up vapor, if necessary
        q_values.append(q_total)
        T_values.append(params[r'$T_{max}$ (°C) '])
        heating_periods['Heating vapor'] = params['mass (g) ']*params[r'$c_{(g)}$ (J/g°C) ']*(params[r'$T_{max}$ (°C) ']-params[r'$T_{min}$ (°C) '])

    return T_values, q_values, heating_periods, phase_transitions

def submit(event):
    try:
        for key in params:
            params[key] = float(text_boxes[key].text)
        if (params[r'$c_{(s)}$ (J/g°C) '] < 0 or params[r'$c_{(l)}$ (J/g°C) '] < 0 or params[r'$c_{(g)}$ (J/g°C) '] < 0 or params[r'$\Delta H_{vap}^\circ$ (J/mol) '] < 0
            or params[r'$\Delta H_{fus}^\circ$ (J/mol) '] < 0 or params['mass (g) '] <= 0 or params['Molar mass (g/mol) '] <= 0 or params[r'$T_{min}$ (°C) '] < -273.15
            or params[r'$T_{melt}$ (°C) '] < -273.15 or params[r'$T_{boil}$ (°C) '] < -273.15):
            raise ValueError
        if params[r'$T_{min}$ (°C) '] > params[r'$T_{max}$ (°C) '] or params[r'$T_{boil}$ (°C) '] < params[r'$T_{melt}$ (°C) ']:
            raise ValueError
        T, q, heating_periods, phase_transitions = simulate_phase_curve(params)
        ax.clear()
        if max(q) < 100000:
            ax.set_xlabel("Heat Energy Added (J)")
        if max(q) >= 100000 and max(q) < 100000000: # just keeps the axis values more sane 
            q = [q[i]/1000 for i in range(len(q))]
            ax.set_xlabel("Heat Energy Added (kJ)")
        ax.plot(q, T, linewidth = 2)
        ax.set_ylabel("Temperature (°C)")
        ax.grid()
        fig.canvas.draw_idle() # forces the redraw
        for key in heating_periods:
            print(str(key) + str(': ') + str(round(heating_periods[key],2)) + ' J')
        for key in phase_transitions:
            print(str(key) + str(': ') + str(round(phase_transitions[key],2)) + ' J')
        print('\n')
    except ValueError:
        print('An error happened while updating values. The mass, molar mass, heat capacities,')
        print('and enthalpies of fusion and vaporization must be positive numbers. The boiling point must be ')
        print('at or above the melting point and the maximum temperature must be above the minimum temperature.')
        print('All temperatures must be physically realizable in theory.' + '\n')

button_ax = plt.axes([0.03, 0.05, 0.2, 0.05])
button = Button(button_ax, 'Generate Curve')
button.on_clicked(submit)

submit(1) # makes an initial graph

plt.show()
