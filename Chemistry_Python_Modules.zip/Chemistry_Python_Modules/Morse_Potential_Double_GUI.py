import numpy as np
import matplotlib.pyplot as plt
from matplotlib.widgets import Slider, Button

def morse_potential(r, De, a, re):
    return De*(1 - np.exp(-a*(r - re)))**2

De1 = 5.0   # eV
a1 = 2.0   # Angstrom^-1
re1 = 1.0  # Angstrom
De2 = 4.0   # eV
a2 = 2.0   # Angstrom^-1
re2 = 1.5  # Angstrom
minr = min(re1-1/a1*np.log(1+np.sqrt(2)), re2-1/a2*np.log(1+np.sqrt(2)))
maxr = max(re1-1/a1*np.log(1-np.sqrt(0.999)), re2-1/a2*np.log(1-np.sqrt(0.999)))
r = np.linspace(minr, maxr, 201)  # in Angstroms; r chosen so V goes from 2*De to 99.9% of De
r2 = np.linspace(minr, maxr, 201)  # in Angstroms; r chosen so V goes from 2*De to 99.9% of De
flag = True # used to set the rescale mode for the button

fig, ax = plt.subplots(figsize=(10,8))
plt.subplots_adjust(bottom=0.4)
line, = ax.plot(r, morse_potential(r, De1, a1, re1), lw=2, color='b')
line2, = ax.plot(r2, morse_potential(r2, De2, a2, re2), lw=2, color='r', linestyle = '--')
ax.set_xlabel(r"Bond length $r$ (Angstrom)")
ax.set_ylabel(r"Potential Energy $V(r)$ (eV)")
ax.set_xlim([minr, maxr]) 
ax.set_ylim([0, 2*max(De1,De2)])
ax.grid(True)

ax_De = plt.axes([0.2, 0.125, 0.5, 0.03])
ax_a  = plt.axes([0.2, 0.075, 0.5, 0.03])
ax_re = plt.axes([0.2, 0.025, 0.5, 0.03])
ax_De2 = plt.axes([0.2, 0.275, 0.5, 0.03])
ax_a2  = plt.axes([0.2, 0.225, 0.5, 0.03])
ax_re2 = plt.axes([0.2, 0.175, 0.5, 0.03])

slider_De = Slider(ax_De, r"$D_{e1}$ (eV)", 1.0, 12.0, valinit=De1, valstep=0.01)
slider_a  = Slider(ax_a, r"$a_1$ (Angstrom$^{-1}$)", 1.0, 4.0, valinit=a1, valstep=0.01)
slider_re = Slider(ax_re, r"$r_{e1}$ (Angstrom)", 0.1, 5, valinit=re1, valstep=0.01)
slider_De2 = Slider(ax_De2, r"$D_{e2}$ (eV)", 1.0, 12.0, valinit=De2, valstep=0.01)
slider_a2  = Slider(ax_a2, r"$a_2$ (Angstrom$^{-1}$)", 1.0, 4.0, valinit=a2, valstep=0.01)
slider_re2 = Slider(ax_re2, r"$r_{e2}$ (Angstrom)", 0.1, 5, valinit=re2, valstep=0.01)

def update(val):
    global r, De, a, re, r2, De2, a2, re2
    De = slider_De.val
    a = slider_a.val
    re = slider_re.val
    De2 = slider_De2.val
    a2 = slider_a2.val
    re2 = slider_re2.val
    if flag: # only updates the x axis data if the autoscale mode is on
        minr = min(re1-1/a1*np.log(1+np.sqrt(2)), re2-1/a2*np.log(1+np.sqrt(2)))
        maxr = max(re1-1/a1*np.log(1-np.sqrt(0.999)), re2-1/a2*np.log(1-np.sqrt(0.999)))
        r = np.linspace(minr, maxr, 201)  # in Angstroms; r chosen so V goes from 2*De to 99.9% of De
        r2 = np.linspace(minr, maxr, 201)  # in Angstroms; r chosen so V goes from 2*De to 99.9% of De
        line.set_xdata(r)
        line2.set_xdata(r2)
    line.set_ydata(morse_potential(r, De, a, re))
    line2.set_ydata(morse_potential(r2, De2, a2, re2))
    if flag: # only updates the x and y axis ranges if autoscale mode is on
        ax.set_xlim([minr, maxr])
        ax.set_ylim([0, 2*max(De1,De2)])

def rescale(event): # controls the button
    global flag
    De = slider_De.val
    a = slider_a.val
    re = slider_re.val
    counter = 0
    if counter == 0 and flag == True:
        flag = False
        counter += 1
    if counter == 0 and flag == False:
        flag = True
        counter += 1
    if flag == True:
        ax_text.clear()
        ax_text.axis('off')
        ax_text.text(0.1, 0.0, "Rescale \n Mode") 
    if flag == False:
        ax_text.clear()
        ax_text.axis('off')
        ax_text.text(0.1, 0.0, "Fixed Scale \n Mode")
    fig.canvas.draw_idle()

ax_button = fig.add_axes([0.8, 0.1, 0.15, 0.1])
rescale_button = Button(ax_button, "Scaling Mode \n Button", color='cyan', hovercolor='red')

ax_text = fig.add_axes([0.82, 0.05, 0.15, 0.1])
ax_text.axis('off')
ax_text.text(0.15, 0.0, "Rescale \n Mode")

slider_De.on_changed(update)
slider_a.on_changed(update)
slider_re.on_changed(update)
slider_De2.on_changed(update)
slider_a2.on_changed(update)
slider_re2.on_changed(update)
rescale_button.on_clicked(rescale)

plt.show()
