import numpy as np #import Numpy Package
import matplotlib.pyplot as plt #import matplotlib Package
from matplotlib.widgets import Button, Slider, TextBox

pka1 = 3.0 #initial random values
pka2 = 8.0
V_a = 10 #volume of acid being titrated (mL)
C_a = 0.1 #concentration of acid (M)
C_b = 0.1 #concentration of base (M)

deriv_peak = True # True = max, False = min; default is max so both peaks show

# The function to be called anytime a slider's value changes
def update(event):
    global pka1, pka2, V_a, C_a, C_b
    try:
        pka1 = pka1_slider.val
        pka2 = pka2_slider.val
        V_a = float(txtBox1.text)
        C_a = float(txtBox2.text)
        C_b = float(txtBox3.text)
        if V_a <= 0 or C_a <= 0 or C_b <= 0:
            raise ValueError
        if pka1_slider.val > pka2_slider.val:
            pka2_slider.set_val(pka1_slider.val)
        V_b, deriv, deriv_max, deriv_min = data(pka1_slider.val, pka2_slider.val, V_a, C_a, C_b)
        ax1.set_xlim([0, 3*V_a*C_a/C_b])
        ax2.set_xlim([0, 3*V_a*C_a/C_b])
        line.set_xdata(V_b)
        line2.set_xdata(V_b[1:len(V_b)-1])
        line2.set_ydata(deriv)
        if deriv_peak:
            ax2.set_ylim([-0.05*deriv_max, 1.1*deriv_max])
        if deriv_peak == False:
            ax2.set_ylim([-0.05*deriv_min, 1.1*deriv_min])
    except ValueError:
        print("Please use valid positive values for the volume of acid and the concentration of acid and base.")

def press(event): #function for the max button
    global deriv_peak
    deriv_peak = not deriv_peak
    if deriv_peak:
        ax2.set_ylim([-0.05*deriv_max, 1.1*deriv_max])
    if deriv_peak == False:
        ax2.set_ylim([-0.05*deriv_min, 1.1*deriv_min])

def data(pka1, pka2, V_a, C_a, C_b):
    pH = pH = np.linspace(0,14+np.log10(C_b),200) # range is set so it doesn't blow up!
    H = 10**(-pH) #concentration of H+ (M)
    OH = (10**(-14))/H #concentration of OH- (M)
    Ka1=10**(-pka1) #first proton Ka value
    Ka2=10**(-pka2) #second proton Ka value
    d = H**2 + Ka1*H + Ka1*Ka2 #denominator of proportions
    A_HA = (H*Ka1)/d #proportion in form HA-
    A_A = (Ka1*Ka2)/d #proportion in form A-2
    phi_n = A_HA + 2*A_A - ((H - OH)/C_a) #numerator of Harris' formula
    phi_d = 1+ ((H - OH)/C_b) #denominator of Harris' formula
    phi = phi_n / phi_d # ratio from Harris' formula
    V_b = (phi*C_a*V_a)/C_b #Volume of base added that matches the pH based on Harris' formula
    
    deriv = []
    for i in range(len(V_b)-2):
        deriv.append((pH[i+2]-pH[i])/(V_b[i+2]-V_b[i])) #derivative of titration curve based on central finite differences; skips 1st point!
    #finding derivative at equivalence points to set y limits since the low V can have a huge derivative sometimes
    diff = np.abs(V_b - V_a*C_a/C_b) #1st equivalence point is set to 0
    index = np.argsort(diff)[0]-1 #finds where lowest value is
    max1 = deriv[index] #-1 since the first point is chopped out of deriv
    diff = np.abs(V_b - 2*V_a*C_a/C_b) #2nd equivalence point is set to 0
    index = np.argsort(diff)[0]-1 #finds where lowest value is; shift of -1 so it lines up with deriv
    max2 = deriv[index]
    deriv_max = max(max1,max2)
    deriv_min = min(max1,max2)
    return V_b, deriv, deriv_max, deriv_min

#Initializing data
pH = np.linspace(0,13,200) #using the pH values to figure out the volume added; range is set so it doesn't blow up!
H = 10**(-pH) #concentration of H+ (M)
OH = (10**(-14))/H #concentration of OH- (M)
V_b, deriv, deriv_max, deriv_min = data(pka1, pka2, V_a, C_a, C_b)

#Initial plot
fig, (ax1, ax2) = plt.subplots(1,2,figsize=(15,6))
fig.subplots_adjust(bottom=0.3)
line, = ax1.plot(V_b,pH,color='b', linewidth = 2, label='Titration Curve')
ax1.set_xlabel(r'$V$ base added (mL)')
ax1.set_ylabel('pH')
ax1.set_xlim([0, 3*V_a*C_a/C_b])
ax1.grid()
line2, = ax2.plot(V_b[1:len(V_b)-1],deriv,color='r', linewidth = 2, label='Titration Curve Derivative')
ax2.set_xlabel(r'$V$ base added (mL)')
ax2.set_ylabel('Titration Curve Derivative')
ax2.set_xlim([0, 3*V_a*C_a/C_b])
ax2.set_ylim([-0.05*deriv_max, 1.1*deriv_max])
ax2.grid()

sliderax1 = fig.add_axes([0.1,0.1,0.5,0.05]) #written in terms of fractions of the window; x start, y start, x width, y width
pka1_slider = Slider(
    sliderax1,
    label=r'p$K_{a1}$',
    valmin=0,
    valmax=13,
    valinit=3)

sliderax2 = fig.add_axes([0.1,0.05,0.5,0.05])
pka2_slider = Slider(
    sliderax2,
    label=r'p$K_{a2}$',
    valmin=0,
    valmax=13,
    valinit=8)

# Switch scale to max/min button
buttonloc = fig.add_axes([0.65, 0.075, 0.1, 0.04])
button = Button(buttonloc, 'Scaling', color='cyan', hovercolor='red')
button.on_clicked(press)

#Textbox for volume of acid'
graphBox1 = fig.add_axes([0.85, 0.125, 0.1, 0.05])
txtBox1 = TextBox(graphBox1, '$V$ acid (mL) ', initial = 10.0)
txtBox1.on_submit(update)

#Textbox for concentration of acid'
graphBox2 = fig.add_axes([0.85, 0.075, 0.1, 0.05])
txtBox2 = TextBox(graphBox2, '[Acid] (M) ', initial = 0.1)
txtBox2.on_submit(update)

#Textbox for concentration of base'
graphBox3 = fig.add_axes([0.85, 0.025, 0.1, 0.05])
txtBox3 = TextBox(graphBox3, '[Base] (M) ', initial = 0.1)
txtBox3.on_submit(update)

# register the update function with each slider
pka1_slider.on_changed(update)
pka2_slider.on_changed(update)

plt.show()
