import numpy as np #import Numpy Package
import matplotlib.pyplot as plt #import matplotlib Package
from matplotlib.widgets import Button, Slider, TextBox

pka1 = 2.0 #initial
pka2 = 5.0
pka3 = 8.0
V_a = 10 #volume of acid being titrated (mL)
C_a = 0.1 #concentration of acid (M)
C_b = 0.1 #concentration of base (M)

# The function to be called anytime a slider's value changes
def update(event):
    global pka1, pka2, pka3, V_a, C_a, C_b
    try:
        pka1 = pka1_slider.val
        pka2 = pka2_slider.val
        pka3 = pka3_slider.val
        V_a = float(txtBox1.text)
        C_a = float(txtBox2.text)
        C_b = float(txtBox3.text)
        if V_a <= 0 or C_a <= 0 or C_b <= 0:
            raise ValueError
        if pka1_slider.val > pka2_slider.val:
            pka2_slider.set_val(pka1_slider.val)
        if pka2_slider.val > pka3_slider.val:
            pka3_slider.set_val(pka2_slider.val)
        V_b, C_H3A, C_H2Amin, C_HAmin2, C_Amin3 = data(pka1, pka2, pka3, V_a, C_a, C_b)
        line.set_xdata(V_b)
        ax1.set_xlim([0, 4*V_a*C_a/C_b])
        line2.set_xdata(V_b)
        line2.set_ydata(C_H3A)
        line3.set_xdata(V_b)
        line3.set_ydata(C_H2Amin)
        line4.set_xdata(V_b)
        line4.set_ydata(C_HAmin2)
        line5.set_xdata(V_b)
        line5.set_ydata(C_Amin3)
        ax2.set_xlim([0, 4*V_a*C_a/C_b])
        ax2.set_ylim([-0.05*C_a, 1.05*C_a])
    except ValueError:
        print("Please use valid positive values for the volume of acid and the concentration of acid and base.")

def data(pka1, pka2, pka3, V_a, C_a, C_b):
    pH = pH = np.linspace(0,14+np.log10(C_b),200) # range is set so it doesn't blow up!
    H = 10**(-pH) #concentration of H+ (M)
    OH = (10**(-14))/H #concentration of OH- (M)
    Ka1=10**(-pka1) #first proton Ka value
    Ka2=10**(-pka2) #second proton Ka value
    Ka3=10**(-pka3) #third proton Ka value
    d = H**3 + Ka1*H**2 + Ka1*Ka2*H + Ka1*Ka2*Ka3 #denominator of proportions
    A_H2A = (H**2*Ka1)/d #proportion in form H2A-
    A_HA = (H*Ka1*Ka2)/d #proportion in form HA-2
    A_A = (Ka1*Ka2*Ka3)/d #proportion in form A-3
    phi_n = A_H2A + 2*A_HA + 3*A_A - ((H - OH)/C_a) # Numerator from Harris' formula
    phi_d = 1 + ((H - OH)/C_b) # demoninator of Harris' formula
    phi = phi_n / phi_d # ratio from Harris' formula
    V_b = (phi*C_a*V_a)/C_b #Volume of base added that matches the pH based on Harris

    C_H3A = C_a*V_a/(V_a+V_b)*(1 + 10**(pH-pka1) + 10**(2*pH-pka1-pka2) + 10**(3*pH-pka1-pka2-pka3))**-1
    C_H2Amin = C_H3A*10**(pH-pka1)
    C_HAmin2 = C_H3A*10**(2*pH-pka1-pka2)
    C_Amin3 = C_a*V_a/(V_a+V_b) - C_H3A - C_H2Amin - C_HAmin2
    return V_b, C_H3A, C_H2Amin, C_HAmin2, C_Amin3

#Initializing data
pH = np.linspace(0,13,200) #using the pH values to figure out the volume added; range is set so it doesn't blow up!
H = 10**(-pH) #concentration of H+ (M)
OH = (10**(-14))/H #concentration of OH- (M)
V_b, C_H3A, C_H2Amin, C_HAmin2, C_Amin3 = data(pka1, pka2, pka3, V_a, C_a, C_b)

#Initial plot
fig, (ax1, ax2) = plt.subplots(1,2,figsize=(15,6))
fig.subplots_adjust(bottom=0.3)
line, = ax1.plot(V_b,pH,color='b', linewidth = 2, label='Titration Curve')
ax1.set_xlabel(r'$V$ base added (mL)')
ax1.set_ylabel('pH')
ax1.set_xlim([0, 4*V_a*C_a/C_b])
ax1.grid()
line2, = ax2.plot(V_b, C_H3A, color='r', linewidth = 2, label=r'[H$_3$A] (M)')
line3, = ax2.plot(V_b, C_H2Amin, color='r', linewidth = 2, linestyle = '--', label=r'[H$_2$A$^-$] (M)')
line4, = ax2.plot(V_b, C_HAmin2, color='r', linewidth = 2, linestyle = ':', label=r'[HA$^{2-}$] (M)')
line5, = ax2.plot(V_b, C_Amin3, color='r', linewidth = 2, linestyle = '-.', label=r'[A$^{3-}$] (M)')
ax2.set_xlabel(r'$V$ base added (mL)')
ax2.set_ylabel('Species Concentration (M)')
ax2.set_xlim([0, 4*V_a*C_a/C_b])
ax2.set_ylim([-0.05*C_a, 1.05*C_a])
ax2.grid()
ax2.legend()

sliderax1 = fig.add_axes([0.1,0.15,0.6,0.05]) #written in terms of fractions of the window; x start, y start, x width, y width
pka1_slider = Slider(
    sliderax1,
    label=r'p$K_{a1}$',
    valmin=0,
    valmax=13,
    valinit=2)

sliderax2 = fig.add_axes([0.1,0.1,0.6,0.05])
pka2_slider = Slider(
    sliderax2,
    label=r'p$K_{a2}$',
    valmin=0,
    valmax=13,
    valinit=5)

sliderax3 = fig.add_axes([0.1,0.05,0.6,0.05])
pka3_slider = Slider(
    sliderax3,
    label=r'p$K_{a3}$',
    valmin=0,
    valmax=13,
    valinit=8)

#Textbox for volume of acid'
graphBox1 = fig.add_axes([0.85, 0.15, 0.1, 0.05])
txtBox1 = TextBox(graphBox1, '$V$ acid (mL) ', initial = 10.0)
txtBox1.on_submit(update)

#Textbox for concentration of acid'
graphBox2 = fig.add_axes([0.85, 0.1, 0.1, 0.05])
txtBox2 = TextBox(graphBox2, '[Acid] (M) ', initial = 0.1)
txtBox2.on_submit(update)

#Textbox for concentration of base'
graphBox3 = fig.add_axes([0.85, 0.05, 0.1, 0.05])
txtBox3 = TextBox(graphBox3, '[Base] (M) ', initial = 0.1)
txtBox3.on_submit(update)

# register the update function with each slider
pka1_slider.on_changed(update)
pka2_slider.on_changed(update)
pka3_slider.on_changed(update)

plt.show()
