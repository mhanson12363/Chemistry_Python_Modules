import numpy as np
import matplotlib
import matplotlib.pyplot as plt
from matplotlib.widgets import TextBox, Button

params ={'1. Sublimation Energy (kJ/mol) ': 89, # default values are for KI
         '2. Ionization Energy (kJ/mol) ': 419,
         '3. Phase Energy (kJ/mol) ': 57, 
         '4. Dissociation Energy (kJ/mol) ': 151,
         '5. Electron Affinity (kJ/mol) ': -295,
         'Total Formation Energy (kJ/mol) ': -328,
         r'Metal coefficient ' : 1,
         r'Non-metal coefficient ' : 1 ,
         'Metal symbol ': 'K',
         'Non-metal symbol ' : 'I'}

fig, ax = plt.subplots(figsize=(10, 6))
plt.subplots_adjust(left=0.4, bottom = 0.3)
ax.set_xticks([])

x_position = 0.25
y_start = 0.05
y_step = 0.125

text_boxes = {}
box_positions = {'1. Sublimation Energy (kJ/mol) ': (x_position, y_start+1*y_step, 0.06, 0.05),
                 '2. Ionization Energy (kJ/mol) ': (x_position, y_start+2*y_step, 0.06, 0.05),
                 '3. Phase Energy (kJ/mol) ': (x_position, y_start+3*y_step, 0.06, 0.05),
                 '4. Dissociation Energy (kJ/mol) ': (x_position, y_start+4*y_step, 0.06, 0.05),
                 '5. Electron Affinity (kJ/mol) ': (x_position, y_start+5*y_step, 0.06, 0.05),
                 'Total Formation Energy (kJ/mol) ': (x_position, y_start+6*y_step, 0.06, 0.05),
                 'Metal coefficient ' :  (0.5, 0.05, 0.06, 0.05),
                 'Non-metal coefficient ' :  (0.75, 0.05, 0.06, 0.05),
                 'Metal symbol ' :  (0.5, 0.15, 0.06, 0.05),
                 'Non-metal symbol ' :  (0.75, 0.15, 0.06, 0.05) }

for key, pos in box_positions.items():
    ax_box = plt.axes(pos)
    text_box = TextBox(ax_box, key, initial=str(params[key]))
    text_boxes[key] = text_box

def Born_Haber(params):
    total = 0 # running total of energy for each step with stoichiometry accounted for
    total_list = [0]
    total += params[r'Metal coefficient ']*params['1. Sublimation Energy (kJ/mol) ']
    total_list.append(total)
    total += params[r'Metal coefficient ']*params['2. Ionization Energy (kJ/mol) ']
    total_list.append(total)
    if params['3. Phase Energy (kJ/mol) '] != 0: # only includes a phase transition if there is one needed
        total += params[r'Non-metal coefficient ']*params['3. Phase Energy (kJ/mol) ']
        total_list.append(total)
    total += 0.5*params[r'Non-metal coefficient ']*params['4. Dissociation Energy (kJ/mol) ']
    total_list.append(total)
    total += params[r'Non-metal coefficient ']*params['5. Electron Affinity (kJ/mol) ']
    total_list.append(total)
    total = params['Total Formation Energy (kJ/mol) ']
    total_list.append(total)
    E_lattice = (params['Total Formation Energy (kJ/mol) '] - params[r'Metal coefficient ']*params['1. Sublimation Energy (kJ/mol) ']
                 - params[r'Metal coefficient ']*params['2. Ionization Energy (kJ/mol) '] - params[r'Non-metal coefficient ']*params['3. Phase Energy (kJ/mol) ']
                 - 0.5*params[r'Non-metal coefficient ']*params['4. Dissociation Energy (kJ/mol) '] - params[r'Non-metal coefficient ']*params['5. Electron Affinity (kJ/mol) '] )
    return E_lattice, total_list

def submit(event):
    try:
        for key in params:
            if key != 'Metal symbol ' and key != 'Non-metal symbol ':
                params[key] = float(text_boxes[key].text) # updates the values of params to be the current text box values
            else:
                params[key] = text_boxes[key].text 
        if (params['1. Sublimation Energy (kJ/mol) '] <= 0 or params['2. Ionization Energy (kJ/mol) '] <= 0
            or params['3. Phase Energy (kJ/mol) '] < 0 or params['Total Formation Energy (kJ/mol) '] >= 0
            or params[r'Metal coefficient ']%1 != 0 or params[r'Non-metal coefficient ']%1 != 0 or params[r'Metal coefficient '] <= 0 or params[r'Non-metal coefficient '] <= 0):
            raise ValueError
        E_lattice, total_list = Born_Haber(params)
        ax.clear()
        M_name = params['Metal symbol ']
        N_name = params['Non-metal symbol ']
        a_coeff = int(params[r'Metal coefficient '])
        b_coeff = int(params[r'Non-metal coefficient '])
        if a_coeff == 1 and b_coeff == 1:
            Comp_name = rf'{M_name}{N_name}'
            ax.set_title(r'Born-Haber cycle for the formation of 1 mol of ' + Comp_name )
        if a_coeff != 1 and b_coeff == 1:
            Comp_name = rf'{M_name}$_{a_coeff}${N_name}'
            ax.set_title(r'Born-Haber cycle for the formation of 1 mol of ' + Comp_name )
        if a_coeff == 1 and b_coeff != 1:
            Comp_name = rf'{M_name}{N_name}$_{b_coeff}$'
            ax.set_title(r'Born-Haber cycle for the formation of 1 mol of ' + Comp_name )
        if a_coeff != 1 and b_coeff != 1:
            Comp_name = rf'{M_name}$_{a_coeff}${N_name}$_{b_coeff}$'
            ax.set_title(r'Born-Haber cycle for the formation of 1 mol of ' + Comp_name )
        ax.set_xticks([])
        ax.set_ylabel("Energy (kJ/mol)")
        ax.set_xlim([-1,4])
        ax.set_ylim([min(total_list) - 0.2*(max(total_list)-min(total_list)), max(total_list) + 0.1*(max(total_list)-min(total_list))])
        E_lattice_text.set_text(f"Lattice Energy (kJ/mol): {E_lattice}")
        for i in range(len(total_list)):
            if params['3. Phase Energy (kJ/mol) '] == 0: # if the non-metal is already in the gas phase normally 
                if i < 3: # first two entries are plotted on the left side 
                    ax.plot([0,1], [total_list[i], total_list[i]], color = 'k')
                    if total_list[i+1]-total_list[i] != 0: # doesn't plot an arrow with no height! 
                        ax.quiver(0.3+i*0.2, total_list[i], 0, total_list[i+1]-total_list[i], color = 'r', angles='xy', scale_units='xy', scale=1)
                if i == 3 or i == 5: # top and bottom lines are longer 
                    ax.plot([0,3], [total_list[i], total_list[i]], color = 'k')
                if i == 4: # fourth line is on the right side
                    ax.plot([2,3], [total_list[i], total_list[i]], color = 'k')
                    if params['5. Electron Affinity (kJ/mol) '] < 0: # typically negative, but not always!
                        ax.quiver(2.3, total_list[i-1], 0, -(total_list[i-1]-total_list[i]), color = 'b', angles='xy', scale_units='xy', scale=1)
                    else:
                        ax.quiver(2.3, total_list[i-1], 0, -(total_list[i-1]-total_list[i]), color = 'r', angles='xy', scale_units='xy', scale=1)
                if i == 5:
                    ax.quiver(0.5, 0, 0, total_list[i], color = 'b', angles='xy', scale_units='xy', scale=1)
                    ax.quiver(2.7, total_list[i-1], 0, -(total_list[i-1]-total_list[i]), color = 'b', angles='xy', scale_units='xy', scale=1)
                React_text = ax.text(1.2, 0, "Elements", fontsize = 12, color = 'k')
                Prod_text = ax.text(1.2, params['Total Formation Energy (kJ/mol) '] - 0.1*(max(total_list)-min(total_list)), Comp_name + " (s)", fontsize = 12, color = 'k')
                Step1_text = ax.text(-0.5, total_list[1]/2, r"$\Delta E_1$", fontsize = 12, color = 'r')
                Step2_text = ax.text(-0.5, (total_list[2]-total_list[1])/2 + total_list[1], r"$\Delta E_2$", fontsize = 12, color = 'r')
                if total_list[3]-total_list[2] != 0: # only plots arrow if we need a dissociation energy! 
                    Step4_text = ax.text(-0.5, (total_list[3]-total_list[2])/2 + total_list[2], r"$\Delta E_4$", fontsize = 12, color = 'r')
                Step5_text = ax.text(3.1, (total_list[4]-total_list[3])/2 + total_list[3], r"$\Delta E_5$", fontsize = 12, color = 'b')
                Step6_text = ax.text(3.1, (total_list[5]-total_list[4])/2 + total_list[4], r"$\Delta E_{lattice}$", fontsize = 12, color = 'b')
                Total_text = ax.text(-0.7, total_list[5]/2, r"$\Delta E_{Total}$", fontsize = 12, color = 'b')
            else: # if vaporization of the non metal is needed there are extra steps 
                if i < 4: # first two entries are plotted on the left side 
                    ax.plot([0,1], [total_list[i], total_list[i]], color = 'k')
                    if total_list[i+1]-total_list[i] != 0: # doesn't plot an arrow with no height! 
                        ax.quiver(0.3+i*0.2, total_list[i], 0, total_list[i+1]-total_list[i], color = 'r', angles='xy', scale_units='xy', scale=1)
                if i == 4 or i == 6: # top and bottom lines are longer 
                    ax.plot([0,3], [total_list[i], total_list[i]], color = 'k')
                if i == 5: # fourth line is on the right side
                    ax.plot([2,3], [total_list[i], total_list[i]], color = 'k')
                    if params['5. Electron Affinity (kJ/mol) '] < 0: # typically negative, but not always!
                        ax.quiver(2.3, total_list[i-1], 0, -(total_list[i-1]-total_list[i]), color = 'b', angles='xy', scale_units='xy', scale=1)
                    else:
                        ax.quiver(2.3, total_list[i-1], 0, -(total_list[i-1]-total_list[i]), color = 'r', angles='xy', scale_units='xy', scale=1)
                if i == 6:
                    ax.quiver(0.5, 0, 0, total_list[i], color = 'b', angles='xy', scale_units='xy', scale=1)
                    ax.quiver(2.7, total_list[i-1], 0, -(total_list[i-1]-total_list[i]), color = 'b', angles='xy', scale_units='xy', scale=1)
                React_text = ax.text(1.2, 0, "Elements", fontsize = 12, color = 'k')
                Prod_text = ax.text(1.2, params['Total Formation Energy (kJ/mol) '] - 0.1*(max(total_list)-min(total_list)), Comp_name + " (s)", fontsize = 12, color = 'k')
                Step1_text = ax.text(-0.5, total_list[1]/2, r"$\Delta E_1$", fontsize = 12, color = 'r')
                Step2_text = ax.text(-0.5, (total_list[2]-total_list[1])/2 + total_list[1], r"$\Delta E_2$", fontsize = 12, color = 'r')
                Step3_text = ax.text(-0.5, (total_list[3]-total_list[2])/2 + total_list[2], r"$\Delta E_3$", fontsize = 12, color = 'r')
                if total_list[4]-total_list[3] != 0: # only plots arrow if we need a dissociation energy! 
                    Step4_text = ax.text(-0.5, (total_list[4]-total_list[3])/2 + total_list[3], r"$\Delta E_4$", fontsize = 12, color = 'r')
                Step5_text = ax.text(3.1, (total_list[5]-total_list[4])/2 + total_list[4], r"$\Delta E_5$", fontsize = 12, color = 'b')
                Step6_text = ax.text(3.1, (total_list[6]-total_list[5])/2 + total_list[5], r"$\Delta E_{lattice}$", fontsize = 12, color = 'b')
                Total_text = ax.text(-0.7, total_list[6]/2, r"$\Delta E_{Total}$", fontsize = 12, color = 'b')

        ex1_text = fig.text(0.1, y_start+0.7*y_step, r"ex. K (s) $\longrightarrow$ K (g)")
        ex2_text = fig.text(0.1, y_start+1.7*y_step, r"ex. K (g) $\longrightarrow$ K$^+$ (g)")
        ex3_text = fig.text(0.1, y_start+2.7*y_step, r"ex. I$_2$ (s) $\longrightarrow$ I$_2$ (g)")
        ex4_text = fig.text(0.1, y_start+3.7*y_step, r"ex. I$_2$ (g) $\longrightarrow$ 2 I (g)")
        ex5_text = fig.text(0.1, y_start+4.7*y_step, r"ex. I (g) $\longrightarrow$ I$^-$ (g)")
        ex6_text = fig.text(0.1, y_start+5.7*y_step, r"ex. I$_2$ (g) + K (s) $\longrightarrow$ KI (s)")
        ex7_text = fig.text(0.1, y_start+6.7*y_step, r"ex. I$^-$ (g) + K$^+$ (g) $\longrightarrow$ KI (s)")
        fig.canvas.draw_idle() # forces the redraw
    except ValueError:
        print('All entries must be physically possible numbers. Dissociation energies, ionization energies, and sublimation energies must be positive.')
        print('Electron affinities are generally negative in this convention and the overall formation energy is also generally negative.' + '\n')

button_ax = plt.axes([0.1, 0.05, 0.2, 0.05])
button = Button(button_ax, 'Generate Cycle')
button.on_clicked(submit)

E_lattice, total_list = Born_Haber(params)

E_lattice_text = fig.text(0.085, y_start+7.2*y_step, f"Lattice Energy (kJ/mol): {E_lattice}")

submit(1)

plt.show()
