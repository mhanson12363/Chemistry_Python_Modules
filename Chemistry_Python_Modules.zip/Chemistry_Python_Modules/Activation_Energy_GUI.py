import numpy as np #import numpy package for handling arrays
import matplotlib.pyplot as plt #import matplotlib package for handling plotting
from matplotlib.widgets import Button, Slider, TextBox #lets us make the desired widgets

valid = False #initializes so the first call will happen
token = 0 #just initializes at a benign value
def get_token(): #allows neatly looping the program and 'talking' to the user
    valid = False #intitialized as False so the program will seek a valid value
    while valid == False: #keeps looping this until the user provides a valid token
        try: #only works if the user puts something that can be interpreted as an integer
            token = int(input('Which option would you like to use? Enter 0 for options: '))
            if (token in [i+1 for i in range(6)]):
                valid = True
            if token == 0: #lists out the options
                print('The following options are available for plots illustrating the activation energy:' + '\n')
                print('Enter 1:' + ' '*5 + '1 activation energy,' + ' '*3 + '0 intermediates, no catalysts')
                print('Enter 2:' + ' '*5 + '2 activation energies, 1 intermediate,  no catalysts')
                print('Enter 3:' + ' '*5 + '3 activation energies, 2 intermediates, no catalysts')
                print('Enter 4:' + ' '*5 + '1 activation energy,' + ' '*3 + '0 intermediates, with a catalyst')
                print('Enter 5:' + ' '*5 + '2 activation energies, 1 intermediate,  with a catalyst')
                print('Enter 6:' + ' '*5 + '3 activation energies, 2 intermediates, with a catalyst')
                print('Enter -1:' + ' '*4 + 'Ends the program' + '\n')
            if (token not in [i+1 for i in range(6)]) and (token != -1):
                valid = False
                print('Please enter a valid integer from 1-6 or -1 to quit the program.' + '\n')
            if token == -1:
                valid = True #lets the loop inside the function end
                print('Terminating program')
        except: #yells at the user for putting in an invalid entry
            valid = False
            print('Please enter a valid integer from 1-6 or -1 to quit the program.' + '\n')
    return token, valid

#tells the user the options right away so they don't have to ask for them
print('The following options are available for plots illustrating the activation energy:' + '\n')
print('Enter 1:' + ' '*5 + '1 activation energy,' + ' '*3 + '0 intermediates, no catalysts')
print('Enter 2:' + ' '*5 + '2 activation energies, 1 intermediate,  no catalysts')
print('Enter 3:' + ' '*5 + '3 activation energies, 2 intermediates, no catalysts')
print('Enter 4:' + ' '*5 + '1 activation energy,' + ' '*3 + '0 intermediates, with a catalyst')
print('Enter 5:' + ' '*5 + '2 activation energies, 1 intermediate,  with a catalyst')
print('Enter 6:' + ' '*5 + '3 activation energies, 2 intermediates, with a catalyst')
print('Enter -1:' + ' '*4 + 'Ends the program' + '\n')

while (valid or valid == False) and (token != -1): #runs the programs until the user decides to kill the process by setting token = -1
    token, valid = get_token() #continues the loop
    if token == 1: 
    #############
    # Program 1 #
    #############
        Ea = 100 #initial activation energy
        Ereact = 200 #initial energy of reactants (kJ/mol)
        Eprod = 0 #intitial energy of products (kJ/mol)
        Emax = 500 # Maximum slider values for energies
        w = 250 #width parameter for Gaussian function; big makes it wide, small makes it narrow
        coord = np.linspace(0,100,1001) #gives reaction coordinate as a % of reaction progress

        # The function to be called anytime a slider's value changes
        def update(event):
            global Ea, Ereact, Eprod, w, Emax
            try:
                Ea = Ea_slider.val
                Ereact = Ereact_slider.val
                Eprod = Eprod_slider.val
                w = w_slider.val
                Emax = int(text_box.text)
                if Emax < Ea or Emax < Ereact or Emax < Eprod:
                    raise ValueError
                Ea_slider.ax.set_xlim(0, Emax)
                Ea_slider.valmax = Emax
                Ereact_slider.ax.set_xlim(0, Emax)
                Ereact_slider.valmax = Emax
                Eprod_slider.ax.set_xlim(0, Emax)
                Eprod_slider.valmax = Emax 
                if Ereact+Ea < Eprod: # activation energy needs to be enough to reach the products!
                    Ea = Eprod-Ereact
                    Ea_slider.set_val(Eprod-Ereact)
                curve = data(Ereact, Eprod, Ea, w)
                if max(curve) != 0:
                    ax.set_ylim([-0.05*max(curve), 1.05*max(curve)])
                line.set_ydata(curve)
            except ValueError:
                print("The maximum energy for sliders must be higher than the current largest value used on the sliders.")

        def data(Ereact, Eprod, Ea, w):
            Gaussian1 = Ea*np.exp(-(coord-50)**2/w)+Ereact #Gaussian for the first part of the curve
            Gaussian2 = (Ea+Ereact-Eprod)*np.exp(-(coord-50)**2/w) + Eprod #Gaussian for the second part of the curve
            curve = Gaussian1 #starts off by making the curve the whole of the first Gaussian
            index = np.where(coord == 50)[0][0] #finds where the peak is
            curve[index::] = Gaussian2[index::] #makes the last half of the curve the second Gaussian
            return curve

        #Initializing data
        coord = np.linspace(0,100,1001) #gives reaction coordinate as a %
        curve = data(Ereact, Eprod, Ea, w)

        #Initial plot
        fig, ax = plt.subplots(figsize=(10,8))
        fig.subplots_adjust(bottom=0.3)
        line, = ax.plot(coord,curve,color='b', linewidth = 2, label='Arrhenius Curve')
        #matplotlib.rcParams.update({'font.size': 16})
        ax.set_xlabel('Reaction progress (%)')
        ax.set_ylabel('Energy (kJ/mol)')
        ax.set_xlim([0, 100])
        if max(curve) != 0:
            ax.set_ylim([-0.05*max(curve), 1.05*max(curve)])
        plt.grid()

        #Slider for the Ea values
        Ea_ax = fig.add_axes([0.15,0.2,0.5,0.05]) #written in terms of fractions of the window; x start, y start, x width, y width
        Ea_slider = Slider(
            Ea_ax,
            label=r'$E_a$ (kJ/mol)',
            valmin=0,
            valmax=Emax,
            valstep = 1,
            valinit=Ea,
            facecolor = 'b',
            track_color = 'b')

        Ereact_ax = fig.add_axes([0.15,0.15,0.5,0.05]) #written in terms of fractions of the window; x start, y start, x width, y width
        Ereact_slider = Slider(
            Ereact_ax,
            label=r'$E_{react}$ (kJ/mol)',
            valmin=0,
            valmax=Emax,
            valstep = 1,
            valinit=Ereact,
            facecolor = 'b',
            track_color = 'b')

        Eprod_ax = fig.add_axes([0.15,0.1,0.5,0.05]) #written in terms of fractions of the window; x start, y start, x width, y width
        Eprod_slider = Slider(
            Eprod_ax,
            label=r'$E_{prod}$ (kJ/mol)',
            valmin=0,
            valmax=Emax,
            valstep = 1,
            valinit=Eprod,
            facecolor = 'b',
            track_color = 'b')

        w_ax = fig.add_axes([0.15,0.025,0.5,0.05]) #written in terms of fractions of the window; x start, y start, x width, y width
        w_slider = Slider(
            w_ax,
            label=r'$w$',
            valmin=1,
            valmax=500,
            valstep = 1,
            valinit=w,
            facecolor = 'b',
            track_color = 'b')

        axbox = plt.axes([0.8,0.025,0.1,0.06])
        text_box = TextBox(axbox, r'Slider Max', initial = Emax, label_pad = 0.05)

        # register the update function with each slider
        Ea_slider.on_changed(update)
        Ereact_slider.on_changed(update)
        Eprod_slider.on_changed(update)
        w_slider.on_changed(update)
        text_box.on_submit(update)

        plt.show()
    #################
    # Program 1 end #
    #################

    if token == 2:
    #############
    # Program 2 #
    #############
        Ea1 = 200 #initial activation energy for 1st step
        Ea2 = 100 #initial activation energy for 2nd step
        Einter = 100 #energy of the intermediate species
        Ereact = 200 #Relative energy of reactant (kJ/mol)
        Eprod = 0 #Relative energy of product (kJ/mol)
        w = 50 #width parameter for Gaussian function
        Emax = 500 

        # The function to be called anytime a slider's value changes
        def update(val):
            global Ea1, Ea2, Einter, Ereact, Eprod, w, Emax
            try:
                Ea1 = Ea1_slider.val
                Ea2 = Ea2_slider.val
                Einter = Einter_slider.val
                Ereact = Ereact_slider.val
                Eprod = Eprod_slider.val
                w = w_slider.val
                Emax = int(text_box.text)
                if Emax < Ea1 or Emax < Ea2 or Emax < Ereact or Emax < Eprod:
                    raise ValueError
                Ea1_slider.ax.set_xlim(0, Emax)
                Ea1_slider.valmax = Emax
                Ea2_slider.ax.set_xlim(0, Emax)
                Ea2_slider.valmax = Emax
                Einter_slider.ax.set_xlim(0, Emax)
                Einter_slider.valmax = Emax
                Ereact_slider.ax.set_xlim(0, Emax)
                Ereact_slider.valmax = Emax
                Eprod_slider.ax.set_xlim(0, Emax)
                Eprod_slider.valmax = Emax 
                if Einter > Ea1+Ereact:
                    Einter = Ea1+Ereact
                    Einter_slider.set_val(Ea1+Ereact)
                if Einter+Ea2 < Eprod: # activation energy needs to be enough to reach the products!
                    Ea2 = Eprod-Einter
                    Ea2_slider.set_val(Eprod-Einter)
                curve = data(Ereact, Eprod, Ea1, Ea2, Einter, w)
                if max(curve) != 0:
                    ax.set_ylim([-0.05*max(curve), 1.05*max(curve)])
                line.set_ydata(curve)
            except ValueError:
                print("The maximum energy for sliders must be higher than the current largest value used on the sliders.")

        def data(Ereact, Eprod, Ea1, Ea2, Einter, w):
            Gaussian1 = Ea1*np.exp(-(coord-33)**2/w)+Ereact #Gaussian for the first part of the curve
            Gaussian2 = (Ea1+Ereact-Einter)*np.exp(-(coord-33)**2/w) #first Gaussian for the second part of the curve
            Gaussian3 = Ea2*np.exp(-(coord-67)**2/w)+Einter #second Gaussian for the second part of the curve
            Gaussian4 = (Ea2+Einter-Eprod)*np.exp(-(coord-67)**2/w)+Eprod #Gaussian for the final part of the curve
            peak1_index = np.where(coord == 33)[0][0] #finds peak of first Gaussian
            peak2_index = np.where(coord == 67)[0][0] #finds peak of last Gaussian
            curve = np.zeros(len(coord))
            curve[0:peak1_index] = Gaussian1[0:peak1_index] #starts off by making the first bit of the curve
            curve[peak1_index:peak2_index] = Gaussian2[peak1_index:peak2_index] + Gaussian3[peak1_index:peak2_index] #makes the final piece of the curve the final Gaussian
            curve[peak2_index::] = Gaussian4[peak2_index::] #makes the final piece of the curve the final Gaussian
            return curve

        #Initializing data
        coord = np.linspace(0,100,1001) #gives reaction coordinate as a %
        curve = data(Ereact, Eprod, Ea1, Ea2, Einter, w)

        #Initial plot
        fig, ax = plt.subplots(figsize=(10,8))
        fig.subplots_adjust(bottom=0.3)
        line, = ax.plot(coord,curve,color='b', linewidth = 2, label='Arrhenius Curve')
        #matplotlib.rcParams.update({'font.size': 16})
        ax.set_xlabel('Reaction progress (%)')
        ax.set_ylabel('Energy (kJ/mol)')
        ax.set_xlim([0, 100])
        if max(curve) != 0:
            ax.set_ylim([-0.05*max(curve), 1.05*max(curve)])
        #plt.legend() #hidden when making plots for tests
        plt.grid()

        #Sliders 
        sliderax = fig.add_axes([0.15,0.2,0.3,0.05]) #written in terms of fractions of the window; x start, y start, x width, y width
        Ea1_slider = Slider(
            sliderax,
            label=r'$E_{a1}$ (kJ/mol)',
            valmin=0,
            valmax=Emax,
            valinit=Ea1,
            valstep = 1,
            facecolor = 'b',
            track_color = 'b')

        sliderax2 = fig.add_axes([0.15,0.15,0.3,0.05]) #written in terms of fractions of the window; x start, y start, x width, y width
        Ea2_slider = Slider(
            sliderax2,
            label=r'$E_{a2}$ (kJ/mol)',
            valmin=0,
            valmax=Emax,
            valinit=Ea2,
            valstep = 1,
            facecolor = 'b',
            track_color = 'b')

        sliderax3 = fig.add_axes([0.15,0.1,0.3,0.05]) #written in terms of fractions of the window; x start, y start, x width, y width
        Einter_slider = Slider(
            sliderax3,
            label=r'$E_{inter}$ (kJ/mol)',
            valmin=0,
            valmax=Emax,
            valinit=Einter,
            valstep = 1,
            facecolor = 'b',
            track_color = 'b')

        w_ax = fig.add_axes([0.15,0.025,0.3,0.05]) #written in terms of fractions of the window; x start, y start, x width, y width
        w_slider = Slider(
            w_ax,
            label=r'$w$',
            valmin=1,
            valmax=200,
            valstep = 1,
            valinit=w,
            facecolor = 'b',
            track_color = 'b')

        Ereact_ax = fig.add_axes([0.6,0.2,0.3,0.05]) #written in terms of fractions of the window; x start, y start, x width, y width
        Ereact_slider = Slider(
            Ereact_ax,
            label=r'$E_{react}$ (kJ/mol)',
            valmin=0,
            valmax=500,
            valstep = 1,
            valinit=Ereact,
            facecolor = 'b',
            track_color = 'b')

        Eprod_ax = fig.add_axes([0.6,0.15,0.3,0.05]) #written in terms of fractions of the window; x start, y start, x width, y width
        Eprod_slider = Slider(
            Eprod_ax,
            label=r'$E_{prod}$ (kJ/mol)',
            valmin=0,
            valmax=Emax,
            valstep = 1,
            valinit=Eprod,
            facecolor = 'b',
            track_color = 'b')

        axbox = plt.axes([0.6,0.025,0.1,0.05])
        text_box = TextBox(axbox, r'Slider Max', initial = Emax, label_pad = 0.05)

        # register the update function with each slider
        Ea1_slider.on_changed(update)
        Ea2_slider.on_changed(update)
        Einter_slider.on_changed(update)
        Ereact_slider.on_changed(update)
        Eprod_slider.on_changed(update)
        w_slider.on_changed(update)
        text_box.on_submit(update)

        plt.show() 
    #################
    # Program 2 end #
    #################

    if token == 3:
    #############
    # Program 3 #
    #############
        Ea1 = 150 #initial activation energy for 1st step
        Ea2 = 150 #initial activation energy for 2nd step
        Ea3 = 100 #initial activation energy for 3rd step
        Einter1 = 100 #energy of the first intermediate species
        Einter2 = 150 #energy of the second intermediate species
        Ereact = 0 #Relative energy of reactant (kJ/mol)
        Eprod = 100 #Relative energy of product (kJ/mol)
        w = 30 #width parameter for Gaussian function
        Emax = 500 

        # The function to be called anytime a slider's value changes
        def update(val):
            global Ea1, Ea2, Ea3, Einter1, Einter2, Ereact, Eprod, w, Emax
            try:
                Ea1 = Ea1_slider.val
                Ea2 = Ea2_slider.val
                Ea3 = Ea3_slider.val
                Einter1 = Einter1_slider.val
                Einter2 = Einter2_slider.val
                Ereact = Ereact_slider.val
                Eprod = Eprod_slider.val
                w = w_slider.val
                Emax = int(text_box.text)
                if Emax < Ea1 or Emax < Ea2 or Emax < Ea3 or Emax < Ereact or Emax < Eprod:
                    raise ValueError
                Ea1_slider.ax.set_xlim(0, Emax)
                Ea1_slider.valmax = Emax
                Ea2_slider.ax.set_xlim(0, Emax)
                Ea2_slider.valmax = Emax
                Ea3_slider.ax.set_xlim(0, Emax)
                Ea3_slider.valmax = Emax
                Einter1_slider.ax.set_xlim(0, Emax)
                Einter1_slider.valmax = Emax
                Einter2_slider.ax.set_xlim(0, Emax)
                Einter2_slider.valmax = Emax
                Ereact_slider.ax.set_xlim(0, Emax)
                Ereact_slider.valmax = Emax
                Eprod_slider.ax.set_xlim(0, Emax)
                Eprod_slider.valmax = Emax 
                if Einter1 > Ea1+Ereact:
                    Einter1 = Ea1+Ereact
                    Einter1_slider.set_val(Ea1+Ereact)
                if Einter1+Ea2 < Einter1: # activation energy needs to be enough to reach the intermediate!
                    Ea2 = Einter2-Einter1
                    Ea2_slider.set_val(Einter2-Einter1)
                if Einter2 > Ea2+Einter1:
                    Einter2 = Ea2+Einter1
                    Einter2_slider.set_val(Ea2+Einter1)
                if Einter2+Ea3 < Eprod: # activation energy needs to be enough to reach the intermediate!
                    Ea3 = Eprod-Einter2
                    Ea3_slider.set_val(Eprod-Einter2)
                curve = data(Ereact, Eprod, Ea1, Ea2, Ea3, Einter1, Einter2, w)
                ax.set_ylim([-0.05*max(curve), 1.05*max(curve)])
                line.set_ydata(curve)
            except ValueError:
                print("The maximum energy for sliders must be higher than the current largest value used on the sliders.")

        def data(Ereact, Eprod, Ea1, Ea2, Ea3, Einter1, Einter2, w):
            Gaussian1 = Ea1*np.exp(-(coord-25)**2/w)+Ereact #Gaussian for the first part of the curve
            Gaussian2 = (Ea1+Ereact-Einter1)*np.exp(-(coord-25)**2/w) #first Gaussian for the second part of the curve
            Gaussian3 = Ea2*np.exp(-(coord-50)**2/w)+Einter1 #second Gaussian for the second part of the curve
            Gaussian4 = (Ea2+Einter1-Einter2)*np.exp(-(coord-50)**2/w) #first Gaussian for the third part of the curve
            Gaussian5 = Ea3*np.exp(-(coord-75)**2/w) + Einter2 #second Gaussian for the third part of the curve
            Gaussian6 = (Ea3+Einter2-Eprod)*np.exp(-(coord-75)**2/w)+Eprod #Gaussian for the final part of the curve
            peak1_index = np.where(coord == 25)[0][0] #finds peak of first Gaussian
            peak2_index = np.where(coord == 50)[0][0] #finds peak of second Gaussian
            peak3_index = np.where(coord == 75)[0][0] #finds peak of last Gaussian
            curve = np.zeros(len(coord))
            curve[0:peak1_index] = Gaussian1[0:peak1_index] #starts off by making the first bit of the curve
            curve[peak1_index:peak2_index] = Gaussian2[peak1_index:peak2_index] + Gaussian3[peak1_index:peak2_index] #makes the second part of the curve a mixture of Gaussians
            curve[peak2_index:peak3_index] = Gaussian4[peak2_index:peak3_index] + Gaussian5[peak2_index:peak3_index] #makes the third part of the curve a mixture of Gaussians
            curve[peak3_index::] = Gaussian6[peak3_index::] #makes the final piece of the curve the final Gaussian
            return curve

        #Initializing data
        coord = np.linspace(0,100,1001) #gives reaction coordinate as a %
        curve = data(Ereact, Eprod, Ea1, Ea2, Ea3, Einter1, Einter2, w)

        #Initial plot
        fig, ax = plt.subplots(figsize=(10,8))
        fig.subplots_adjust(bottom=0.3)
        line, = ax.plot(coord,curve,color='b', linewidth = 2, label='Arrhenius Curve')
        #matplotlib.rcParams.update({'font.size': 16})
        ax.set_xlabel('Reaction progress (%)')
        ax.set_ylabel('Energy (kJ/mol)')
        ax.set_xlim([0, 100])
        ax.set_ylim([-0.05*max(curve), 1.05*max(curve)])
        plt.grid()

        #Sliders for the Ea values
        sliderax = fig.add_axes([0.15,0.2,0.3,0.05]) #written in terms of fractions of the window; x start, y start, x width, y width
        Ea1_slider = Slider(
            sliderax,
            label=r'$E_{a1}$ (kJ/mol)',
            valmin=0,
            valmax=Emax,
            valinit=Ea1,
            valstep = 1,
            facecolor = 'b',
            track_color = 'b')

        sliderax2 = fig.add_axes([0.15,0.15,0.3,0.05]) #written in terms of fractions of the window; x start, y start, x width, y width
        Ea2_slider = Slider(
            sliderax2,
            label=r'$E_{a2}$ (kJ/mol)',
            valmin=0,
            valmax=Emax,
            valinit=Ea2,
            valstep = 1,
            facecolor = 'b',
            track_color = 'b')

        sliderax3 = fig.add_axes([0.15,0.1,0.3,0.05]) #written in terms of fractions of the window; x start, y start, x width, y width
        Ea3_slider = Slider(
            sliderax3,
            label=r'$E_{a3}$ (kJ/mol)',
            valmin=0,
            valmax=Emax,
            valinit=Ea3,
            valstep = 1,
            facecolor = 'b',
            track_color = 'b')

        w_ax = fig.add_axes([0.15,0.0,0.3,0.05]) #written in terms of fractions of the window; x start, y start, x width, y width
        w_slider = Slider(
            w_ax,
            label=r'$w$',
            valmin=1,
            valmax=60,
            valstep = 1,
            valinit=w,
            facecolor = 'b',
            track_color = 'b')

        Einter1_ax = fig.add_axes([0.6,0.2,0.3,0.05]) #written in terms of fractions of the window; x start, y start, x width, y width
        Einter1_slider = Slider(
            Einter1_ax,
            label=r'$E_{inter1}$ (kJ/mol)',
            valmin=0,
            valmax=500,
            valinit=Einter1,
            valstep = 1,
            facecolor = 'b',
            track_color = 'b')

        Einter2_ax = fig.add_axes([0.6,0.15,0.3,0.05]) #written in terms of fractions of the window; x start, y start, x width, y width
        Einter2_slider = Slider(
            Einter2_ax,
            label=r'$E_{inter2}$ (kJ/mol)',
            valmin=0,
            valmax=Emax,
            valinit=Einter2,
            valstep = 1,
            facecolor = 'b',
            track_color = 'b')

        Ereact_ax = fig.add_axes([0.6,0.1,0.3,0.05]) #written in terms of fractions of the window; x start, y start, x width, y width
        Ereact_slider = Slider(
            Ereact_ax,
            label=r'$E_{react}$ (kJ/mol)',
            valmin=0,
            valmax=500,
            valstep = 1,
            valinit=Ereact,
            facecolor = 'b',
            track_color = 'b')

        Eprod_ax = fig.add_axes([0.6,0.05,0.3,0.05]) #written in terms of fractions of the window; x start, y start, x width, y width
        Eprod_slider = Slider(
            Eprod_ax,
            label=r'$E_{prod}$ (kJ/mol)',
            valmin=0,
            valmax=Emax,
            valstep = 1,
            valinit=Eprod,
            facecolor = 'b',
            track_color = 'b')

        axbox = plt.axes([0.6,0.0,0.1,0.05])
        text_box = TextBox(axbox, r'Slider Max', initial = Emax, label_pad = 0.05)

        # register the update function with each slider
        Ea1_slider.on_changed(update)
        Ea2_slider.on_changed(update)
        Ea3_slider.on_changed(update)
        Einter1_slider.on_changed(update)
        Einter2_slider.on_changed(update)
        Ereact_slider.on_changed(update)
        Eprod_slider.on_changed(update)
        w_slider.on_changed(update)
        text_box.on_submit(update)

        plt.show()
    #################
    # Program 3 end #
    #################

    if token == 4: 
    #############
    # Program 4 #
    #############
        Ea = 150 #initial activation energy
        Ea_uncat = 100 #initial uncatalyzed activation energy
        Ereact = 200 #initial energy of reactants (kJ/mol)
        Eprod = 0 #intitial energy of products (kJ/mol)
        w = 250 #width parameter for Gaussian function; big makes it wide, small makes it narrow
        Emax = 500
        coord = np.linspace(0,100,1001) #gives reaction coordinate as a % of reaction progress

        # The function to be called anytime a slider's or text box's value changes
        def update(val):
            global Ea, Ea_uncat, Ereact, Eprod, w, Emax
            try:
                Ea = Ea_slider.val
                Ea_uncat = Ea_uncat_slider.val
                Ereact = Ereact_slider.val
                Eprod = Eprod_slider.val
                w = w_slider.val
                Emax = int(text_box.text)
                if Emax < Ea or Emax < Ereact or Emax < Eprod or Emax < Ea_uncat:
                    raise ValueError
                Ea_slider.ax.set_xlim(0, Emax)
                Ea_slider.valmax = Emax
                Ea_uncat_slider.ax.set_xlim(0, Emax)
                Ea_uncat_slider.valmax = Emax
                Ereact_slider.ax.set_xlim(0, Emax)
                Ereact_slider.valmax = Emax
                Eprod_slider.ax.set_xlim(0, Emax)
                Eprod_slider.valmax = Emax 
                if w <= 0:
                    raise ValueError
                if Ereact+Ea < Eprod: # activation energy needs to be enough to reach the products!
                    Ea = Eprod-Ereact
                    Ea_slider.set_val(Eprod-Ereact)
                if Ereact+Ea_uncat < Eprod: # activation energy needs to be enough to reach the products!
                    Ea_uncat = Eprod-Ereact
                    Ea_uncat_slider.set_val(Eprod-Ereact)
                if Ea < Ea_uncat:
                    Ea = Ea_uncat
                    Ea_slider.set_val(Ea_uncat)
                curve, curve_uncat = data(Ereact, Eprod, Ea, Ea_uncat, w)
                ax.set_ylim([-0.05*max(max(curve),max(curve_uncat)), 1.05*max(max(curve),max(curve_uncat))])
                line.set_ydata(curve)
                line2.set_ydata(curve_uncat)
            except ValueError:
                print("The maximum energy for sliders must be higher than the current largest value used on the sliders.")

        def data(Ereact, Eprod, Ea, Ea_uncat, w):
            Gaussian1 = Ea*np.exp(-(coord-50)**2/w)+Ereact #Gaussian for the first part of the curve
            Gaussian2 = (Ea+Ereact-Eprod)*np.exp(-(coord-50)**2/w) + Eprod #Gaussian for the second part of the curve
            Gaussian3 = Ea_uncat*np.exp(-(coord-50)**2/w)+Ereact #Gaussian for the first part of the curve
            Gaussian4 = (Ea_uncat+Ereact-Eprod)*np.exp(-(coord-50)**2/w) + Eprod #Gaussian for the second part of the curve
            curve = Gaussian1 #starts off by making the curve the whole of the first Gaussian
            index = np.where(coord == 50)[0][0] #finds where the peak is
            curve[index::] = Gaussian2[index::] #makes the last half of the curve the second Gaussian
            curve_uncat = Gaussian3 #starts off by making the curve the whole of the first Gaussian
            curve_uncat[index::] = Gaussian4[index::] #makes the last half of the curve the second Gaussian
            return curve, curve_uncat

        #Initializing data
        coord = np.linspace(0,100,1001) #gives reaction coordinate as a %
        curve, curve_uncat = data(Ereact, Eprod, Ea, Ea_uncat, w)

        #Initial plot
        fig, ax = plt.subplots(figsize=(12,8))
        fig.subplots_adjust(bottom=0.3)
        line, = ax.plot(coord,curve,color='b', linewidth = 2, label='Catalyzed Reaction')
        line2, = ax.plot(coord,curve_uncat,color='red', linewidth = 2, linestyle = '--', label='Uncatalyzed Reaction')
        #matplotlib.rcParams.update({'font.size': 16})
        ax.set_xlabel('Reaction progress (%)')
        ax.set_ylabel('Energy (kJ/mol)')
        ax.set_xlim([0, 100])
        ax.set_ylim([-0.05*max(max(curve),max(curve_uncat)), 1.05*max(max(curve),max(curve_uncat))])
        plt.grid()
        plt.legend()

        #Slider for the Ea values
        sliderax = fig.add_axes([0.15,0.15,0.3,0.05]) #written in terms of fractions of the window; x start, y start, x width, y width
        Ea_slider = Slider(
            sliderax,
            label=r'$E_a$ (kJ/mol)',
            valmin=0,
            valmax=Emax,
            valinit=Ea,
            valstep = 1,
            facecolor = 'b',
            track_color = 'b')

        sliderax2 = fig.add_axes([0.15,0.1,0.3,0.05]) #written in terms of fractions of the window; x start, y start, x width, y width
        Ea_uncat_slider = Slider(
            sliderax2,
            label=r'$E_a$ Uncatalyzed (kJ/mol)',
            valmin=0,
            valmax=Emax,
            valinit=Ea_uncat,
            valstep = 1,
            facecolor = 'b',
            track_color = 'b')

        w_ax = fig.add_axes([0.15,0.025,0.3,0.05]) #written in terms of fractions of the window; x start, y start, x width, y width
        w_slider = Slider(
            w_ax,
            label=r'$w$',
            valmin=1,
            valmax=500,
            valstep = 1,
            valinit=w,
            facecolor = 'b',
            track_color = 'b')

        Ereact_ax = fig.add_axes([0.6,0.15,0.3,0.05]) #written in terms of fractions of the window; x start, y start, x width, y width
        Ereact_slider = Slider(
            Ereact_ax,
            label=r'$E_{react}$ (kJ/mol)',
            valmin=0,
            valmax=Emax,
            valstep = 1,
            valinit=Ereact,
            facecolor = 'b',
            track_color = 'b')

        Eprod_ax = fig.add_axes([0.6,0.1,0.3,0.05]) #written in terms of fractions of the window; x start, y start, x width, y width
        Eprod_slider = Slider(
            Eprod_ax,
            label=r'$E_{prod}$ (kJ/mol)',
            valmin=0,
            valmax=Emax,
            valstep = 1,
            valinit=Eprod,
            facecolor = 'b',
            track_color = 'b')

        axbox = plt.axes([0.6,0.025,0.1,0.05])
        text_box = TextBox(axbox, r'Slider Max', initial = Emax, label_pad = 0.05)

        # register the update function with each slider and text box
        Ea_slider.on_changed(update)
        Ea_uncat_slider.on_changed(update)
        Ereact_slider.on_changed(update)
        Eprod_slider.on_changed(update)
        w_slider.on_changed(update)
        text_box.on_submit(update)

        plt.show()
    #################
    # Program 4 end #
    #################

    if token == 5:
    #############
    # Program 5 #
    #############
        Ea1 = 100 #initial activation energy for 1st step
        Ea2 = 150 #initial activation energy for 2nd step
        Einter = 100 #energy of the intermediate species
        Ereact = 200 #Relative energy of reactant (kJ/mol)
        Eprod = 0 #Relative energy of product (kJ/mol)
        Ea_uncat = 200 #initial uncatalyzed activation energy
        Emax = 500 
        w = 60 #width parameter for Gaussian function

        # The function to be called anytime a slider's value changes
        def update(val):
            global Ea1, Ea2, Einter, Ereact, Eprod, w, Ea_uncat, Emax
            try:
                Ea1 = Ea1_slider.val
                Ea2 = Ea2_slider.val
                Ea_uncat = Ea_uncat_slider.val
                Einter = Einter_slider.val
                Ereact = Ereact_slider.val
                Eprod = Eprod_slider.val
                w = w_slider.val
                Emax = int(text_box.text)
                if Emax < Ea1 or Emax < Ea2 or Emax < Ereact or Emax < Eprod or Emax < Ea_uncat:
                    raise ValueError
                Ea1_slider.ax.set_xlim(0, Emax)
                Ea1_slider.valmax = Emax
                Ea2_slider.ax.set_xlim(0, Emax)
                Ea2_slider.valmax = Emax
                Ea_uncat_slider.ax.set_xlim(0, Emax)
                Ea_uncat_slider.valmax = Emax
                Einter_slider.ax.set_xlim(0, Emax)
                Einter_slider.valmax = Emax
                Ereact_slider.ax.set_xlim(0, Emax)
                Ereact_slider.valmax = Emax
                Eprod_slider.ax.set_xlim(0, Emax)
                Eprod_slider.valmax = Emax 
                if Einter > Ea1+Ereact:
                    Einter = Ea1+Ereact
                    Einter_slider.set_val(Ea1+Ereact)
                if Einter+Ea2 < Eprod: # activation energy needs to be enough to reach the products!
                    Ea2 = Eprod-Einter
                    Ea2_slider.set_val(Eprod-Einter)
                if Ea_uncat < max(Ea1, Ea2):
                    Ea_uncat = max(Ea1, Ea2)
                    Ea_uncat_slider.set_val(max(Ea1, Ea2))
                curve, curve_uncat = data(Ereact, Eprod, Ea1, Ea2, Ea_uncat, Einter, w)
                if max(curve) != 0:
                    ax.set_ylim([-0.05*max(max(curve),max(curve_uncat)), 1.05*max(max(curve),max(curve_uncat))])
                line.set_ydata(curve)
                line2.set_ydata(curve_uncat)
            except ValueError:
                print("The maximum energy for sliders must be higher than the current largest value used on the sliders.")

        def data(Ereact, Eprod, Ea1, Ea2, Ea_uncat, Einter, w):
            # Makes the curve for the catalyzed process
            Gaussian1 = Ea1*np.exp(-(coord-33)**2/w)+Ereact #Gaussian for the first part of the curve
            Gaussian2 = (Ea1+Ereact-Einter)*np.exp(-(coord-33)**2/w) #first Gaussian for the second part of the curve
            Gaussian3 = Ea2*np.exp(-(coord-67)**2/w)+Einter #second Gaussian for the second part of the curve
            Gaussian4 = (Ea2+Einter-Eprod)*np.exp(-(coord-67)**2/w)+Eprod #Gaussian for the final part of the curve
            peak1_index = np.where(coord == 33)[0][0] #finds peak of first Gaussian
            peak2_index = np.where(coord == 67)[0][0] #finds peak of last Gaussian
            curve = np.zeros(len(coord))
            curve[0:peak1_index] = Gaussian1[0:peak1_index] #starts off by making the first bit of the curve
            curve[peak1_index:peak2_index] = Gaussian2[peak1_index:peak2_index] + Gaussian3[peak1_index:peak2_index] #makes the final piece of the curve the final Gaussian
            curve[peak2_index::] = Gaussian4[peak2_index::] #makes the final piece of the curve the final Gaussian
            # Makes the curve for the uncatalyzed process
            index = np.where(coord == 50)[0][0] #finds where the peak is
            Gaussian5 = Ea_uncat*np.exp(-(coord-50)**2/w)+Ereact #Gaussian for the first part of the curve
            Gaussian6 = (Ea_uncat+Ereact-Eprod)*np.exp(-(coord-50)**2/w) + Eprod #Gaussian for the second part of the curve
            curve_uncat = Gaussian5 #starts off by making the curve the whole of the first Gaussian
            curve_uncat[index::] = Gaussian6[index::] #makes the last half of the curve the second Gaussian
            return curve, curve_uncat

        #Initializing data
        coord = np.linspace(0,100,1001) #gives reaction coordinate as a %
        curve, curve_uncat = data(Ereact, Eprod, Ea1, Ea2, Ea_uncat, Einter, w)

        #Initial plot
        fig, ax = plt.subplots(figsize=(12,8))
        fig.subplots_adjust(bottom=0.3)
        line, = ax.plot(coord,curve,color='b', linewidth = 2, label='Catalyzed Reaction')
        line2, = ax.plot(coord,curve_uncat,color='r', linewidth = 2, linestyle = '--', label='Uncatalyzed Reaction')
        #matplotlib.rcParams.update({'font.size': 16})
        ax.set_xlabel('Reaction progress (%)')
        ax.set_ylabel('Energy (kJ/mol)')
        ax.set_xlim([0, 100])
        if max(curve_uncat) != 0:
            ax.set_ylim([-0.05*max(max(curve),max(curve_uncat)), 1.05*max(max(curve),max(curve_uncat))])
        #plt.legend() #hidden when making plots for tests
        plt.grid()
        plt.legend()

        #Sliders for the Ea values
        sliderax = fig.add_axes([0.15,0.15,0.3,0.05]) #written in terms of fractions of the window; x start, y start, x width, y width
        Ea1_slider = Slider(
            sliderax,
            label=r'$E_{a1}$ (kJ/mol)',
            valmin=0,
            valmax=Emax,
            valinit=Ea1,
            valstep = 1,
            facecolor = 'b',
            track_color = 'b')

        sliderax2 = fig.add_axes([0.15,0.1,0.3,0.05]) #written in terms of fractions of the window; x start, y start, x width, y width
        Ea2_slider = Slider(
            sliderax2,
            label=r'$E_{a2}$ (kJ/mol)',
            valmin=0,
            valmax=Emax,
            valinit=Ea2,
            valstep = 1,
            facecolor = 'b',
            track_color = 'b')

        w_ax = fig.add_axes([0.15,0.025,0.3,0.05]) #written in terms of fractions of the window; x start, y start, x width, y width
        w_slider = Slider(
            w_ax,
            label=r'$w$',
            valmin=1,
            valmax=100,
            valstep = 1,
            valinit=w,
            facecolor = 'b',
            track_color = 'b')

        sliderax4 = fig.add_axes([0.15,0.2,0.3,0.05]) #written in terms of fractions of the window; x start, y start, x width, y width
        Ea_uncat_slider = Slider(
            sliderax4,
            label=r'$E_a$ Uncatalyzed (kJ/mol)',
            valmin=0,
            valmax=Emax,
            valinit=Ea_uncat,
            valstep = 1,
            facecolor = 'b',
            track_color = 'b')

        sliderax3 = fig.add_axes([0.6,0.2,0.3,0.05]) #written in terms of fractions of the window; x start, y start, x width, y width
        Einter_slider = Slider(
            sliderax3,
            label=r'$E_{inter}$ (kJ/mol)',
            valmin=0,
            valmax=Emax,
            valinit=Einter,
            valstep = 1,
            facecolor = 'b',
            track_color = 'b')

        Ereact_ax = fig.add_axes([0.6,0.15,0.3,0.05]) #written in terms of fractions of the window; x start, y start, x width, y width
        Ereact_slider = Slider(
            Ereact_ax,
            label=r'$E_{react}$ (kJ/mol)',
            valmin=0,
            valmax=Emax,
            valstep = 1,
            valinit=Ereact,
            facecolor = 'b',
            track_color = 'b')

        Eprod_ax = fig.add_axes([0.6,0.1,0.3,0.05]) #written in terms of fractions of the window; x start, y start, x width, y width
        Eprod_slider = Slider(
            Eprod_ax,
            label=r'$E_{prod}$ (kJ/mol)',
            valmin=0,
            valmax=Emax,
            valstep = 1,
            valinit=Eprod,
            facecolor = 'b',
            track_color = 'b')

        axbox = plt.axes([0.6,0.025,0.1,0.05])
        text_box = TextBox(axbox, r'Slider Max', initial = Emax, label_pad = 0.05)

        # register the update function with each slider
        Ea1_slider.on_changed(update)
        Ea2_slider.on_changed(update)
        Einter_slider.on_changed(update)
        Ea_uncat_slider.on_changed(update)
        Ereact_slider.on_changed(update)
        Eprod_slider.on_changed(update)
        w_slider.on_changed(update)
        text_box.on_submit(update)

        plt.show()
    #################
    # Program 5 end #
    #################

    if token == 6:
    #############
    # Program 6 #
    #############
        Ea1 = 150 #initial activation energy for 1st step
        Ea2 = 150 #initial activation energy for 2nd step
        Ea3 = 100 #initial activation energy for 3rd step
        Einter1 = 100 #energy of the first intermediate species
        Einter2 = 150 #energy of the second intermediate species
        Ereact = 0 #Relative energy of reactant (kJ/mol)
        Eprod = 100 #Relative energy of product (kJ/mol)
        w = 30 #width parameter for Gaussian function
        Emax = 500
        Ea_uncat = max(Ea1,Ea2+Einter1-Ereact,Ea3+Einter2-Ereact) + 200 #initial uncatalyzed activation energy

        # The function to be called anytime a fslider's value changes
        def update(val):
            global Ea1, Ea2, Ea3, Einter1, Einter2, Ereact, Eprod, w, Ea_uncat, Emax
            try:
                Ea1 = Ea1_slider.val
                Ea2 = Ea2_slider.val
                Ea3 = Ea3_slider.val
                Ea_uncat = Ea_uncat_slider.val
                Einter1 = Einter1_slider.val
                Einter2 = Einter2_slider.val
                Ereact = Ereact_slider.val
                Eprod = Eprod_slider.val
                w = w_slider.val
                Emax = int(text_box.text)
                if Emax < Ea1 or Emax < Ea2 or Emax < Ea3 or Emax < Ereact or Emax < Eprod or Emax < Ea_uncat:
                    raise ValueError
                Ea1_slider.ax.set_xlim(0, Emax)
                Ea1_slider.valmax = Emax
                Ea2_slider.ax.set_xlim(0, Emax)
                Ea2_slider.valmax = Emax
                Ea3_slider.ax.set_xlim(0, Emax)
                Ea3_slider.valmax = Emax
                Ea_uncat_slider.ax.set_xlim(0, Emax)
                Ea_uncat_slider.valmax = Emax
                Einter1_slider.ax.set_xlim(0, Emax)
                Einter1_slider.valmax = Emax
                Einter2_slider.ax.set_xlim(0, Emax)
                Einter2_slider.valmax = Emax
                Ereact_slider.ax.set_xlim(0, Emax)
                Ereact_slider.valmax = Emax
                Eprod_slider.ax.set_xlim(0, Emax)
                Eprod_slider.valmax = Emax 
                if Einter1 > Ea1+Ereact:
                    Einter1 = Ea1+Ereact
                    Einter1_slider.set_val(Ea1+Ereact)
                if Einter1+Ea2 < Einter1: # activation energy needs to be enough to reach the intermediate!
                    Ea2 = Einter2-Einter1
                    Ea2_slider.set_val(Einter2-Einter1)
                if Einter2 > Ea2+Einter1:
                    Einter2 = Ea2+Einter1
                    Einter2_slider.set_val(Ea2+Einter1)
                if Einter2+Ea3 < Eprod: # activation energy needs to be enough to reach the intermediate!
                    Ea3 = Eprod-Einter2
                    Ea3_slider.set_val(Eprod-Einter2)
                if Ea_uncat < max(Ea1, Ea2, Ea3):
                    Ea_uncat = max(Ea1, Ea2, Ea3)
                    Ea_uncat_slider.set_val(max(Ea1, Ea2, Ea3))
                curve, curve_uncat = data(Ereact, Eprod, Ea1, Ea2, Ea3, Ea_uncat, Einter1, Einter2, w)
                ax.set_ylim([-0.05*max(max(curve),max(curve_uncat)), 1.05*max(max(curve),max(curve_uncat))])
                line.set_ydata(curve)
                line2.set_ydata(curve_uncat)
            except ValueError:
                print("The maximum energy for sliders must be higher than the current largest value used on the sliders.")

        def data(Ereact, Eprod, Ea1, Ea2, Ea3, Ea_uncat, Einter1, Einter2, w):
            # Making curve for uncatalyzed reaction
            Gaussian1 = Ea1*np.exp(-(coord-25)**2/w)+Ereact #Gaussian for the first part of the curve
            Gaussian2 = (Ea1+Ereact-Einter1)*np.exp(-(coord-25)**2/w) #first Gaussian for the second part of the curve
            Gaussian3 = Ea2*np.exp(-(coord-50)**2/w)+Einter1 #second Gaussian for the second part of the curve
            Gaussian4 = (Ea2+Einter1-Einter2)*np.exp(-(coord-50)**2/w) #first Gaussian for the third part of the curve
            Gaussian5 = Ea3*np.exp(-(coord-75)**2/w) + Einter2 #second Gaussian for the third part of the curve
            Gaussian6 = (Ea3+Einter2-Eprod)*np.exp(-(coord-75)**2/w)+Eprod #Gaussian for the final part of the curve
            peak1_index = np.where(coord == 25)[0][0] #finds peak of first Gaussian
            peak2_index = np.where(coord == 50)[0][0] #finds peak of second Gaussian
            peak3_index = np.where(coord == 75)[0][0] #finds peak of last Gaussian
            curve = np.zeros(len(coord))
            curve[0:peak1_index] = Gaussian1[0:peak1_index] #starts off by making the first bit of the curve
            curve[peak1_index:peak2_index] = Gaussian2[peak1_index:peak2_index] + Gaussian3[peak1_index:peak2_index] #makes the second part of the curve a mixture of Gaussians
            curve[peak2_index:peak3_index] = Gaussian4[peak2_index:peak3_index] + Gaussian5[peak2_index:peak3_index] #makes the third part of the curve a mixture of Gaussians
            curve[peak3_index::] = Gaussian6[peak3_index::] #makes the final piece of the curve the final Gaussian
            # Making curve for uncatalyzed reaction
            index = np.where(coord == 50)[0][0] #finds where the peak is
            Gaussian7 = Ea_uncat*np.exp(-(coord-50)**2/250)+Ereact #Gaussian for the first part of the curve
            Gaussian8 = (Ea_uncat+Ereact-Eprod)*np.exp(-(coord-50)**2/250)+Eprod #Gaussian for the second part of the curve
            curve_uncat = Gaussian7 #starts off by making the curve the whole of the first Gaussian
            curve_uncat[index::] = Gaussian8[index::] #makes the last half of the curve the second Gaussian
            return curve, curve_uncat

        #Initializing data
        coord = np.linspace(0,100,1001) #gives reaction coordinate as a %
        curve, curve_uncat = data(Ereact, Eprod, Ea1, Ea2, Ea3, Ea_uncat, Einter1, Einter2, w)

        #Initial plot
        fig, ax = plt.subplots(figsize=(12,8))
        fig.subplots_adjust(bottom=0.35)
        line, = ax.plot(coord,curve,color='b', linewidth = 2, label='Catalyzed Reaction')
        line2, = ax.plot(coord,curve_uncat,color='r', linewidth = 2, linestyle = '--', label='Uncatalyzed Reaction')
        #matplotlib.rcParams.update({'font.size': 16})
        ax.set_xlabel('Reaction progress (%)')
        ax.set_ylabel('Energy (kJ/mol)')
        ax.set_xlim([0, 100])
        if max(curve_uncat) != 0:
            ax.set_ylim([-0.05*max(max(curve),max(curve_uncat)), 1.05*max(max(curve),max(curve_uncat))])
        plt.grid()
        plt.legend()

        # Sliders
        Ea_uncat_ax = fig.add_axes([0.15,0.25,0.3,0.05]) #written in terms of fractions of the window; x start, y start, x width, y width
        Ea_uncat_slider = Slider(
            Ea_uncat_ax,
            label=r'$E_a$ Uncatalyzed (kJ/mol)',
            valmin=0,
            valmax=Emax,
            valinit=Ea_uncat,
            valstep = 1,
            facecolor = 'b',
            track_color = 'b')

        sliderax = fig.add_axes([0.15,0.2,0.3,0.05]) #written in terms of fractions of the window; x start, y start, x width, y width
        Ea1_slider = Slider(
            sliderax,
            label=r'$E_{a1}$ (kJ/mol)',
            valmin=0,
            valmax=Emax,
            valinit=Ea1,
            valstep = 1,
            facecolor = 'b',
            track_color = 'b')

        sliderax2 = fig.add_axes([0.15,0.15,0.3,0.05]) #written in terms of fractions of the window; x start, y start, x width, y width
        Ea2_slider = Slider(
            sliderax2,
            label=r'$E_{a2}$ (kJ/mol)',
            valmin=0,
            valmax=Emax,
            valinit=Ea2,
            valstep = 1,
            facecolor = 'b',
            track_color = 'b')

        sliderax3 = fig.add_axes([0.15,0.1,0.3,0.05]) #written in terms of fractions of the window; x start, y start, x width, y width
        Ea3_slider = Slider(
            sliderax3,
            label=r'$E_{a3}$ (kJ/mol)',
            valmin=0,
            valmax=Emax,
            valinit=Ea3,
            valstep = 1,
            facecolor = 'b',
            track_color = 'b')

        w_ax = fig.add_axes([0.15,0.025,0.3,0.05]) #written in terms of fractions of the window; x start, y start, x width, y width
        w_slider = Slider(
            w_ax,
            label=r'$w$',
            valmin=1,
            valmax=60,
            valstep = 1,
            valinit=w,
            facecolor = 'b',
            track_color = 'b')

        Einter1_ax = fig.add_axes([0.6,0.25,0.3,0.05]) #written in terms of fractions of the window; x start, y start, x width, y width
        Einter1_slider = Slider(
            Einter1_ax,
            label=r'$E_{inter1}$ (kJ/mol)',
            valmin=0,
            valmax=500,
            valinit=Einter1,
            valstep = 1,
            facecolor = 'b',
            track_color = 'b')

        Einter2_ax = fig.add_axes([0.6,0.2,0.3,0.05]) #written in terms of fractions of the window; x start, y start, x width, y width
        Einter2_slider = Slider(
            Einter2_ax,
            label=r'$E_{inter2}$ (kJ/mol)',
            valmin=0,
            valmax=Emax,
            valinit=Einter2,
            valstep = 1,
            facecolor = 'b',
            track_color = 'b')

        Ereact_ax = fig.add_axes([0.6,0.15,0.3,0.05]) #written in terms of fractions of the window; x start, y start, x width, y width
        Ereact_slider = Slider(
            Ereact_ax,
            label=r'$E_{react}$ (kJ/mol)',
            valmin=0,
            valmax=Emax,
            valstep = 1,
            valinit=Ereact,
            facecolor = 'b',
            track_color = 'b')

        Eprod_ax = fig.add_axes([0.6,0.1,0.3,0.05]) #written in terms of fractions of the window; x start, y start, x width, y width
        Eprod_slider = Slider(
            Eprod_ax,
            label=r'$E_{prod}$ (kJ/mol)',
            valmin=0,
            valmax=Emax,
            valstep = 1,
            valinit=Eprod,
            facecolor = 'b',
            track_color = 'b')

        axbox = plt.axes([0.6,0.025,0.1,0.05])
        text_box = TextBox(axbox, r'Slider Max', initial = Emax, label_pad = 0.05)

        # register the update function with each slider
        Ea1_slider.on_changed(update)
        Ea2_slider.on_changed(update)
        Ea3_slider.on_changed(update)
        Einter1_slider.on_changed(update)
        Einter2_slider.on_changed(update)
        Ea_uncat_slider.on_changed(update)
        Ereact_slider.on_changed(update)
        Eprod_slider.on_changed(update)
        w_slider.on_changed(update)
        text_box.on_submit(update)

        plt.show()
    #################
    # Program 6 end #
    #################
