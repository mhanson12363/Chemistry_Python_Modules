import numpy as np
import matplotlib.pyplot as plt
import matplotlib
from matplotlib import cm
from matplotlib.widgets import Button, Slider, TextBox

valid = False #initializes so the first call will happen
token = 0 #just initializes at a benign value
def get_token(): #allows neatly looping the program and 'talking' to the user
    valid = False #intitialized as False so the program will seek a valid value
    while valid == False: #keeps looping this until the user provides a valid token
        try: #only works if the user puts something that can be interpreted as an integer
            token = int(input('Which option would you like to use? Enter 0 for options: '))
            if (token in [i+1 for i in range(2)]):
                valid = True
            if token == 0: #lists out the options
                print('The following options are available for plots illustrating the activation energy:' + '\n')
                print('Enter 1:' + ' '*5 + 'Maxwell-Boltzmann distribution for one gas')
                print('Enter 2:' + ' '*5 + 'Maxwell-Boltzmann distributions for two gases')
                print('Enter -1:' + ' '*4 + 'Ends the program' + '\n')
            if (token not in [i+1 for i in range(2)]) and (token != -1):
                valid = False
                print('Please enter a valid integer from 1-2 or -1 to quit the program.' + '\n')
            if token == -1:
                valid = True #lets the loop inside the function end
                print('Terminating program')
        except: #yells at the user for putting in an invalid entry
            valid = False
            print('Please enter a valid integer from 1-2 or -1 to quit the program.' + '\n')
    return token, valid

#tells the user the options right away so they don't have to ask for them
print('The following options are available for plots illustrating the activation energy:' + '\n')
print('Enter 1:' + ' '*5 + 'Maxwell-Boltzmann distribution for one gas')
print('Enter 2:' + ' '*5 + 'Maxwell-Boltzmann distributions for two gases')
print('Enter -1:' + ' '*4 + 'Ends the program' + '\n')

while (valid or valid == False) and (token != -1): #runs the programs until the user decides to kill the process by setting token = -1
    token, valid = get_token() #continues the loop
    if token == 1:
    #############
    # Program 1 #
    #############
        # constants and flags
        k_B = 1.38*10**-23 #J/K
        flag = False # initial setting for rescale button

        def redraw_fill(v, pv): # function to update the filled in area
            global fill
            if fill is not None:
                fill.remove()
            fill = ax.fill_between(v, np.zeros(len(pv)), pv, color='b', alpha=0.1, hatch = '//')
            
        def update(event): # this function is called whenever the value of the slider widget is changed
            global T, mass # we make the slider variable global so that we can keep track of it
            try:
                mass = float(mass_txtbox.text)
                m = mass/1000/(6.02214*10**23) # kg
                if mass <= 0:
                    raise ValueError
                T = T_slider.val # the slider value is used to update the curve
                v_mean = np.sqrt(2*k_B*T/m)
                v = np.linspace(0, 4*v_mean, 500) # updates the linear array in case the value of end was changed in on_type()
                pv = (4/np.sqrt(np.pi))*(m/(2*k_B*T))**1.5*(v**2)*np.exp(-m*v**2/(2*k_B*T))
                redraw_fill(v, pv)
                line.set_xdata(v)
                line.set_ydata(pv)
                if flag: 
                    ax.set(xlim = [min(v), max(v)], ylim = [-0.1*max(pv), 1.1*max(pv)])
                else:        
                    ax.set(ylim = [-0.1*max(pv), 1.1*max(pv)])
            except ValueError:
                print('Please choose valid positive values for the mass and temperature.')

        def rescale(event): # controls the button
            global flag 
            flag = not flag 
            if flag == True:
                ax_text.clear()
                ax_text.axis('off')
                ax_text.text(0.6, 0.0, "Rescale Mode") 
            if flag == False:
                ax_text.clear()
                ax_text.axis('off')
                ax_text.text(0.6, 0.0, "Fixed Scale Mode")

        T = 298 # K (default)
        mass = 32 # g/mol (default) 
        m = mass/1000/(6.02214*10**23) # kg
        v_mean = np.sqrt(2*k_B*T/m)
        v = np.linspace(0, 4*v_mean, 500)
        pv = (4/np.sqrt(np.pi)) * (m/(2 * k_B * T))**1.5 * (v**2) * np.exp(-m * v**2/(2 * k_B * T))

        # Initial plot
        fig, ax = plt.subplots(1,1,figsize=(10,6))
        fig.subplots_adjust(bottom=0.3, left = 0.2)
        line, = ax.plot(v, pv, color='b', linewidth = 2, label='Probability')
        fill = ax.fill_between(v, np.zeros(len(pv)), pv, color = 'b', alpha = 0.1, hatch = '//')
        matplotlib.rcParams.update({'font.size': 16})
        ax.set(xlim = [min(v), max(v)], ylim = [-0.1*max(pv), 1.1*max(pv)])
        ax.tick_params(labelsize=16)
        ax.set_xlabel(r'$v$ (m/s)',fontsize=16)
        ax.set_ylabel('Probability Density $P(v)$',fontsize=16)
        ax.grid()

        sliderax = fig.add_axes([0.1,0.125,0.4,0.05]) # written in terms of fractions of the window position; x start, y start, x width, y width
        T_slider = Slider( #the Slider() function creates the slider
            sliderax, # uses the slider axis to create the slider
            label='$T$ (K)', # the label displayed on the slider
            valmin=1, # the lowest allowed value on the slider
            valmax=1000, # the highest allowed value on the slider
            valstep = 1, # this is the step between the values on the slider. This is optional, but larger steps can reduce the computational cost a lot! 
            valinit=T)

        #textbox
        mass_ax = fig.add_axes([0.3, 0.025, 0.1, 0.05])
        mass_txtbox = TextBox(mass_ax, 'Molar mass (g/mol): ', initial = str(round(mass, 2)))

        #button
        ax_button = fig.add_axes([0.65, 0.125, 0.25, 0.05])
        rescale_button = Button(ax_button, "Scaling Mode Button", color='cyan', hovercolor='red')

        ax_text = fig.add_axes([0.6, 0.05, 0.15, 0.1])
        ax_text.axis('off')
        ax_text.text(0.6, 0.0, "Fixed Scale Mode")

        T_slider.on_changed(update)
        mass_txtbox.on_submit(update)
        rescale_button.on_clicked(rescale)

        plt.show()
    #################
    # Program 1 end #
    #################

    if token == 2:
    #############
    # Program 2 #
    #############
        # constants and flags 
        k_B = 1.38*10**-23 #J/K
        flag = False # initial setting for rescale button

        def redraw_fill(v, pv, pv2): # function to update the filled in area
            global fill, fill2
            if fill is not None:
                fill.remove()
            fill = ax.fill_between(v, np.zeros(len(pv)), pv, color='b', alpha=0.1, hatch = '//')
            if fill2 is not None:
                fill2.remove()
            fill2 = ax.fill_between(v, np.zeros(len(pv2)), pv2, color='r', alpha=0.1, hatch = '\\')
            
        def update(event): # this function is called whenever the value of the slider widget is changed
            global T, mass, mass2 # we make the slider variable global so that we can keep track of it
            try:
                mass = float(mass_txtbox.text)
                mass2 = float(mass_txtbox2.text)
                m = mass/1000/(6.02214*10**23) # kg
                m2 = mass2/1000/(6.02214*10**23) # kg
                if mass <= 0:
                    raise ValueError
                T = T_slider.val # the slider value is used to update the curve
                T2 = T_slider2.val # the slider value is used to update the curve
                v_mean = np.sqrt(2*k_B*T/m)
                v_mean2 = np.sqrt(2*k_B*T2/m2)
                v = np.linspace(0, 4*max(v_mean, v_mean2), 500) # updates the linear array in case the value of end was changed in on_type()
                pv = (4/np.sqrt(np.pi))*(m/(2*k_B*T))**1.5*(v**2)*np.exp(-m*v**2/(2*k_B*T))
                pv2 = (4/np.sqrt(np.pi))*(m2/(2*k_B*T2))**1.5*(v**2)*np.exp(-m2*v**2/(2*k_B*T2))
                redraw_fill(v, pv, pv2)
                line.set_xdata(v)
                line.set_ydata(pv)
                line2.set_xdata(v)
                line2.set_ydata(pv2)
                if flag: 
                    ax.set(xlim = [min(v), max(v)], ylim = [-0.1*max(max(pv),max(pv2)), 1.1*max(max(pv),max(pv2))])
                else:        
                    ax.set(ylim = [-0.1*max(max(pv),max(pv2)), 1.1*max(max(pv),max(pv2))])
            except ValueError:
                print('Please choose valid positive values for the mass and temperature.')

        def rescale(event): # controls the button
            global flag 
            flag = not flag 
            if flag == True:
                ax_text.clear()
                ax_text.axis('off')
                ax_text.text(0.6, 0.0, "Rescale Mode") 
            if flag == False:
                ax_text.clear()
                ax_text.axis('off')
                ax_text.text(0.6, 0.0, "Fixed Scale Mode")

        T = 298 # K (default)
        T2 = 500 # K (default)
        mass = 32 # g/mol (default)
        mass2 = 28 # g/mol (default) 
        m = mass/1000/(6.02214*10**23) # kg
        m2 = mass2/1000/(6.02214*10**23) # kg
        v_mean = np.sqrt(2*k_B*T/m)
        v_mean2 = np.sqrt(2*k_B*T2/m2)
        v = np.linspace(0, 4*max(v_mean, v_mean2), 500)
        pv = (4/np.sqrt(np.pi))*(m/(2*k_B*T))**1.5*(v**2)*np.exp(-m*v**2/(2*k_B*T))
        pv2 = (4/np.sqrt(np.pi))*(m2/(2*k_B*T2))**1.5*(v**2)*np.exp(-m2*v**2/(2*k_B*T2))

        # Initial plot
        fig, ax = plt.subplots(1,1,figsize=(12,6))
        fig.subplots_adjust(bottom=0.3, left = 0.2)
        line, = ax.plot(v, pv, color='b', linewidth = 2, label='Molecule 1')
        line2, = ax.plot(v, pv2, color='r', linewidth = 2, linestyle = '--', label='Molecule 2')
        fill = ax.fill_between(v, np.zeros(len(pv)), pv, color = 'b', alpha = 0.1, hatch = '//')
        fill2 = ax.fill_between(v, np.zeros(len(pv2)), pv2, color='r', alpha = 0.1, hatch = '\\')
        matplotlib.rcParams.update({'font.size': 16})
        ax.set(xlim = [min(v), max(v)], ylim = [-0.1*max(max(pv),max(pv2)), 1.1*max(max(pv),max(pv2))])
        ax.tick_params(labelsize=16)
        ax.set_xlabel(r'$v$ (m/s)',fontsize=16)
        ax.set_ylabel('Probability Density $P(v)$',fontsize=16)
        ax.grid()
        ax.legend()

        sliderax = fig.add_axes([0.1,0.1,0.4,0.05]) # written in terms of fractions of the window position; x start, y start, x width, y width
        T_slider = Slider( #the Slider() function creates the slider
            sliderax, # uses the slider axis to create the slider
            label='$T_1$ (K)', # the label displayed on the slider
            valmin=1, # the lowest allowed value on the slider
            valmax=1000, # the highest allowed value on the slider
            valstep = 1, # this is the step between the values on the slider. This is optional, but larger steps can reduce the computational cost a lot! 
            valinit=T)

        sliderax2 = fig.add_axes([0.1,0.15,0.4,0.05]) # written in terms of fractions of the window position; x start, y start, x width, y width
        T_slider2 = Slider( #the Slider() function creates the slider
            sliderax2, # uses the slider axis to create the slider
            label='$T_2$ (K)', # the label displayed on the slider
            valmin=1, # the lowest allowed value on the slider
            valmax=1000, # the highest allowed value on the slider
            valstep = 1, # this is the step between the values on the slider. This is optional, but larger steps can reduce the computational cost a lot! 
            valinit=T2)

        #textboxes
        mass_ax = fig.add_axes([0.3, 0.025, 0.1, 0.05])
        mass_txtbox = TextBox(mass_ax, 'Molar mass 1 (g/mol): ', initial = str(round(mass, 2)))
        mass_ax2 = fig.add_axes([0.65, 0.025, 0.1, 0.05])
        mass_txtbox2 = TextBox(mass_ax2, 'Molar mass 2 (g/mol): ', initial = str(round(mass2, 2)))

        #button
        ax_button = fig.add_axes([0.7, 0.125, 0.25, 0.05])
        rescale_button = Button(ax_button, "Scaling Mode Button", color='cyan', hovercolor='red')

        ax_text = fig.add_axes([0.7, 0.05, 0.15, 0.1])
        ax_text.axis('off')
        ax_text.text(0.7, 0.0, "Fixed Scale Mode")

        T_slider.on_changed(update)
        T_slider2.on_changed(update)
        mass_txtbox.on_submit(update)
        mass_txtbox2.on_submit(update)
        rescale_button.on_clicked(rescale)

        plt.show()
    #################
    # Program 2 end #
    #################
