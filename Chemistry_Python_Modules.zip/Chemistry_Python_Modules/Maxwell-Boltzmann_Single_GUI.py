import numpy as np
import matplotlib.pyplot as plt
import matplotlib
from matplotlib import cm
from matplotlib.widgets import Button, Slider, TextBox

k_B = 1.38*10**-23 #J/K
flag = True # initial setting for rescale button

def redraw_fill(v, pv): # function to update the filled in area
    global fill
    if fill is not None:
        fill.remove()
    fill = ax.fill_between(v, np.zeros(len(pv)), pv, color='b', alpha=0.1, hatch = '//')
    
def update(event): # this function is called whenever the value of the slider widget is changed
    global T, mass # we make the slider variable global so that we can keep track of it
    try:
        mass = float(mass_txtbox.text)
        m = mass/1000/(6.02214*10**23) # kg
        if mass <= 0:
            raise ValueError
        T = T_slider.val # the slider value is used to update the curve
        v_mean = np.sqrt(2*k_B*T/m)
        v = np.linspace(0, 4*v_mean, 200) # updates the linear array in case the value of end was changed in on_type()
        pv = (4/np.sqrt(np.pi))*(m/(2*k_B*T))**1.5*(v**2)*np.exp(-m*v**2/(2*k_B*T))
        redraw_fill(v, pv)
        line.set_xdata(v)
        line.set_ydata(pv)
        if flag: 
            ax.set(xlim = [min(v), max(v)], ylim = [-0.1*max(pv), 1.1*max(pv)])
        else:        
            ax.set(ylim = [-0.1*max(pv), 1.1*max(pv)])
    except ValueError:
        print('Please choose valid positive values for the mass and temperature.')

def rescale(event): # controls the button
    global flag 
    flag = not flag 
    if flag == True:
        ax_text.clear()
        ax_text.axis('off')
        ax_text.text(0.6, 0.0, "Rescale Mode") 
    if flag == False:
        ax_text.clear()
        ax_text.axis('off')
        ax_text.text(0.6, 0.0, "Fixed Scale Mode")

T = 298 # K (default)
mass = 32 # g/mol (default) 
m = mass/1000/(6.02214*10**23) # kg
v_mean = np.sqrt(2*k_B*T/m)
v = np.linspace(0, 4*v_mean, 200)
pv = (4/np.sqrt(np.pi)) * (m/(2 * k_B * T))**1.5 * (v**2) * np.exp(-m * v**2/(2 * k_B * T))

# Initial plot
fig, ax = plt.subplots(1,1,figsize=(10,6))
fig.subplots_adjust(bottom=0.3, left = 0.2)
line, = ax.plot(v, pv, color='b', linewidth = 2, label='Probability')
fill = ax.fill_between(v, np.zeros(len(pv)), pv, color = 'b', alpha = 0.1, hatch = '//')
matplotlib.rcParams.update({'font.size': 16})
ax.set(xlim = [min(v), max(v)], ylim = [-0.1*max(pv), 1.1*max(pv)])
ax.tick_params(labelsize=16)
ax.set_xlabel(r'$v$ (m/s)',fontsize=16)
ax.set_ylabel('Probability Density $P(v)$',fontsize=16)
ax.grid()

sliderax = fig.add_axes([0.1,0.125,0.4,0.05]) # written in terms of fractions of the window position; x start, y start, x width, y width
T_slider = Slider( #the Slider() function creates the slider
    sliderax, # uses the slider axis to create the slider
    label='$T$ (K)', # the label displayed on the slider
    valmin=1, # the lowest allowed value on the slider
    valmax=1000, # the highest allowed value on the slider
    valstep = 1, # this is the step between the values on the slider. This is optional, but larger steps can reduce the computational cost a lot! 
    valinit=T)

#textbox
mass_ax = fig.add_axes([0.3, 0.025, 0.1, 0.05])
mass_txtbox = TextBox(mass_ax, 'Molar mass (g/mol): ', initial = str(round(mass, 2)))

#button
ax_button = fig.add_axes([0.65, 0.125, 0.25, 0.05])
rescale_button = Button(ax_button, "Scaling Mode Button", color='cyan', hovercolor='red')

ax_text = fig.add_axes([0.6, 0.05, 0.15, 0.1])
ax_text.axis('off')
ax_text.text(0.6, 0.0, "Rescale Mode")

T_slider.on_changed(update)
mass_txtbox.on_submit(update)
rescale_button.on_clicked(rescale)

plt.show()
