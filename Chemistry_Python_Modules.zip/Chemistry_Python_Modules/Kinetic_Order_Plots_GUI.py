import numpy as np
import matplotlib
import matplotlib.pyplot as plt
from matplotlib.widgets import Button, Slider, TextBox
#Initial information for the reaction A <=> products
compound =  'A' #'C$_4$H$_6$' is how you would write the compound C4H6, for instance
n = 1 #order of reaction with respect to A
k = 0.2 #units of M^n-1/s
Ci = 0.1 #Initial concentration in M
frac = 0.25 #fraction of initial concentration remaining at the end of the reaction

def update(event):
    global compound, Ci, k, n
    try:
        compound = compound_txtbox.text
        Ci = float(Ci_txtbox.text)
        k = float(k_txtbox.text)
        n = int(order_txtbox.text)
        frac = float(frac_txtbox.text)
        if k <= 0 or Ci <= 0 or isinstance(n,int) == False or n < 0 or frac <= 0 or frac >= 1:
            raise ValueError
        concs = np.linspace(frac*Ci, Ci, 101)
        if n == 0: # creates the time axis based on the actual order of reaction to optimize the graph appearances
            times = (Ci - concs)/k
        elif n == 1:
            times = np.log(Ci/concs)/k
        elif n == 2:
            times = (Ci - concs)/(concs*Ci*k)
        elif n not in [0,1,2] and n > 0:
            times = 1/(k*(n-1))*(concs**(-n+1) - Ci**(-n+1)) # general form of the integrated rate law for large n
        ax1.set_ylabel('[' + compound + ']', fontsize = 16)
        ax2.set_ylabel('ln([' + compound + '])', fontsize = 16)
        ax3.set_ylabel('1/[' + compound + ']', fontsize = 16)
        ax1.set(xlim = [0,max(times)], ylim = [0,1.05*Ci] )
        ax2.set(xlim = [0,max(times)], ylim = [min(np.log(concs)),max(np.log(concs))])
        ax3.set(xlim = [0,max(times)], ylim = [min(1/concs),max(1/concs)])
        line.set_xdata(times)
        line.set_ydata(concs)
        line2.set_xdata(times)
        line2.set_ydata(np.log(concs))
        line3.set_xdata(times)
        line3.set_ydata(1/concs)
        ax_text.clear()
        ax_text.axis('off')
        ax_text.text(0, 0.0, compound + r" $\longrightarrow$ Products") 
    except ValueError:
        print('Ensure that the rate constant and initial concentration are valid positive values.')
        print('The reaction order should be an integer ideally in [0,2] or a larger integer.')

concs = np.linspace(frac*Ci, Ci, 101)
if n == 0: # creates the time axis based on the actual order of reaction to optimize the graph appearances
    times = (Ci - concs)/k
elif n == 1:
    times = np.log(Ci/concs)/k
elif n == 2:
    times = (Ci - concs)/(concs*Ci*k)
elif n > 2:
    times = 1/(k*(n-1))*(concs**(-n+1) - Ci**(-n+1)) # general form of the integrated rate law for large n

fig, (ax1, ax2, ax3) = plt.subplots(1,3,figsize=(15,6))
fig.subplots_adjust(bottom=0.3, wspace = 0.5)
matplotlib.rcParams.update({'font.size': 16})
line, = ax1.plot(times,concs,color='b', linewidth = 2)
ax1.set(xlim = [0,max(times)], ylim = [0,1.05*Ci] )
ax1.set_xlabel(r'Time (s)', fontsize = 16)
ax1.set_ylabel('[' + compound + ']', fontsize = 16)
ax1.tick_params(labelsize=16)
ax1.grid()

line2, = ax2.plot(times,np.log(concs),color='b', linewidth = 2)
ax2.set(xlim = [0,max(times)], ylim = [min(np.log(concs)),max(np.log(concs))])
ax2.set_xlabel(r'Time (s)', fontsize = 16)
ax2.set_ylabel('ln([' + compound + '])', fontsize = 16)
ax2.tick_params(labelsize=16)
ax2.grid()

line3, = ax3.plot(times,1/concs,color='b', linewidth = 2)
ax3.set(xlim = [0,max(times)], ylim = [min(1/concs),max(1/concs)])
ax3.set_xlabel(r'Time (s)', fontsize = 16)
ax3.set_ylabel('1/[' + compound + ']', fontsize = 16)
ax3.tick_params(labelsize=16)
ax3.grid()

compound_ax = fig.add_axes([0.2, 0.025, 0.1, 0.05])
compound_txtbox = TextBox(compound_ax, r'Compound name: ', initial = 'A')
compound_txtbox.on_submit(update)

Ci_ax = fig.add_axes([0.2, 0.125, 0.1, 0.05])
Ci_txtbox = TextBox(Ci_ax, r'[compound]$_i$ (M): ', initial = Ci)
Ci_txtbox.on_submit(update)

frac_ax = fig.add_axes([0.75, 0.125, 0.1, 0.05])
frac_txtbox = TextBox(frac_ax, 'Fraction remaining: ', initial = frac)
frac_txtbox.on_submit(update)

k_ax = fig.add_axes([0.4, 0.125, 0.1, 0.05])
k_txtbox = TextBox(k_ax, r'$k$: ', initial = k)
k_txtbox.on_submit(update)

order_ax = fig.add_axes([0.75, 0.025, 0.1, 0.05])
order_txtbox = TextBox(order_ax, 'Reaction order: ', initial = n)
order_txtbox.on_submit(update)

ax_text = fig.add_axes([0.48, 0.92, 0.15, 0.05])
ax_text.axis('off')
ax_text.text(0, 0.0, compound + r" $\longrightarrow$ Products", fontsize = 16)

plt.show()
