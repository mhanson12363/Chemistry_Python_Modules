import numpy as np #import Numpy Package
import matplotlib.pyplot as plt #import matplotlib Package
from matplotlib.widgets import Button, Slider, TextBox

valid = False #initializes so the first call will happen
token = 0 #just initializes at a benign value
def get_token(): #allows neatly looping the program and 'talking' to the user
    valid = False #intitialized as False so the program will seek a valid value
    while valid == False: #keeps looping this until the user provides a valid token
        try: #only works if the user puts something that can be interpreted as an integer
            token = int(input('Which option would you like to use? Enter 0 for options: '))
            if (token in [i+1 for i in range(9)]):
                valid = True
            if token == 0: #lists out the options
                print('The following options are available for plots illustrating the titration curves:' + '\n')
                print('Enter 1:' + ' '*5 + '1 pKa value,' + ' '*2 + 'no derivative or speciation plot')
                print('Enter 2:' + ' '*5 + '2 pKa values, no derivative or speciation plot')
                print('Enter 3:' + ' '*5 + '3 pKa values, no derivative or speciation plot')
                print('Enter 4:' + ' '*5 + '1 pKa value,' + ' '*2 + 'with derivative plot')
                print('Enter 5:' + ' '*5 + '2 pKa values, with derivative plot')
                print('Enter 6:' + ' '*5 + '3 pKa values, with derivative plot')
                print('Enter 7:' + ' '*5 + '1 pKa value,' + ' '*2 + 'with speciation plot')
                print('Enter 8:' + ' '*5 + '2 pKa values, with speciation plot')
                print('Enter 9:' + ' '*5 + '3 pKa values, with speciation plot')
                print('Enter -1:' + ' '*4 + 'Ends the program' + '\n')
            if (token not in [i+1 for i in range(9)]) and (token != -1):
                valid = False
                print('Please enter a valid integer from 1-9 or -1 to quit the program.' + '\n')
            if token == -1:
                valid = True #lets the loop inside the function end
                print('Terminating program')
        except: #yells at the user for putting in an invalid entry
            valid = False
            print('Please enter a valid integer from 1-9 or -1 to quit the program.' + '\n')
    return token, valid

#tells the user the options right away so they don't have to ask for them
print('The following options are available for plots illustrating the titration curves:' + '\n')
print('Enter 1:' + ' '*5 + '1 pKa value,' + ' '*2 + 'no derivative or speciation plot')
print('Enter 2:' + ' '*5 + '2 pKa values, no derivative or speciation plot')
print('Enter 3:' + ' '*5 + '3 pKa values, no derivative or speciation plot')
print('Enter 4:' + ' '*5 + '1 pKa value,' + ' '*2 + 'with derivative plot')
print('Enter 5:' + ' '*5 + '2 pKa values, with derivative plot')
print('Enter 6:' + ' '*5 + '3 pKa values, with derivative plot')
print('Enter 7:' + ' '*5 + '1 pKa value,' + ' '*2 + 'with speciation plot')
print('Enter 8:' + ' '*5 + '2 pKa values, with speciation plot')
print('Enter 9:' + ' '*5 + '3 pKa values, with speciation plot')
print('Enter -1:' + ' '*4 + 'Ends the program' + '\n')

while (valid or valid == False) and (token != -1): #runs the programs until the user decides to kill the process by setting token = -1
    token, valid = get_token() #continues the loop
    if token == 1:
    #############
    # Program 1 #
    #############
        pka = 5.0 #initial
        V_a = 10.0 #volume of acid being titrated (mL)
        C_a = 0.1 #concentration of acid (M)
        C_b = 0.1 #concentration of base (M)

        # The function to be called anytime a slider's value changes
        def update(event):
            global pka, V_a, C_a, C_b
            try:
                pka = pka_slider.val
                V_a = float(txtBox1.text)
                C_a = float(txtBox2.text)
                C_b = float(txtBox3.text)
                if V_a <= 0 or C_a <= 0 or C_b <= 0:
                    raise ValueError
                V_b = data(pka, V_a, C_a, C_b)
                ax.set_xlim([0, 2*V_a*C_a/C_b])
                line.set_xdata(V_b)
                ax.set_xlim([0, 2*V_a*C_a/C_b])
            except ValueError:
                print("Please use valid positive values for the volume of acid and the concentration of acid and base.")
            
        def data(pka, V_a, C_a, C_b):
            pH = pH = np.linspace(0,14+np.log10(C_b),200) # range is set so it doesn't blow up!
            H = 10**(-pH) #concentration of H+ (M)
            OH = (10**(-14))/H #concentration of OH- (M)
            Ka=10**(-pka)
            d = H + Ka #denominator of proportions
            A_A = Ka/d #proportion in form A-
            phi_n = A_A - ((H - OH)/C_a) 
            phi_d = 1 + ((H - OH)/C_b) 
            phi = phi_n / phi_d 
            
            V_b = (phi*C_a*V_a)/C_b #Volume of base added that matches the pH based on ???
            return V_b

        #Initializing data
        pH = np.linspace(0,13,200) #using the pH values to figure out the volume added; range is set so it doesn't blow up!
        H = 10**(-pH) #concentration of H+ (M)
        OH = (10**(-14))/H #concentration of OH- (M)
        V_b = data(pka, V_a, C_a, C_b)

        #Initial plot
        fig, ax = plt.subplots(figsize=(10,6))
        fig.subplots_adjust(bottom=0.3)
        line, = ax.plot(V_b,pH,color='b', linewidth = 2, label='Titration Curve')
        #matplotlib.rcParams.update({'font.size': 16})
        ax.set_xlabel(r'$V$ base added (mL)')
        ax.set_ylabel('pH')
        ax.set_xlim([0, 2*V_a*C_a/C_b])
        plt.grid()

        #Slider for the pKa values
        sliderax = fig.add_axes([0.1,0.1,0.6,0.05]) #written in terms of fractions of the window; x start, y start, x width, y width
        pka_slider = Slider(
            sliderax,
            label=r'p$K_a$',
            valmin=0,
            valmax=13,
            valinit=5)

        #Textbox for volume of acid'
        graphBox1 = fig.add_axes([0.85, 0.15, 0.1, 0.05])
        txtBox1 = TextBox(graphBox1, '$V$ acid (mL) ', initial = 10.0)
        txtBox1.on_submit(update)

        #Textbox for concentration of acid'
        graphBox2 = fig.add_axes([0.85, 0.1, 0.1, 0.05])
        txtBox2 = TextBox(graphBox2, '[Acid] (M) ', initial = 0.1)
        txtBox2.on_submit(update)

        #Textbox for concentration of base'
        graphBox3 = fig.add_axes([0.85, 0.05, 0.1, 0.05])
        txtBox3 = TextBox(graphBox3, '[Base] (M) ', initial = 0.1)
        txtBox3.on_submit(update)

        # register the update function with each slider
        pka_slider.on_changed(update)

        plt.show()
    #################
    # Program 1 end #
    #################

    if token == 2:
    #############
    # Program 2 #
    #############
        pka1 = 3.0 #initial random values
        pka2 = 8.0
        V_a = 10 #volume of acid being titrated (mL)
        C_a = 0.1 #concentration of acid (M)
        C_b = 0.1 #concentration of base (M)

        # The function to be called anytime a slider's value changes
        def update(event):
            global pka1, pka2, V_a, C_a, C_b
            try:
                pka1 = pka1_slider.val
                pka2 = pka2_slider.val
                V_a = float(txtBox1.text)
                C_a = float(txtBox2.text)
                C_b = float(txtBox3.text)
                if V_a <= 0 or C_a <= 0 or C_b <= 0:
                    raise ValueError
                if pka1_slider.val > pka2_slider.val:
                    pka2_slider.set_val(pka1_slider.val)
                V_b = data(pka1_slider.val, pka2_slider.val, V_a, C_a, C_b)
                line.set_xdata(V_b)
                ax.set_xlim([0, 3*V_a*C_a/C_b])
            except ValueError:
                print("Please use valid positive values for the volume of acid and the concentration of acid and base.")

        def data(pka1, pka2, V_a, C_a, C_b):
            pH = pH = np.linspace(0,14+np.log10(C_b),200) # range is set so it doesn't blow up!
            H = 10**(-pH) #concentration of H+ (M)
            OH = (10**(-14))/H #concentration of OH- (M)
            Ka1=10**(-pka1) #first proton Ka value
            Ka2=10**(-pka2) #second proton Ka value
            d = H**2 + Ka1*H + Ka1*Ka2 #denominator of proportions
            A_HA = (H*Ka1)/d #proportion in form HA-
            A_A = (Ka1*Ka2)/d #proportion in form A-2
            phi_n = A_HA + 2*A_A - ((H - OH)/C_a) #numerator of Harris' formula
            phi_d = 1+ ((H - OH)/C_b) #denominator of Harris' formula
            phi = phi_n / phi_d # ratio from Harris' formula
            V_b = (phi*C_a*V_a)/C_b #Volume of base added that matches the pH based on Harris' formula
            return V_b

        #Initializing data
        pH = np.linspace(0,13,200) #using the pH values to figure out the volume added; range is set so it doesn't blow up!
        H = 10**(-pH) #concentration of H+ (M)
        OH = (10**(-14))/H #concentration of OH- (M)
        V_b = data(pka1, pka2, V_a, C_a, C_b)

        #Initial plot
        fig, ax = plt.subplots(figsize=(10,6))
        fig.subplots_adjust(bottom=0.3)
        line, = ax.plot(V_b,pH,color='b', linewidth = 2, label='Titration Curve')
        ax.set_xlabel(r'$V$ base added (mL)')
        ax.set_ylabel('pH')
        ax.set_xlim([0, 3*V_a*C_a/C_b])
        plt.grid()

        sliderax1 = fig.add_axes([0.1,0.1,0.6,0.05]) #written in terms of fractions of the window; x start, y start, x width, y width
        pka1_slider = Slider(
            sliderax1,
            label=r'p$K_{a1}$',
            valmin=0,
            valmax=13,
            valinit=3)

        sliderax2 = fig.add_axes([0.1,0.05,0.6,0.05])
        pka2_slider = Slider(
            sliderax2,
            label=r'p$K_{a2}$',
            valmin=0,
            valmax=13,
            valinit=8)

        #Textbox for volume of acid'
        graphBox1 = fig.add_axes([0.85, 0.125, 0.1, 0.05])
        txtBox1 = TextBox(graphBox1, '$V$ acid (mL) ', initial = 10.0)
        txtBox1.on_submit(update)

        #Textbox for concentration of acid'
        graphBox2 = fig.add_axes([0.85, 0.075, 0.1, 0.05])
        txtBox2 = TextBox(graphBox2, '[Acid] (M) ', initial = 0.1)
        txtBox2.on_submit(update)

        #Textbox for concentration of base'
        graphBox3 = fig.add_axes([0.85, 0.025, 0.1, 0.05])
        txtBox3 = TextBox(graphBox3, '[Base] (M) ', initial = 0.1)
        txtBox3.on_submit(update)

        # register the update function with each slider
        pka1_slider.on_changed(update)
        pka2_slider.on_changed(update)

        plt.show()
    #################
    # Program 2 end #
    #################

    if token == 3:
    #############
    # Program 3 #
    #############
        pka1 = 2.0 #initial
        pka2 = 5.0
        pka3 = 8.0
        V_a = 10 #volume of acid being titrated (mL)
        C_a = 0.1 #concentration of acid (M)
        C_b = 0.1 #concentration of base (M)

        # The function to be called anytime a slider's value changes
        def update(val):
            global pka1, pka2, pka3, V_a, C_a, C_b
            try:
                pka1 = pka1_slider.val
                pka2 = pka2_slider.val
                pka3 = pka3_slider.val
                V_a = float(txtBox1.text)
                C_a = float(txtBox2.text)
                C_b = float(txtBox3.text)
                if V_a <= 0 or C_a <= 0 or C_b <= 0:
                    raise ValueError
                if pka1_slider.val > pka2_slider.val:
                    pka2_slider.set_val(pka1_slider.val)
                if pka2_slider.val > pka3_slider.val:
                    pka3_slider.set_val(pka2_slider.val)
                V_b = data(pka1, pka2, pka3, V_a, C_a, C_b)
                line.set_xdata(V_b)
                ax.set_xlim([0, 4*V_a*C_a/C_b])
            except ValueError:
                print("Please use valid positive values for the volume of acid and the concentration of acid and base.")

        def data(pka1, pka2, pka3, V_a, C_a, C_b):
            pH = np.linspace(0,14+np.log10(C_b),200) # range is set so it doesn't blow up!
            H = 10**(-pH) #concentration of H+ (M)
            OH = (10**(-14))/H #concentration of OH- (M)
            Ka1=10**(-pka1) #first proton Ka value
            Ka2=10**(-pka2) #second proton Ka value
            Ka3=10**(-pka3) #third proton Ka value
            d = H**3 + Ka1*H**2 + Ka1*Ka2*H + Ka1*Ka2*Ka3 #denominator of proportions
            A_H2A = (H**2*Ka1)/d #proportion in form H2A-
            A_HA = (H*Ka1*Ka2)/d #proportion in form HA-2
            A_A = (Ka1*Ka2*Ka3)/d #proportion in form A-3
            phi_n = A_H2A + 2*A_HA + 3*A_A - ((H - OH)/C_a) #numerator of Harris' formula
            phi_d = 1 + ((H - OH)/C_b) #denominator of Harris' formula
            phi = phi_n / phi_d # Ratio from Harris' formula
            V_b = (phi*C_a*V_a)/C_b #Volume of base added that matches the pH based on Harris' formula
            return V_b

        #Initializing data
        pH = np.linspace(0,13,200) #using the pH values to figure out the volume added; range is set so it doesn't blow up!
        H = 10**(-pH) #concentration of H+ (M)
        OH = (10**(-14))/H #concentration of OH- (M)
        V_b = data(pka1, pka2, pka3, V_a, C_a, C_b)

        #Initial plot
        fig, ax = plt.subplots(figsize=(10,6))
        fig.subplots_adjust(bottom=0.3)
        line, = ax.plot(V_b,pH,color='b', linewidth = 2, label='Titration Curve')
        ax.set_xlabel(r'$V$ base added (mL)')
        ax.set_ylabel('pH')
        ax.set_xlim([0, 4*V_a*C_a/C_b])
        plt.grid()

        sliderax1 = fig.add_axes([0.1,0.15,0.6,0.05]) #written in terms of fractions of the window; x start, y start, x width, y width
        pka1_slider = Slider(
            sliderax1,
            label=r'p$K_{a1}$',
            valmin=0,
            valmax=13,
            valinit=2)

        sliderax2 = fig.add_axes([0.1,0.1,0.6,0.05])
        pka2_slider = Slider(
            sliderax2,
            label=r'p$K_{a2}$',
            valmin=0,
            valmax=13,
            valinit=5)

        sliderax3 = fig.add_axes([0.1,0.05,0.6,0.05])
        pka3_slider = Slider(
            sliderax3,
            label=r'p$K_{a3}$',
            valmin=0,
            valmax=13,
            valinit=8)

        #Textbox for volume of acid'
        graphBox1 = fig.add_axes([0.85, 0.15, 0.1, 0.05])
        txtBox1 = TextBox(graphBox1, '$V$ acid (mL) ', initial = 10.0)
        txtBox1.on_submit(update)

        #Textbox for concentration of acid'
        graphBox2 = fig.add_axes([0.85, 0.1, 0.1, 0.05])
        txtBox2 = TextBox(graphBox2, '[Acid] (M) ', initial = 0.1)
        txtBox2.on_submit(update)

        #Textbox for concentration of base'
        graphBox3 = fig.add_axes([0.85, 0.05, 0.1, 0.05])
        txtBox3 = TextBox(graphBox3, '[Base] (M) ', initial = 0.1)
        txtBox3.on_submit(update)

        # register the update function with each slider
        pka1_slider.on_changed(update)
        pka2_slider.on_changed(update)
        pka3_slider.on_changed(update)

        plt.show()
    #################
    # Program 3 end #
    #################

    if token == 4:
    #############
    # Program 4 #
    #############
        pka = 5.0 #initial
        V_a = 10.0 #volume of acid being titrated (mL)
        C_a = 0.1 #concentration of acid (M)
        C_b = 0.1 #concentration of base (M)

        # The function to be called anytime a slider's value changes
        def update(val):
            global pka, V_a, C_a, C_b
            try: 
                pka = pka_slider.val
                V_a = float(txtBox1.text)
                C_a = float(txtBox2.text)
                C_b = float(txtBox3.text)
                if V_a <= 0 or C_a <= 0 or C_b <= 0:
                    raise ValueError
                V_b, deriv, deriv_max  = data(pka, V_a, C_a, C_b)
                ax1.set_xlim([0, 2*V_a*C_a/C_b])
                ax2.set_xlim([0, 2*V_a*C_a/C_b])
                line.set_xdata(V_b)
                line2.set_xdata(V_b[1:len(V_b)-1])
                line2.set_ydata(deriv)
                ax2.set_ylim([-0.05*deriv_max, 1.1*deriv_max])
            except ValueError:
                print("Please use valid positive values for the volume of acid and the concentration of acid and base.")

        def data(pka, V_a, C_a, C_b):
            pH = pH = np.linspace(0,14+np.log10(C_b),200) # range is set so it doesn't blow up!
            H = 10**(-pH) #concentration of H+ (M)
            OH = (10**(-14))/H #concentration of OH- (M)
            Ka=10**(-pka)
            d = H + Ka #denominator of proportions
            A_A = Ka/d #proportion in form A-
            phi_n = A_A - ((H - OH)/C_a) #numerator of Harris' formula
            phi_d = 1 + ((H - OH)/C_b) #denominator of Harris' formula
            phi = phi_n / phi_d # Ratio from Harris' formula
            V_b = (phi*C_a*V_a)/C_b #Volume of base added that matches the pH based on Harris' formula
            
            deriv = []
            for i in range(len(V_b)-2):
                deriv.append((pH[i+2]-pH[i])/(V_b[i+2]-V_b[i])) #derivative of titration curve using central difference
            #finding derivative at equivalence point to set y limits since the low V can have a huge derivative sometimes
            diff = V_b - V_a*C_a/C_b #1st equivalence point is 0
            index = np.argsort(np.abs(diff))[0]
            deriv_max = deriv[index-1] #-1 since the first point is chopped out of deriv
            return V_b, deriv, deriv_max

        #Initializing data
        pH = np.linspace(0,13,200) #using the pH values to figure out the volume added; range is set so it doesn't blow up!
        H = 10**(-pH) #concentration of H+ (M)
        OH = (10**(-14))/H #concentration of OH- (M)
        V_b, deriv, deriv_max  = data(pka, V_a, C_a, C_b)

        #Initial plot
        fig, (ax1,ax2) = plt.subplots(1,2,figsize=(15,6))
        fig.subplots_adjust(bottom=0.3)
        line, = ax1.plot(V_b,pH,color='b', linewidth = 2, label='Titration Curve')
        ax1.set_xlabel(r'$V$ base added (mL)')
        ax1.set_ylabel('pH')
        ax1.set_xlim([0, 2*V_a*C_a/C_b])
        ax1.grid()
        line2, = ax2.plot(V_b[1:len(V_b)-1],deriv,color='r', linewidth = 2, label='Titration Curve Derivative')
        ax2.set_xlabel(r'$V$ base added (mL)')
        ax2.set_ylabel('Titration Curve Derivative')
        ax2.set_xlim([0, 2*V_a*C_a/C_b])
        ax2.set_ylim([-0.05*deriv_max, 1.1*deriv_max])
        ax2.grid()

        #Slider for the pKa values
        sliderax = fig.add_axes([0.1,0.1,0.6,0.05]) #written in terms of fractions of the window; x start, y start, x width, y width
        pka_slider = Slider(
            sliderax,
            label=r'p$K_a$',
            valmin=0,
            valmax=13,
            valinit=5)

        #Textbox for volume of acid'
        graphBox1 = fig.add_axes([0.85, 0.15, 0.1, 0.05])
        txtBox1 = TextBox(graphBox1, '$V$ acid (mL) ', initial = 10.0)
        txtBox1.on_submit(update)

        #Textbox for concentration of acid'
        graphBox2 = fig.add_axes([0.85, 0.1, 0.1, 0.05])
        txtBox2 = TextBox(graphBox2, '[Acid] (M) ', initial = 0.1)
        txtBox2.on_submit(update)

        #Textbox for concentration of base'
        graphBox3 = fig.add_axes([0.85, 0.05, 0.1, 0.05])
        txtBox3 = TextBox(graphBox3, '[Base] (M) ', initial = 0.1)
        txtBox3.on_submit(update)

        # register the update function with each slider
        pka_slider.on_changed(update)

        plt.show()
    #################
    # Program 4 end #
    #################

    if token == 5:
    #############
    # Program 5 #
    #############
        pka1 = 3.0 #initial random values
        pka2 = 8.0
        V_a = 10 #volume of acid being titrated (mL)
        C_a = 0.1 #concentration of acid (M)
        C_b = 0.1 #concentration of base (M)

        deriv_peak = True # True = max, False = min; default is max so both peaks show

        # The function to be called anytime a slider's value changes
        def update(event):
            global pka1, pka2, V_a, C_a, C_b
            try:
                pka1 = pka1_slider.val
                pka2 = pka2_slider.val
                V_a = float(txtBox1.text)
                C_a = float(txtBox2.text)
                C_b = float(txtBox3.text)
                if V_a <= 0 or C_a <= 0 or C_b <= 0:
                    raise ValueError
                if pka1_slider.val > pka2_slider.val:
                    pka2_slider.set_val(pka1_slider.val)
                V_b, deriv, deriv_max, deriv_min = data(pka1_slider.val, pka2_slider.val, V_a, C_a, C_b)
                ax1.set_xlim([0, 3*V_a*C_a/C_b])
                ax2.set_xlim([0, 3*V_a*C_a/C_b])
                line.set_xdata(V_b)
                line2.set_xdata(V_b[1:len(V_b)-1])
                line2.set_ydata(deriv)
                if deriv_peak:
                    ax2.set_ylim([-0.05*deriv_max, 1.1*deriv_max])
                if deriv_peak == False:
                    ax2.set_ylim([-0.05*deriv_min, 1.1*deriv_min])
            except ValueError:
                print("Please use valid positive values for the volume of acid and the concentration of acid and base.")

        def press(event): #function for the max button
            global deriv_peak
            deriv_peak = not deriv_peak
            if deriv_peak:
                ax2.set_ylim([-0.05*deriv_max, 1.1*deriv_max])
            if deriv_peak == False:
                ax2.set_ylim([-0.05*deriv_min, 1.1*deriv_min])

        def data(pka1, pka2, V_a, C_a, C_b):
            pH = pH = np.linspace(0,14+np.log10(C_b),200) # range is set so it doesn't blow up!
            H = 10**(-pH) #concentration of H+ (M)
            OH = (10**(-14))/H #concentration of OH- (M)
            Ka1=10**(-pka1) #first proton Ka value
            Ka2=10**(-pka2) #second proton Ka value
            d = H**2 + Ka1*H + Ka1*Ka2 #denominator of proportions
            A_HA = (H*Ka1)/d #proportion in form HA-
            A_A = (Ka1*Ka2)/d #proportion in form A-2
            phi_n = A_HA + 2*A_A - ((H - OH)/C_a) #numerator of Harris' formula
            phi_d = 1+ ((H - OH)/C_b) #denominator of Harris' formula
            phi = phi_n / phi_d # ratio from Harris' formula
            V_b = (phi*C_a*V_a)/C_b #Volume of base added that matches the pH based on Harris' formula
            
            deriv = []
            for i in range(len(V_b)-2):
                deriv.append((pH[i+2]-pH[i])/(V_b[i+2]-V_b[i])) #derivative of titration curve based on central finite differences; skips 1st point!
            #finding derivative at equivalence points to set y limits since the low V can have a huge derivative sometimes
            diff = np.abs(V_b - V_a*C_a/C_b) #1st equivalence point is set to 0
            index = np.argsort(diff)[0]-1 #finds where lowest value is
            max1 = deriv[index] #-1 since the first point is chopped out of deriv
            diff = np.abs(V_b - 2*V_a*C_a/C_b) #2nd equivalence point is set to 0
            index = np.argsort(diff)[0]-1 #finds where lowest value is; shift of -1 so it lines up with deriv
            max2 = deriv[index]
            deriv_max = max(max1,max2)
            deriv_min = min(max1,max2)
            return V_b, deriv, deriv_max, deriv_min

        #Initializing data
        pH = np.linspace(0,13,200) #using the pH values to figure out the volume added; range is set so it doesn't blow up!
        H = 10**(-pH) #concentration of H+ (M)
        OH = (10**(-14))/H #concentration of OH- (M)
        V_b, deriv, deriv_max, deriv_min = data(pka1, pka2, V_a, C_a, C_b)

        #Initial plot
        fig, (ax1, ax2) = plt.subplots(1,2,figsize=(15,6))
        fig.subplots_adjust(bottom=0.3)
        line, = ax1.plot(V_b,pH,color='b', linewidth = 2, label='Titration Curve')
        ax1.set_xlabel(r'$V$ base added (mL)')
        ax1.set_ylabel('pH')
        ax1.set_xlim([0, 3*V_a*C_a/C_b])
        ax1.grid()
        line2, = ax2.plot(V_b[1:len(V_b)-1],deriv,color='r', linewidth = 2, label='Titration Curve Derivative')
        ax2.set_xlabel(r'$V$ base added (mL)')
        ax2.set_ylabel('Titration Curve Derivative')
        ax2.set_xlim([0, 3*V_a*C_a/C_b])
        ax2.set_ylim([-0.05*deriv_max, 1.1*deriv_max])
        ax2.grid()

        sliderax1 = fig.add_axes([0.1,0.1,0.5,0.05]) #written in terms of fractions of the window; x start, y start, x width, y width
        pka1_slider = Slider(
            sliderax1,
            label=r'p$K_{a1}$',
            valmin=0,
            valmax=13,
            valinit=3)

        sliderax2 = fig.add_axes([0.1,0.05,0.5,0.05])
        pka2_slider = Slider(
            sliderax2,
            label=r'p$K_{a2}$',
            valmin=0,
            valmax=13,
            valinit=8)

        # Switch scale to max/min button
        buttonloc = fig.add_axes([0.65, 0.075, 0.1, 0.04])
        button = Button(buttonloc, 'Scaling', color='cyan', hovercolor='red')
        button.on_clicked(press)

        #Textbox for volume of acid'
        graphBox1 = fig.add_axes([0.85, 0.125, 0.1, 0.05])
        txtBox1 = TextBox(graphBox1, '$V$ acid (mL) ', initial = 10.0)
        txtBox1.on_submit(update)

        #Textbox for concentration of acid'
        graphBox2 = fig.add_axes([0.85, 0.075, 0.1, 0.05])
        txtBox2 = TextBox(graphBox2, '[Acid] (M) ', initial = 0.1)
        txtBox2.on_submit(update)

        #Textbox for concentration of base'
        graphBox3 = fig.add_axes([0.85, 0.025, 0.1, 0.05])
        txtBox3 = TextBox(graphBox3, '[Base] (M) ', initial = 0.1)
        txtBox3.on_submit(update)

        # register the update function with each slider
        pka1_slider.on_changed(update)
        pka2_slider.on_changed(update)

        plt.show()
    #################
    # Program 5 end #
    #################

    if token == 6:
    #############
    # Program 6 #
    #############
        pka1 = 2.0 #initial
        pka2 = 5.0
        pka3 = 8.0
        V_a = 10 #volume of acid being titrated (mL)
        C_a = 0.1 #concentration of acid (M)
        C_b = 0.1 #concentration of base (M)

        deriv_peak = True # True = max, False = min; default is max so both peaks show

        # The function to be called anytime a slider's value changes
        def update(event):
            global pka1, pka2, pka3, V_a, C_a, C_b
            try:
                pka1 = pka1_slider.val
                pka2 = pka2_slider.val
                pka3 = pka3_slider.val
                V_a = float(txtBox1.text)
                C_a = float(txtBox2.text)
                C_b = float(txtBox3.text)
                if V_a <= 0 or C_a <= 0 or C_b <= 0:
                    raise ValueError
                if pka1_slider.val > pka2_slider.val:
                    pka2_slider.set_val(pka1_slider.val)
                if pka2_slider.val > pka3_slider.val:
                    pka3_slider.set_val(pka2_slider.val)
                V_b, deriv, deriv_max, deriv_min = data(pka1, pka2, pka3, V_a, C_a, C_b)
                line.set_xdata(V_b)
                ax1.set_xlim([0, 4*V_a*C_a/C_b])
                ax2.set_xlim([0, 4*V_a*C_a/C_b])
                line2.set_xdata(V_b[1:len(V_b)-1])
                line2.set_ydata(deriv)
                if deriv_peak == 'max':
                    ax2.set_ylim([-0.05*deriv_max, 1.1*deriv_max])
                if deriv_peak == 'min':
                    ax2.set_ylim([-0.05*deriv_min, 1.1*deriv_min])
            except ValueError:
                print("Please use valid positive values for the volume of acid and the concentration of acid and base.")

        def press(event): #function for the max button
            global deriv_peak
            deriv_peak = not deriv_peak
            if deriv_peak:
                ax2.set_ylim([-0.05*deriv_max, 1.1*deriv_max])
            if deriv_peak == False:
                ax2.set_ylim([-0.05*deriv_min, 1.1*deriv_min])

        def data(pka1, pka2, pka3, V_a, C_a, C_b):
            pH = pH = np.linspace(0,14+np.log10(C_b),200) # range is set so it doesn't blow up!
            H = 10**(-pH) #concentration of H+ (M)
            OH = (10**(-14))/H #concentration of OH- (M)
            Ka1=10**(-pka1) #first proton Ka value
            Ka2=10**(-pka2) #second proton Ka value
            Ka3=10**(-pka3) #third proton Ka value
            d = H**3 + Ka1*H**2 + Ka1*Ka2*H + Ka1*Ka2*Ka3 #denominator of proportions
            A_H2A = (H**2*Ka1)/d #proportion in form H2A-
            A_HA = (H*Ka1*Ka2)/d #proportion in form HA-2
            A_A = (Ka1*Ka2*Ka3)/d #proportion in form A-3
            phi_n = A_H2A + 2*A_HA + 3*A_A - ((H - OH)/C_a) # numerator from Harris' formula
            phi_d = 1 + ((H - OH)/C_b) # denominator from Harris' formula
            phi = phi_n / phi_d # ratio from Harris' formula
            V_b = (phi*C_a*V_a)/C_b #Volume of base added that matches the pH based on Harris
            deriv = []
            for i in range(len(V_b)-2):
                deriv.append((pH[i+2]-pH[i])/(V_b[i+2]-V_b[i])) #derivative of titration curve based on central finite differences
            #finding derivative at equivalence points to set y limits since the low V can have a huge derivative sometimes
            diff = V_b - V_a*C_a/C_b #1st equivalence point is 0
            index = np.argsort(np.abs(diff))[0]
            max1 = deriv[index-1] #-1 since the first point is chopped out of deriv
            diff = V_b - 2*V_a*C_a/C_b #2nd equivalence point is 0
            index = np.argsort(np.abs(diff))[0]
            max2 = deriv[index-1] #-1 since the first point is chopped out of deriv
            diff = V_b - 3*V_a*C_a/C_b #2nd equivalence point is 0
            index = np.argsort(np.abs(diff))[0]
            max3 = deriv[index-1] #-1 since the first point is chopped out of deriv
            deriv_max = max(max1,max2,max3)
            deriv_min = min(max1,max2,max3)
            return V_b, deriv, deriv_max, deriv_min

        #Initializing data
        pH = np.linspace(0,13,200) #using the pH values to figure out the volume added; range is set so it doesn't blow up!
        H = 10**(-pH) #concentration of H+ (M)
        OH = (10**(-14))/H #concentration of OH- (M)
        V_b, deriv, deriv_max, deriv_min = data(pka1, pka2, pka3, V_a, C_a, C_b)

        #Initial plot
        fig, (ax1, ax2) = plt.subplots(1,2,figsize=(15,6))
        fig.subplots_adjust(bottom=0.3)
        line, = ax1.plot(V_b,pH,color='b', linewidth = 2, label='Titration Curve')
        ax1.set_xlabel(r'$V$ base added (mL)')
        ax1.set_ylabel('pH')
        ax1.set_xlim([0, 4*V_a*C_a/C_b])
        ax1.grid()
        line2, = ax2.plot(V_b[1:len(V_b)-1],deriv,color='r', linewidth = 2, label='Titration Curve Derivative')
        ax2.set_xlabel(r'$V$ base added (mL)')
        ax2.set_ylabel('Titration Curve Derivative')
        ax2.set_xlim([0, 4*V_a*C_a/C_b])
        ax2.set_ylim([-0.05*deriv_max, 1.1*deriv_max])
        ax2.grid()

        # Switch scale to max/min button
        buttonloc = fig.add_axes([0.65, 0.1, 0.1, 0.04])
        button = Button(buttonloc, 'Scaling', hovercolor='1')
        button.on_clicked(press)

        sliderax1 = fig.add_axes([0.1,0.15,0.5,0.05]) #written in terms of fractions of the window; x start, y start, x width, y width
        pka1_slider = Slider(
            sliderax1,
            label=r'p$K_{a1}$',
            valmin=0,
            valmax=13,
            valinit=2)

        sliderax2 = fig.add_axes([0.1,0.1,0.5,0.05])
        pka2_slider = Slider(
            sliderax2,
            label=r'p$K_{a2}$',
            valmin=0,
            valmax=13,
            valinit=5)

        sliderax3 = fig.add_axes([0.1,0.05,0.5,0.05])
        pka3_slider = Slider(
            sliderax3,
            label=r'p$K_{a3}$',
            valmin=0,
            valmax=13,
            valinit=8)

        #Textbox for volume of acid'
        graphBox1 = fig.add_axes([0.85, 0.15, 0.1, 0.05])
        txtBox1 = TextBox(graphBox1, '$V$ acid (mL) ', initial = 10.0)
        txtBox1.on_submit(update)

        #Textbox for concentration of acid'
        graphBox2 = fig.add_axes([0.85, 0.1, 0.1, 0.05])
        txtBox2 = TextBox(graphBox2, '[Acid] (M) ', initial = 0.1)
        txtBox2.on_submit(update)

        #Textbox for concentration of base'
        graphBox3 = fig.add_axes([0.85, 0.05, 0.1, 0.05])
        txtBox3 = TextBox(graphBox3, '[Base] (M) ', initial = 0.1)
        txtBox3.on_submit(update)

        # register the update function with each slider
        pka1_slider.on_changed(update)
        pka2_slider.on_changed(update)
        pka3_slider.on_changed(update)

        plt.show()
    #################
    # Program 6 end #
    #################

    if token == 7:
    #############
    # Program 7 #
    #############
        pka = 5.0 #initial
        V_a = 10.0 #volume of acid being titrated (mL)
        C_a = 0.1 #concentration of acid (M)
        C_b = 0.1 #concentration of base (M)

        # The function to be called anytime a slider's value changes
        def update(val):
            global pka, V_a, C_a, C_b
            try: 
                pka = pka_slider.val
                V_a = float(txtBox1.text)
                C_a = float(txtBox2.text)
                C_b = float(txtBox3.text)
                if V_a <= 0 or C_a <= 0 or C_b <= 0:
                    raise ValueError
                V_b, C_HA, C_Amin = data(pka, V_a, C_a, C_b)
                ax1.set_xlim([0, 2*V_a*C_a/C_b])
                line.set_xdata(V_b)
                line2.set_xdata(V_b)
                line2.set_ydata(C_HA)
                line3.set_xdata(V_b)
                line3.set_ydata(C_Amin)
                ax2.set_xlim([0, 2*V_a*C_a/C_b])
                ax2.set_ylim([-0.05*C_a, 1.05*C_a])
            except ValueError:
                print("Please use valid positive values for the volume of acid and the concentration of acid and base.")

        def data(pka, V_a, C_a, C_b):
            pH = pH = np.linspace(0,14+np.log10(C_b),200) # range is set so it doesn't blow up!
            H = 10**(-pH) #concentration of H+ (M)
            OH = (10**(-14))/H #concentration of OH- (M)
            Ka=10**(-pka)
            d = H + Ka #denominator of proportions
            A_A = Ka/d #proportion in form A-
            phi_n = A_A - ((H - OH)/C_a) #numerator of Harris' formula
            phi_d = 1 + ((H - OH)/C_b) #denominator of Harris' formula
            phi = phi_n / phi_d # ratio from Harris' formula
            V_b = (phi*C_a*V_a)/C_b #Volume of base added that matches the pH based on Harris' formula

            C_HA = C_a*V_a/(V_a+V_b)*(1+10**(pH-pka))**-1 # speciation based on HH equation
            C_Amin = C_a*V_a/(V_a+V_b) - C_HA # using the total equation
            return V_b, C_HA, C_Amin

        #Initializing data
        pH = np.linspace(0,13,200) #using the pH values to figure out the volume added; range is set so it doesn't blow up!
        H = 10**(-pH) #concentration of H+ (M)
        OH = (10**(-14))/H #concentration of OH- (M)
        V_b, C_HA, C_Amin  = data(pka, V_a, C_a, C_b)

        #Initial plot
        fig, (ax1,ax2) = plt.subplots(1,2,figsize=(15,6))
        fig.subplots_adjust(bottom=0.3)
        line, = ax1.plot(V_b,pH,color='b', linewidth = 2, label='Titration Curve')
        ax1.set_xlabel(r'$V$ base added (mL)')
        ax1.set_ylabel('pH')
        ax1.set_xlim([0, 2*V_a*C_a/C_b])
        ax1.grid()
        line2, = ax2.plot(V_b, C_HA, color='r', linewidth = 2, label=r'[HA] (M)')
        line3, = ax2.plot(V_b, C_Amin, color='r', linewidth = 2, linestyle = '--', label=r'[A$^-$] (M)')
        ax2.set_xlabel(r'$V$ base added (mL)')
        ax2.set_ylabel('Species Concentration (M)')
        ax2.set_xlim([0, 2*V_a*C_a/C_b])
        ax2.set_ylim([-0.05*C_a, 1.05*C_a])
        ax2.grid()
        ax2.legend()

        #Slider for the pKa values
        sliderax = fig.add_axes([0.1,0.1,0.6,0.05]) #written in terms of fractions of the window; x start, y start, x width, y width
        pka_slider = Slider(
            sliderax,
            label=r'p$K_a$',
            valmin=0,
            valmax=13,
            valinit=5)

        #Textbox for volume of acid'
        graphBox1 = fig.add_axes([0.85, 0.15, 0.1, 0.05])
        txtBox1 = TextBox(graphBox1, '$V$ acid (mL) ', initial = 10.0)
        txtBox1.on_submit(update)

        #Textbox for concentration of acid'
        graphBox2 = fig.add_axes([0.85, 0.1, 0.1, 0.05])
        txtBox2 = TextBox(graphBox2, '[Acid] (M) ', initial = 0.1)
        txtBox2.on_submit(update)

        #Textbox for concentration of base'
        graphBox3 = fig.add_axes([0.85, 0.05, 0.1, 0.05])
        txtBox3 = TextBox(graphBox3, '[Base] (M) ', initial = 0.1)
        txtBox3.on_submit(update)

        # register the update function with each slider
        pka_slider.on_changed(update)

        plt.show()
    #################
    # Program 7 end #
    #################

    if token == 8:
    #############
    # Program 8 #
    #############
        pka1 = 3.0 #initial random values
        pka2 = 8.0
        V_a = 10 #volume of acid being titrated (mL)
        C_a = 0.1 #concentration of acid (M)
        C_b = 0.1 #concentration of base (M)

        # The function to be called anytime a slider's value changes
        def update(event):
            global pka1, pka2, V_a, C_a, C_b, pH
            try:
                pka1 = pka1_slider.val
                pka2 = pka2_slider.val
                V_a = float(txtBox1.text)
                C_a = float(txtBox2.text)
                C_b = float(txtBox3.text)
                if V_a <= 0 or C_a <= 0 or C_b <= 0:
                    raise ValueError
                if pka1_slider.val > pka2_slider.val:
                    pka2_slider.set_val(pka1_slider.val)
                V_b, C_H2A, C_HAmin, C_Amin2 = data(pka1_slider.val, pka2_slider.val, V_a, C_a, C_b)
                ax1.set_xlim([0, 3*V_a*C_a/C_b])
                line.set_xdata(V_b)

                line2.set_xdata(V_b)
                line2.set_ydata(C_H2A)
                line3.set_xdata(V_b)
                line3.set_ydata(C_HAmin)
                line4.set_xdata(V_b)
                line4.set_ydata(C_Amin2)
                ax2.set_xlim([0, 3*V_a*C_a/C_b])
                ax2.set_ylim([-0.05*C_a, 1.05*C_a])
            except ValueError:
                print("Please use valid positive values for the volume of acid and the concentration of acid and base.")

        def data(pka1, pka2, V_a, C_a, C_b):
            pH = pH = np.linspace(0,14+np.log10(C_b),200) # range is set so it doesn't blow up!
            H = 10**(-pH) #concentration of H+ (M)
            OH = (10**(-14))/H #concentration of OH- (M)
            Ka1=10**(-pka1) #first proton Ka value
            Ka2=10**(-pka2) #second proton Ka value
            d = H**2 + Ka1*H + Ka1*Ka2 #denominator of proportions
            A_HA = (H*Ka1)/d #proportion in form HA-
            A_A = (Ka1*Ka2)/d #proportion in form A-2
            phi_n = A_HA + 2*A_A - ((H - OH)/C_a) #numerator of Harris' formula
            phi_d = 1+ ((H - OH)/C_b) #denominator of Harris' formula
            phi = phi_n / phi_d # ratio from Harris' formula
            V_b = (phi*C_a*V_a)/C_b #Volume of base added that matches the pH based on Harris' formula

            C_H2A = C_a*V_a/(V_a+V_b)*(1 + 10**(pH-pka1) + 10**(2*pH-pka1-pka2))**-1
            C_HAmin = C_H2A*10**(pH-pka1)
            C_Amin2 = C_a*V_a/(V_a+V_b) - C_H2A - C_HAmin
            return V_b, C_H2A, C_HAmin, C_Amin2

        #Initializing data
        pH = np.linspace(0,13,200) #using the pH values to figure out the volume added; range is set so it doesn't blow up!
        H = 10**(-pH) #concentration of H+ (M)
        OH = (10**(-14))/H #concentration of OH- (M)
        V_b, C_H2A, C_HAmin, C_Amin2 = data(pka1, pka2, V_a, C_a, C_b)

        #Initial plot
        fig, (ax1, ax2) = plt.subplots(1,2,figsize=(15,6))
        fig.subplots_adjust(bottom=0.3)
        line, = ax1.plot(V_b,pH,color='b', linewidth = 2, label='Titration Curve')
        ax1.set_xlabel(r'$V$ base added (mL)')
        ax1.set_ylabel('pH')
        ax1.set_xlim([0, 3*V_a*C_a/C_b])
        ax1.grid()
        line2, = ax2.plot(V_b, C_H2A, color='r', linewidth = 2, label=r'[H$_2$A] (M)')
        line3, = ax2.plot(V_b, C_HAmin, color='r', linewidth = 2, linestyle = '--', label=r'[HA$^-$] (M)')
        line4, = ax2.plot(V_b, C_Amin2, color='r', linewidth = 2, linestyle = ':', label=r'[A$^{2-}$] (M)')
        ax2.set_xlabel(r'$V$ base added (mL)')
        ax2.set_ylabel('Species Concentration (M)')
        ax2.set_xlim([0, 3*V_a*C_a/C_b])
        ax2.set_ylim([-0.05*C_a, 1.05*C_a])
        ax2.grid()
        ax2.legend()

        sliderax1 = fig.add_axes([0.1,0.1,0.6,0.05]) #written in terms of fractions of the window; x start, y start, x width, y width
        pka1_slider = Slider(
            sliderax1,
            label=r'p$K_{a1}$',
            valmin=0,
            valmax=13,
            valinit=3)

        sliderax2 = fig.add_axes([0.1,0.05,0.6,0.05])
        pka2_slider = Slider(
            sliderax2,
            label=r'p$K_{a2}$',
            valmin=0,
            valmax=13,
            valinit=8)

        #Textbox for volume of acid'
        graphBox1 = fig.add_axes([0.85, 0.125, 0.1, 0.05])
        txtBox1 = TextBox(graphBox1, '$V$ acid (mL) ', initial = 10.0)
        txtBox1.on_submit(update)

        #Textbox for concentration of acid'
        graphBox2 = fig.add_axes([0.85, 0.075, 0.1, 0.05])
        txtBox2 = TextBox(graphBox2, '[Acid] (M) ', initial = 0.1)
        txtBox2.on_submit(update)

        #Textbox for concentration of base'
        graphBox3 = fig.add_axes([0.85, 0.025, 0.1, 0.05])
        txtBox3 = TextBox(graphBox3, '[Base] (M) ', initial = 0.1)
        txtBox3.on_submit(update)

        # register the update function with each slider
        pka1_slider.on_changed(update)
        pka2_slider.on_changed(update)

        plt.show()
    #################
    # Program 8 end #
    #################

    if token == 9:
    #############
    # Program 9 #
    #############
        pka1 = 2.0 #initial
        pka2 = 5.0
        pka3 = 8.0
        V_a = 10 #volume of acid being titrated (mL)
        C_a = 0.1 #concentration of acid (M)
        C_b = 0.1 #concentration of base (M)

        # The function to be called anytime a slider's value changes
        def update(event):
            global pka1, pka2, pka3, V_a, C_a, C_b
            try:
                pka1 = pka1_slider.val
                pka2 = pka2_slider.val
                pka3 = pka3_slider.val
                V_a = float(txtBox1.text)
                C_a = float(txtBox2.text)
                C_b = float(txtBox3.text)
                if V_a <= 0 or C_a <= 0 or C_b <= 0:
                    raise ValueError
                if pka1_slider.val > pka2_slider.val:
                    pka2_slider.set_val(pka1_slider.val)
                if pka2_slider.val > pka3_slider.val:
                    pka3_slider.set_val(pka2_slider.val)
                V_b, C_H3A, C_H2Amin, C_HAmin2, C_Amin3 = data(pka1, pka2, pka3, V_a, C_a, C_b)
                line.set_xdata(V_b)
                ax1.set_xlim([0, 4*V_a*C_a/C_b])
                line2.set_xdata(V_b)
                line2.set_ydata(C_H3A)
                line3.set_xdata(V_b)
                line3.set_ydata(C_H2Amin)
                line4.set_xdata(V_b)
                line4.set_ydata(C_HAmin2)
                line5.set_xdata(V_b)
                line5.set_ydata(C_Amin3)
                ax2.set_xlim([0, 4*V_a*C_a/C_b])
                ax2.set_ylim([-0.05*C_a, 1.05*C_a])
            except ValueError:
                print("Please use valid positive values for the volume of acid and the concentration of acid and base.")

        def data(pka1, pka2, pka3, V_a, C_a, C_b):
            pH = pH = np.linspace(0,14+np.log10(C_b),200) # range is set so it doesn't blow up!
            H = 10**(-pH) #concentration of H+ (M)
            OH = (10**(-14))/H #concentration of OH- (M)
            Ka1=10**(-pka1) #first proton Ka value
            Ka2=10**(-pka2) #second proton Ka value
            Ka3=10**(-pka3) #third proton Ka value
            d = H**3 + Ka1*H**2 + Ka1*Ka2*H + Ka1*Ka2*Ka3 #denominator of proportions
            A_H2A = (H**2*Ka1)/d #proportion in form H2A-
            A_HA = (H*Ka1*Ka2)/d #proportion in form HA-2
            A_A = (Ka1*Ka2*Ka3)/d #proportion in form A-3
            phi_n = A_H2A + 2*A_HA + 3*A_A - ((H - OH)/C_a) # Numerator from Harris' formula
            phi_d = 1 + ((H - OH)/C_b) # demoninator of Harris' formula
            phi = phi_n / phi_d # ratio from Harris' formula
            V_b = (phi*C_a*V_a)/C_b #Volume of base added that matches the pH based on Harris

            C_H3A = C_a*V_a/(V_a+V_b)*(1 + 10**(pH-pka1) + 10**(2*pH-pka1-pka2) + 10**(3*pH-pka1-pka2-pka3))**-1
            C_H2Amin = C_H3A*10**(pH-pka1)
            C_HAmin2 = C_H3A*10**(2*pH-pka1-pka2)
            C_Amin3 = C_a*V_a/(V_a+V_b) - C_H3A - C_H2Amin - C_HAmin2
            return V_b, C_H3A, C_H2Amin, C_HAmin2, C_Amin3

        #Initializing data
        pH = np.linspace(0,13,200) #using the pH values to figure out the volume added; range is set so it doesn't blow up!
        H = 10**(-pH) #concentration of H+ (M)
        OH = (10**(-14))/H #concentration of OH- (M)
        V_b, C_H3A, C_H2Amin, C_HAmin2, C_Amin3 = data(pka1, pka2, pka3, V_a, C_a, C_b)

        #Initial plot
        fig, (ax1, ax2) = plt.subplots(1,2,figsize=(15,6))
        fig.subplots_adjust(bottom=0.3)
        line, = ax1.plot(V_b,pH,color='b', linewidth = 2, label='Titration Curve')
        ax1.set_xlabel(r'$V$ base added (mL)')
        ax1.set_ylabel('pH')
        ax1.set_xlim([0, 4*V_a*C_a/C_b])
        ax1.grid()
        line2, = ax2.plot(V_b, C_H3A, color='r', linewidth = 2, label=r'[H$_3$A] (M)')
        line3, = ax2.plot(V_b, C_H2Amin, color='r', linewidth = 2, linestyle = '--', label=r'[H$_2$A$^-$] (M)')
        line4, = ax2.plot(V_b, C_HAmin2, color='r', linewidth = 2, linestyle = ':', label=r'[HA$^{2-}$] (M)')
        line5, = ax2.plot(V_b, C_Amin3, color='r', linewidth = 2, linestyle = '-.', label=r'[A$^{3-}$] (M)')
        ax2.set_xlabel(r'$V$ base added (mL)')
        ax2.set_ylabel('Species Concentration (M)')
        ax2.set_xlim([0, 4*V_a*C_a/C_b])
        ax2.set_ylim([-0.05*C_a, 1.05*C_a])
        ax2.grid()
        ax2.legend()

        sliderax1 = fig.add_axes([0.1,0.15,0.6,0.05]) #written in terms of fractions of the window; x start, y start, x width, y width
        pka1_slider = Slider(
            sliderax1,
            label=r'p$K_{a1}$',
            valmin=0,
            valmax=13,
            valinit=2)

        sliderax2 = fig.add_axes([0.1,0.1,0.6,0.05])
        pka2_slider = Slider(
            sliderax2,
            label=r'p$K_{a2}$',
            valmin=0,
            valmax=13,
            valinit=5)

        sliderax3 = fig.add_axes([0.1,0.05,0.6,0.05])
        pka3_slider = Slider(
            sliderax3,
            label=r'p$K_{a3}$',
            valmin=0,
            valmax=13,
            valinit=8)

        #Textbox for volume of acid'
        graphBox1 = fig.add_axes([0.85, 0.15, 0.1, 0.05])
        txtBox1 = TextBox(graphBox1, '$V$ acid (mL) ', initial = 10.0)
        txtBox1.on_submit(update)

        #Textbox for concentration of acid'
        graphBox2 = fig.add_axes([0.85, 0.1, 0.1, 0.05])
        txtBox2 = TextBox(graphBox2, '[Acid] (M) ', initial = 0.1)
        txtBox2.on_submit(update)

        #Textbox for concentration of base'
        graphBox3 = fig.add_axes([0.85, 0.05, 0.1, 0.05])
        txtBox3 = TextBox(graphBox3, '[Base] (M) ', initial = 0.1)
        txtBox3.on_submit(update)

        # register the update function with each slider
        pka1_slider.on_changed(update)
        pka2_slider.on_changed(update)
        pka3_slider.on_changed(update)

        plt.show()
    #################
    # Program 9 end #
    #################
