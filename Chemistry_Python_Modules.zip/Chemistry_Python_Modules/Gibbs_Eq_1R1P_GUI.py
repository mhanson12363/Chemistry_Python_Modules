import numpy as np
import matplotlib
import matplotlib.pyplot as plt
from matplotlib.widgets import TextBox, Button

#constants
R = 8.314 #J/(mol*K)

#initial values
a = 1
b = 1
Ai = 1
Bi = 1
Keq = 1
T = 298.15 #K
step = 0.001 #amount of steps between adjacent concentrations, gives the resolution

x_axis_mode = 'A'

def rxn_calcs(a, b, Ai, Bi, Keq, T, step):
    try:
        N = int((Ai+a*Bi/b-2*step)/step)+1 #determines how many steps between concentrations
        if N <= 1:
            raise ValueError
        As = np.linspace(step, Ai+a*Bi/b-step, N)
        Bs = np.zeros(N) #empty but right shape
        for i in range(N):
            Bs[i] = Bi+b/a*(Ai-As[i]) #reaction stoichiometry; if A is consumed then B is increased
        Qs = np.zeros(N)
        dGs = np.zeros(N)
        Gs = np.zeros(N)
        for i in range(N):
            Qs[i] = (Bs[i]**b)/(As[i]**a) #regular equilibrium constant expression
        for i in range(N):
            dGs[i] = 8.314*T/1000*np.log(Qs[i]/Keq) #written in kJ/mol
        min_index = np.where(np.abs(dGs) == min(np.abs(dGs))) #finds closest value to Delta G=0
        min_index = int(min_index[0][0]) #makes it a regular integer
        for i in range(N-min_index-1):
            Gs[min_index+i+1] = Gs[min_index+i] - step*dGs[min_index+i+1] #estimates points after equilibrium
        for i in range(min_index):
            Gs[min_index-i-1] = Gs[min_index-i] + step*dGs[min_index-i-1] #estimates points before equilibrium
        return As, Bs, Qs, dGs, Gs
    except ValueError:
        print('The calculation encountered an error. Ensure that your step size is small enough for the concentrations used.')


def plot_all(ax1, ax2, ax3):
    try:
        As, Bs, Qs, dGs, Gs = rxn_calcs(a, b, Ai, Bi, Keq, T, step)
        for ax in [ax1, ax2, ax3]:
           ax.clear()
        A_label = r'A'
        if x_axis_mode == 'A':
            x_vals = As
            x_label = r'[' + A_label + '] (M)'
        else:
            x_vals = Bs
            x_label = r'[' + 'B' + '] (M)'

        ax1.plot([0, max(x_vals)], [Keq, Keq], color = 'b', linewidth = 2, linestyle = '--', label = '$K_{eq}$')
        ax1.plot(x_vals, Qs, color = 'darkorange', linewidth = 2, label = 'Q')
        ax1.set_xlabel(x_label)
        ax1.set_ylabel(r'$Q$')
        ax1.set(xlim = [0, max(x_vals)], ylim = [0.1*Keq, 5*Keq])
        ax1.tick_params(labelsize=16)
        ax1.legend()
        ax1.grid()

        ax2.plot([0,max(x_vals)],[0,0], color='b', linewidth = 2, linestyle='--', label=r'$\Delta G_{rxn} = 0$')
        ax2.plot(x_vals, dGs, color = 'darkorange', linewidth = 2, label = r'$\Delta G_{rxn}$')
        ax2.set_xlabel(x_label)
        ax2.set_ylabel(r'$\Delta G_{rxn}$ (kJ/mol)')
        ax2.set(xlim = [0,max(x_vals)], ylim = [1.05*min(dGs),1.05*max(dGs)] )
        ax2.tick_params(labelsize=16)
        ax2.legend()
        ax2.grid()

        ax3.plot([0,max(x_vals)],[0,0],color='b', linewidth = 2, linestyle='--', label='Relative $G = 0$')
        ax3.plot(x_vals, Gs, color='darkorange', linewidth = 2, label = 'Relative $G$')
        ax3.set_xlabel(x_label)
        ax3.set_ylabel(r'Relative $G$ (kJ/mol)')
        ax3.set(xlim = [0,max(x_vals)], ylim = [-0.05*max(Gs),1.05*max(Gs)] )
        ax3.tick_params(labelsize=16)
        ax3.legend()
        ax3.grid()
        
        plt.draw() 
    except:
        print('Error updating plots; nothing has been changed.') 

fig, (ax1, ax2, ax3) = plt.subplots(1,3, figsize = (15,6))
fig.subplots_adjust(bottom=0.3, wspace = 0.5)
plot_all(ax1, ax2, ax3)

def submit(event):
    global Keq, a, b, Ai, Bi, T, step
    try:
        Keq = float(text_box_Keq.text)
        a = int(text_box_a.text)
        b = int(text_box_b.text)
        Ai = float(text_box_Ai.text)
        Bi = float(text_box_Bi.text)
        T = float(text_box_T.text)
        step = float(text_box_step.text)
        if a <= 0 or b <= 0 or Ai < 0 or Bi < 0 or T <= 0 or Keq <= 0 or (Ai == 0 and Bi == 0) or step <= 0:
            raise ValueError
        plot_all(ax1, ax2, ax3)
    except ValueError:
        print('The values of a, b, the initial concentrations, the equilibrium constant, and the temperature must be positive.')
        print('Only one of the initial concentrations is allowed to be 0.')

def button(event):
    global x_axis_mode
    x_axis_mode = 'B' if x_axis_mode == 'A' else 'A'
    plot_all(ax1, ax2, ax3)  

xstart = 0.15 # used for making the box positions more easily
xstep = 0.2

#Keq textbox
axbox_Keq = plt.axes([xstart,0.025,0.05,0.06])
text_box_Keq = TextBox(axbox_Keq, r'$K_{eq}$', initial = str(Keq), label_pad = 0.05)

#T textbox
axbox_T = plt.axes([xstart, 0.125, 0.05, 0.06])
text_box_T = TextBox(axbox_T, r'$T$ (K)', initial=str(T), label_pad = 0.05)

#a textbox
axbox_a = plt.axes([xstart+xstep, 0.125, 0.05, 0.06])
text_box_a = TextBox(axbox_a, r'$a$', initial = str(a), label_pad = 0.05)

#Ai textbox
axbox_Ai = plt.axes([xstart+xstep, 0.025, 0.05, 0.06])
text_box_Ai = TextBox(axbox_Ai, r'[A]$_i$', initial = str(Ai), label_pad = 0.05)

#b textbox
axbox_b = plt.axes([xstart+2*xstep, 0.125, 0.05, 0.06])
text_box_b = TextBox(axbox_b, r'$b$', initial = str(b), label_pad = 0.05)

#B textbox
axbox_Bi = plt.axes([xstart+2*xstep, 0.025, 0.05, 0.06])
text_box_Bi = TextBox(axbox_Bi, r'[B]$_i$', initial = str(Bi), label_pad = 0.05)

#Conc step textbox
axbox_step = plt.axes([xstart+3.25*xstep, 0.125, 0.05, 0.06])
text_box_step = TextBox(axbox_step, r'Concentration step (M)', initial = str(step), label_pad = 0.05)

#button
ax_button = plt.axes([xstart+3*xstep, 0.025, 0.1, 0.05])
btn = Button(ax_button, 'Switch x-axis', color='cyan', hovercolor='red')

# text
ax_text = fig.add_axes([0.48, 0.92, 0.15, 0.05])
ax_text.axis('off')
ax_text.text(0, 0.0, r"$a$A $\longrightarrow b$B", fontsize = 16)

text_box_Keq.on_submit(submit)
text_box_T.on_submit(submit)
text_box_a.on_submit(submit)
text_box_b.on_submit(submit)
text_box_Ai.on_submit(submit)
text_box_Bi.on_submit(submit)
text_box_step.on_submit(submit)
btn.on_clicked(button)

plt.show()
