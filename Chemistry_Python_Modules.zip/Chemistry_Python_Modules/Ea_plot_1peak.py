#import numpy as np #import np Package
import numpy as np
import matplotlib.pyplot as plt #import matplotlib Package
from matplotlib.widgets import Button, Slider, TextBox

Ea = 100 #initial activation energy
Ereact = 200 #initial energy of reactants (kJ/mol)
Eprod = 0 #intitial energy of products (kJ/mol)
Emax = 500 # Maximum slider values for energies
w = 250 #width parameter for Gaussian function; big makes it wide, small makes it narrow
coord = np.linspace(0,100,1001) #gives reaction coordinate as a % of reaction progress

# The function to be called anytime a slider's value changes
def update(event):
    global Ea, Ereact, Eprod, w, Emax
    try:
        Ea = Ea_slider.val
        Ereact = Ereact_slider.val
        Eprod = Eprod_slider.val
        w = w_slider.val
        Emax = int(text_box.text)
        if Emax < Ea or Emax < Ereact or Emax < Eprod:
            raise ValueError
        Ea_slider.ax.set_xlim(0, Emax)
        Ea_slider.valmax = Emax
        Ereact_slider.ax.set_xlim(0, Emax)
        Ereact_slider.valmax = Emax
        Eprod_slider.ax.set_xlim(0, Emax)
        Eprod_slider.valmax = Emax 
        if Ereact+Ea < Eprod: # activation energy needs to be enough to reach the products!
            Ea = Eprod-Ereact
            Ea_slider.set_val(Eprod-Ereact)
        curve = data(Ereact, Eprod, Ea, w)
        if max(curve) != 0:
            ax.set_ylim([-0.05*max(curve), 1.05*max(curve)])
        line.set_ydata(curve)
    except ValueError:
        print("The maximum energy for sliders must be higher than the current largest value used on the sliders.")

def data(Ereact, Eprod, Ea, w):
    Gaussian1 = Ea*np.exp(-(coord-50)**2/w)+Ereact #Gaussian for the first part of the curve
    Gaussian2 = (Ea+Ereact-Eprod)*np.exp(-(coord-50)**2/w) + Eprod #Gaussian for the second part of the curve
    curve = Gaussian1 #starts off by making the curve the whole of the first Gaussian
    index = np.where(coord == 50)[0][0] #finds where the peak is
    curve[index::] = Gaussian2[index::] #makes the last half of the curve the second Gaussian
    return curve

#Initializing data
coord = np.linspace(0,100,1001) #gives reaction coordinate as a %
curve = data(Ereact, Eprod, Ea, w)

#Initial plot
fig, ax = plt.subplots(figsize=(10,8))
fig.subplots_adjust(bottom=0.3)
line, = ax.plot(coord,curve,color='b', linewidth = 2, label='Arrhenius Curve')
#matplotlib.rcParams.update({'font.size': 16})
ax.set_xlabel('Reaction progress (%)')
ax.set_ylabel('Energy (kJ/mol)')
ax.set_xlim([0, 100])
if max(curve) != 0:
    ax.set_ylim([-0.05*max(curve), 1.05*max(curve)])
plt.grid()

#Slider for the Ea values
Ea_ax = fig.add_axes([0.15,0.2,0.5,0.05]) #written in terms of fractions of the window; x start, y start, x width, y width
Ea_slider = Slider(
    Ea_ax,
    label=r'$E_a$ (kJ/mol)',
    valmin=0,
    valmax=Emax,
    valstep = 1,
    valinit=Ea,
    facecolor = 'b',
    track_color = 'b')

Ereact_ax = fig.add_axes([0.15,0.15,0.5,0.05]) #written in terms of fractions of the window; x start, y start, x width, y width
Ereact_slider = Slider(
    Ereact_ax,
    label=r'$E_{react}$ (kJ/mol)',
    valmin=0,
    valmax=Emax,
    valstep = 1,
    valinit=Ereact,
    facecolor = 'b',
    track_color = 'b')

Eprod_ax = fig.add_axes([0.15,0.1,0.5,0.05]) #written in terms of fractions of the window; x start, y start, x width, y width
Eprod_slider = Slider(
    Eprod_ax,
    label=r'$E_{prod}$ (kJ/mol)',
    valmin=0,
    valmax=Emax,
    valstep = 1,
    valinit=Eprod,
    facecolor = 'b',
    track_color = 'b')

w_ax = fig.add_axes([0.15,0.05,0.5,0.05]) #written in terms of fractions of the window; x start, y start, x width, y width
w_slider = Slider(
    w_ax,
    label=r'$w$',
    valmin=1,
    valmax=500,
    valstep = 1,
    valinit=w,
    facecolor = 'b',
    track_color = 'b')

axbox = plt.axes([0.8,0.125,0.1,0.06])
text_box = TextBox(axbox, r'Slider Max', initial = Emax, label_pad = 0.05)

# register the update function with each slider
Ea_slider.on_changed(update)
Ereact_slider.on_changed(update)
Eprod_slider.on_changed(update)
w_slider.on_changed(update)
text_box.on_submit(update)

plt.show()
