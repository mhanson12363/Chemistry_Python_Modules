import numpy as np #import Numpy Package
import matplotlib.pyplot as plt #import matplotlib Package
from matplotlib.widgets import Button, Slider, TextBox

pka1 = 3.0 #initial random values
pka2 = 8.0
V_a = 10 #volume of acid being titrated (mL)
C_a = 0.1 #concentration of acid (M)
C_b = 0.1 #concentration of base (M)

# The function to be called anytime a slider's value changes
def update(event):
    global pka1, pka2, V_a, C_a, C_b
    try:
        pka1 = pka1_slider.val
        pka2 = pka2_slider.val
        V_a = float(txtBox1.text)
        C_a = float(txtBox2.text)
        C_b = float(txtBox3.text)
        if V_a <= 0 or C_a <= 0 or C_b <= 0:
            raise ValueError
        if pka1_slider.val > pka2_slider.val:
            pka2_slider.set_val(pka1_slider.val)
        V_b = data(pka1_slider.val, pka2_slider.val, V_a, C_a, C_b)
        line.set_xdata(V_b)
        ax.set_xlim([0, 3*V_a*C_a/C_b])
    except ValueError:
        print("Please use valid positive values for the volume of acid and the concentration of acid and base.")

def data(pka1, pka2, V_a, C_a, C_b):
    pH = pH = np.linspace(0,14+np.log10(C_b),200) # range is set so it doesn't blow up!
    H = 10**(-pH) #concentration of H+ (M)
    OH = (10**(-14))/H #concentration of OH- (M)
    Ka1=10**(-pka1) #first proton Ka value
    Ka2=10**(-pka2) #second proton Ka value
    d = H**2 + Ka1*H + Ka1*Ka2 #denominator of proportions
    A_HA = (H*Ka1)/d #proportion in form HA-
    A_A = (Ka1*Ka2)/d #proportion in form A-2
    phi_n = A_HA + 2*A_A - ((H - OH)/C_a) #numerator of Harris' formula
    phi_d = 1+ ((H - OH)/C_b) #denominator of Harris' formula
    phi = phi_n / phi_d # ratio from Harris' formula
    V_b = (phi*C_a*V_a)/C_b #Volume of base added that matches the pH based on Harris' formula
    return V_b

#Initializing data
pH = np.linspace(0,13,200) #using the pH values to figure out the volume added; range is set so it doesn't blow up!
H = 10**(-pH) #concentration of H+ (M)
OH = (10**(-14))/H #concentration of OH- (M)
V_b = data(pka1, pka2, V_a, C_a, C_b)

#Initial plot
fig, ax = plt.subplots(figsize=(10,6))
fig.subplots_adjust(bottom=0.3)
line, = ax.plot(V_b,pH,color='b', linewidth = 2, label='Titration Curve')
ax.set_xlabel(r'$V$ base added (mL)')
ax.set_ylabel('pH')
ax.set_xlim([0, 3*V_a*C_a/C_b])
plt.grid()

sliderax1 = fig.add_axes([0.1,0.1,0.6,0.05]) #written in terms of fractions of the window; x start, y start, x width, y width
pka1_slider = Slider(
    sliderax1,
    label=r'p$K_{a1}$',
    valmin=0,
    valmax=13,
    valinit=3)

sliderax2 = fig.add_axes([0.1,0.05,0.6,0.05])
pka2_slider = Slider(
    sliderax2,
    label=r'p$K_{a2}$',
    valmin=0,
    valmax=13,
    valinit=8)

#Textbox for volume of acid'
graphBox1 = fig.add_axes([0.85, 0.125, 0.1, 0.05])
txtBox1 = TextBox(graphBox1, '$V$ acid (mL) ', initial = 10.0)
txtBox1.on_submit(update)

#Textbox for concentration of acid'
graphBox2 = fig.add_axes([0.85, 0.075, 0.1, 0.05])
txtBox2 = TextBox(graphBox2, '[Acid] (M) ', initial = 0.1)
txtBox2.on_submit(update)

#Textbox for concentration of base'
graphBox3 = fig.add_axes([0.85, 0.025, 0.1, 0.05])
txtBox3 = TextBox(graphBox3, '[Base] (M) ', initial = 0.1)
txtBox3.on_submit(update)

# register the update function with each slider
pka1_slider.on_changed(update)
pka2_slider.on_changed(update)

plt.show()
