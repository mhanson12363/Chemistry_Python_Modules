import numpy as np
from numpy.random import rand
import scipy.optimize as opt
import matplotlib.pyplot as plt
import warnings #used to make a specific message not appear
warnings.simplefilter("ignore")

n = -1 # initializing with a stupid value
while n < 0:
    try:
        n = int(input("How many points should be plotted? "))
        if n < 0 :
            raise ValueError
        if n == 0:
            break
    except ValueError:
        n = -1
        print("You must enter an integer or enter 0 to terminate the program.")

if n != 0:
    #sphere coordinates

    T = np.linspace(0,np.pi,25)
    P = np.linspace(0,2*np.pi,50)
    T,P = np.meshgrid(T,P)
    X = np.sin(T)*np.cos(P)
    Y = np.sin(T)*np.sin(P)
    Z = np.cos(T)

    # setting up guess for points on the sphere

    guess = np.zeros(3*n) #0s to start
    for i in range(n):
        guess[3*i:3*i+3] = [rand()-0.5,rand()-0.5,rand()-0.5] #random points centered about the origin
        guess[3*i:3*i+3] = guess[3*i:3*i+3]/np.linalg.norm(guess[3*i:3*i+3]) #normalizes vector to fall on unit sphere
    guess[0:3] = [0,0,1] #setting one point to be consistent
    guesses=np.zeros((n,3)) #makes them easier to plot
    for i in range(n):
        guesses[i,0:3] = guess[3*i:3*i+3]
    #print(guesses)

    #function to optimize based on distances between points

    def cost_function(coords):
        distances = np.zeros(int(n*(n-1)/2))
        counter = -1
        for i in range(n):
            for j in range(n):
                if i > j:
                    counter += 1
                    distances[counter] = np.sqrt(np.sum((coords[3*i:3*i+3]-coords[3*j:3*j+3])**2)) #distances between pairs of points
        return -np.sum(distances) #maximizes distances

    # function to constrain all points to the unit sphere

    def fix_distances(coords):
        ds = np.zeros(n)
        for i in range(n):
            ds[i] = np.sqrt(np.dot(coords[3*i:3*i+3],coords[3*i:3*i+3]))
        return ds - np.ones(n)  #tries to make sure all points have distance 1 so they are on the unit sphere

    # Function to constrain one point to be consistent and one to point a certain way

    def fix_point(coords):
        return coords[0:3]-[0,0,1]  #ensures that one point is fixed on top of the sphere

    def fix_orient(coords):
        return coords[3]-0  #ensures that one point has x coordinate 0 to fix orientation

    # running the optimization

    if n == 2: #different constraint for 2 points because it breaks???
        Constraints = [{'type': 'eq', 'fun': fix_distances},
                       {'type': 'eq', 'fun': fix_point}]

    if n > 2:
        Constraints = [{'type': 'eq', 'fun': fix_distances},
                       {'type': 'eq', 'fun': fix_point},
                       {'type': 'eq', 'fun': fix_orient}]
    result = opt.minimize(cost_function, guess, method='trust-constr', constraints=Constraints, options={'maxiter': 10000},tol=1e-5)
    results = result.x
    print("Optimization converged: " + str(result.success))
    print("Number of iterations required: " + str(result.niter))
    if result.success == False:
        print(result)

    # recasting as a set of coordinates
    coords = np.zeros((n,3))
    for i in range(n):
        for j in range(3):
            coords[i,j] = round(results[3*i+j],3)
    print("Coordinates of optimized points:")
    print(coords)

    angles = np.zeros((int(n*(n-1)/2),3))
    counter = -1
    for i in range(n):
        for j in range(n):
            if i > j:
                counter += 1
                angles[counter,0:2] = [i+1,j+1]
                angles[counter,2] = round(np.arccos(np.dot(coords[i],coords[j]))*360/(2*np.pi),1)
    print("Angles between points:")
    print(angles)

    # Plotting stuff

    fig = plt.figure(figsize=(10, 8))
    ax = fig.add_subplot(projection='3d')
    for i in range(n):
        ax.plot([0,coords[i,0]],[0,coords[i,1]],[0,coords[i,2]],c='k',linewidth=2,linestyle='--')
    ax.scatter(coords[:,0],coords[:,1],coords[:,2], c='k', marker='o',s=100)
    ax.scatter(0,0,0, c='k', marker='o',s=100)
    #ax.scatter(guesses[:,0],guesses[:,1],guesses[:,2], c='r', marker='x')
    #surf = ax.plot_surface(X, Y, Z, alpha=0.3, color='b')
    surf = ax.plot_wireframe(X, Y, Z, alpha=0.3, color='b')
    ax.set_xlabel(r'$x$ axis')
    ax.set_ylabel(r'$y$ axis')
    ax.set_zlabel(r'$z$ axis')
    ax.set_xlim([-1,1])
    ax.set_ylim([-1,1])
    ax.set_zlim([-1,1])
    plt.show()
