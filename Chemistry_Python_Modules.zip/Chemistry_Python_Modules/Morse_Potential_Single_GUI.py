import numpy as np
import matplotlib.pyplot as plt
from matplotlib.widgets import Slider, Button

def morse_potential(r, De, a, re):
    return De*(1 - np.exp(-a*(r - re)))**2

De = 5.0   # eV
a = 2.0   # Angstrom^-1
re = 1.0  # Angstrom
r = np.linspace(re-1/a*np.log(1+np.sqrt(2)), re-1/a*np.log(1-np.sqrt(0.999)), 201)  # in Angstroms; r chosen so V goes from 2*De to 99.9% of De
flag = True # used to set the rescale mode for the button

fig, ax = plt.subplots(figsize=(10,6))
plt.subplots_adjust(bottom=0.3)
line, = ax.plot(r, morse_potential(r, De, a, re), lw=2, color='blue')
ax.set_xlabel(r"Bond length $r$ (Angstrom)")
ax.set_ylabel(r"Potential Energy $V(r)$ (eV)")
#ax.set_title("Morse Potential: Bond Energy Curve")
ax.set_xlim([re-1/a*np.log(1+np.sqrt(2)), re-1/a*np.log(1-np.sqrt(0.999))]) 
ax.set_ylim([0, 2*De])
ax.grid(True)

ax_De = plt.axes([0.2, 0.15, 0.5, 0.03])
ax_a  = plt.axes([0.2, 0.1, 0.5, 0.03])
ax_re = plt.axes([0.2, 0.05, 0.5, 0.03])

slider_De = Slider(ax_De, r"$D_e$ (eV)", 1.0, 12.0, valinit=De, valstep=0.01)
slider_a  = Slider(ax_a, r"a (Angstrom$^{-1}$)", 1.0, 4.0, valinit=a, valstep=0.01)
slider_re = Slider(ax_re, r"$r_e$ (Angstrom)", 0.1, 5, valinit=re, valstep=0.01)

def update(val):
    global r, De, a, re
    De = slider_De.val
    a = slider_a.val
    re = slider_re.val
    if flag: # only updates the x axis data if the autoscale mode is on
        r = np.linspace(re-1/a*np.log(1+np.sqrt(2)), re-1/a*np.log(1-np.sqrt(0.999)), 201)  # in Angstroms
        line.set_xdata(r)
    line.set_ydata(morse_potential(r, De, a, re))
    if flag: # only updates the x axis ranges if autoscale mode is on
        ax.set_xlim([re-1/a*np.log(1+np.sqrt(2)), re-1/a*np.log(1-np.sqrt(0.999))])
        ax.set_ylim([0, 2*De])

def rescale(event): # controls the button
    global flag
    De = slider_De.val
    a = slider_a.val
    re = slider_re.val
    counter = 0
    if counter == 0 and flag == True:
        flag = False
        counter += 1
    if counter == 0 and flag == False:
        flag = True
        counter += 1
    if flag == True:
        ax_text.clear()
        ax_text.axis('off')
        ax_text.text(0.1, 0.0, "Rescale \n Mode") 
    if flag == False:
        ax_text.clear()
        ax_text.axis('off')
        ax_text.text(0.1, 0.0, "Fixed Scale \n Mode")
    fig.canvas.draw_idle()

ax_button = fig.add_axes([0.8, 0.1, 0.15, 0.1])
rescale_button = Button(ax_button, "Scaling Mode \n Button", color='cyan', hovercolor='red')

ax_text = fig.add_axes([0.82, 0.05, 0.15, 0.1])
ax_text.axis('off')
ax_text.text(0.15, 0.0, "Rescale \n Mode")

slider_De.on_changed(update)
slider_a.on_changed(update)
slider_re.on_changed(update)
rescale_button.on_clicked(rescale)

plt.show()
