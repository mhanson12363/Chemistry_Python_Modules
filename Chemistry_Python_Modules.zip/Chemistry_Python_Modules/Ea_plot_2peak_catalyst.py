import numpy as np #import np Package
import matplotlib.pyplot as plt #import matplotlib Package
from matplotlib.widgets import Button, Slider, TextBox

Ea1 = 100 #initial activation energy for 1st step
Ea2 = 150 #initial activation energy for 2nd step
Einter = 100 #energy of the intermediate species
Ereact = 200 #Relative energy of reactant (kJ/mol)
Eprod = 0 #Relative energy of product (kJ/mol)
Ea_uncat = 200 #initial uncatalyzed activation energy
Emax = 500 
w = 60 #width parameter for Gaussian function

# The function to be called anytime a slider's value changes
def update(val):
    global Ea1, Ea2, Einter, Ereact, Eprod, w, Ea_uncat, Emax
    try:
        Ea1 = Ea1_slider.val
        Ea2 = Ea2_slider.val
        Ea_uncat = Ea_uncat_slider.val
        Einter = Einter_slider.val
        Ereact = Ereact_slider.val
        Eprod = Eprod_slider.val
        w = w_slider.val
        Emax = int(text_box.text)
        if Emax < Ea1 or Emax < Ea2 or Emax < Ereact or Emax < Eprod or Emax < Ea_uncat:
            raise ValueError
        Ea1_slider.ax.set_xlim(0, Emax)
        Ea1_slider.valmax = Emax
        Ea2_slider.ax.set_xlim(0, Emax)
        Ea2_slider.valmax = Emax
        Ea_uncat_slider.ax.set_xlim(0, Emax)
        Ea_uncat_slider.valmax = Emax
        Einter_slider.ax.set_xlim(0, Emax)
        Einter_slider.valmax = Emax
        Ereact_slider.ax.set_xlim(0, Emax)
        Ereact_slider.valmax = Emax
        Eprod_slider.ax.set_xlim(0, Emax)
        Eprod_slider.valmax = Emax 
        if Einter > Ea1+Ereact:
            Einter = Ea1+Ereact
            Einter_slider.set_val(Ea1+Ereact)
        if Einter+Ea2 < Eprod: # activation energy needs to be enough to reach the products!
            Ea2 = Eprod-Einter
            Ea2_slider.set_val(Eprod-Einter)
        if Ea_uncat < max(Ea1, Ea2):
            Ea_uncat = max(Ea1, Ea2)
            Ea_uncat_slider.set_val(max(Ea1, Ea2))
        curve, curve_uncat = data(Ereact, Eprod, Ea1, Ea2, Ea_uncat, Einter, w)
        if max(curve) != 0:
            ax.set_ylim([-0.05*max(max(curve),max(curve_uncat)), 1.05*max(max(curve),max(curve_uncat))])
        line.set_ydata(curve)
        line2.set_ydata(curve_uncat)
    except ValueError:
        print("The maximum energy for sliders must be higher than the current largest value used on the sliders.")

def data(Ereact, Eprod, Ea1, Ea2, Ea_uncat, Einter, w):
    # Makes the curve for the catalyzed process
    Gaussian1 = Ea1*np.exp(-(coord-33)**2/w)+Ereact #Gaussian for the first part of the curve
    Gaussian2 = (Ea1+Ereact-Einter)*np.exp(-(coord-33)**2/w) #first Gaussian for the second part of the curve
    Gaussian3 = Ea2*np.exp(-(coord-67)**2/w)+Einter #second Gaussian for the second part of the curve
    Gaussian4 = (Ea2+Einter-Eprod)*np.exp(-(coord-67)**2/w)+Eprod #Gaussian for the final part of the curve
    peak1_index = np.where(coord == 33)[0][0] #finds peak of first Gaussian
    peak2_index = np.where(coord == 67)[0][0] #finds peak of last Gaussian
    curve = np.zeros(len(coord))
    curve[0:peak1_index] = Gaussian1[0:peak1_index] #starts off by making the first bit of the curve
    curve[peak1_index:peak2_index] = Gaussian2[peak1_index:peak2_index] + Gaussian3[peak1_index:peak2_index] #makes the final piece of the curve the final Gaussian
    curve[peak2_index::] = Gaussian4[peak2_index::] #makes the final piece of the curve the final Gaussian
    # Makes the curve for the uncatalyzed process
    index = np.where(coord == 50)[0][0] #finds where the peak is
    Gaussian5 = Ea_uncat*np.exp(-(coord-50)**2/w)+Ereact #Gaussian for the first part of the curve
    Gaussian6 = (Ea_uncat+Ereact-Eprod)*np.exp(-(coord-50)**2/w) + Eprod #Gaussian for the second part of the curve
    curve_uncat = Gaussian5 #starts off by making the curve the whole of the first Gaussian
    curve_uncat[index::] = Gaussian6[index::] #makes the last half of the curve the second Gaussian
    return curve, curve_uncat

#Initializing data
coord = np.linspace(0,100,1001) #gives reaction coordinate as a %
curve, curve_uncat = data(Ereact, Eprod, Ea1, Ea2, Ea_uncat, Einter, w)

#Initial plot
fig, ax = plt.subplots(figsize=(12,8))
fig.subplots_adjust(bottom=0.3)
line, = ax.plot(coord,curve,color='b', linewidth = 2, label='Catalyzed Reaction')
line2, = ax.plot(coord,curve_uncat,color='r', linewidth = 2, linestyle = '--', label='Uncatalyzed Reaction')
#matplotlib.rcParams.update({'font.size': 16})
ax.set_xlabel('Reaction progress (%)')
ax.set_ylabel('Energy (kJ/mol)')
ax.set_xlim([0, 100])
if max(curve_uncat) != 0:
    ax.set_ylim([-0.05*max(max(curve),max(curve_uncat)), 1.05*max(max(curve),max(curve_uncat))])
#plt.legend() #hidden when making plots for tests
plt.grid()
plt.legend()

#Sliders for the Ea values
sliderax = fig.add_axes([0.15,0.15,0.3,0.05]) #written in terms of fractions of the window; x start, y start, x width, y width
Ea1_slider = Slider(
    sliderax,
    label=r'$E_{a1}$ (kJ/mol)',
    valmin=0,
    valmax=Emax,
    valinit=Ea1,
    valstep = 1,
    facecolor = 'b',
    track_color = 'b')

sliderax2 = fig.add_axes([0.15,0.1,0.3,0.05]) #written in terms of fractions of the window; x start, y start, x width, y width
Ea2_slider = Slider(
    sliderax2,
    label=r'$E_{a2}$ (kJ/mol)',
    valmin=0,
    valmax=Emax,
    valinit=Ea2,
    valstep = 1,
    facecolor = 'b',
    track_color = 'b')

w_ax = fig.add_axes([0.15,0.05,0.3,0.05]) #written in terms of fractions of the window; x start, y start, x width, y width
w_slider = Slider(
    w_ax,
    label=r'$w$',
    valmin=1,
    valmax=100,
    valstep = 1,
    valinit=w,
    facecolor = 'b',
    track_color = 'b')

sliderax4 = fig.add_axes([0.15,0.2,0.3,0.05]) #written in terms of fractions of the window; x start, y start, x width, y width
Ea_uncat_slider = Slider(
    sliderax4,
    label=r'$E_a$ Uncatalyzed (kJ/mol)',
    valmin=0,
    valmax=Emax,
    valinit=Ea_uncat,
    valstep = 1,
    facecolor = 'b',
    track_color = 'b')

sliderax3 = fig.add_axes([0.6,0.2,0.3,0.05]) #written in terms of fractions of the window; x start, y start, x width, y width
Einter_slider = Slider(
    sliderax3,
    label=r'$E_{inter}$ (kJ/mol)',
    valmin=0,
    valmax=Emax,
    valinit=Einter,
    valstep = 1,
    facecolor = 'b',
    track_color = 'b')

Ereact_ax = fig.add_axes([0.6,0.15,0.3,0.05]) #written in terms of fractions of the window; x start, y start, x width, y width
Ereact_slider = Slider(
    Ereact_ax,
    label=r'$E_{react}$ (kJ/mol)',
    valmin=0,
    valmax=Emax,
    valstep = 1,
    valinit=Ereact,
    facecolor = 'b',
    track_color = 'b')

Eprod_ax = fig.add_axes([0.6,0.1,0.3,0.05]) #written in terms of fractions of the window; x start, y start, x width, y width
Eprod_slider = Slider(
    Eprod_ax,
    label=r'$E_{prod}$ (kJ/mol)',
    valmin=0,
    valmax=Emax,
    valstep = 1,
    valinit=Eprod,
    facecolor = 'b',
    track_color = 'b')

axbox = plt.axes([0.6,0.05,0.1,0.05])
text_box = TextBox(axbox, r'Slider Max', initial = Emax, label_pad = 0.05)

# register the update function with each slider
Ea1_slider.on_changed(update)
Ea2_slider.on_changed(update)
Einter_slider.on_changed(update)
Ea_uncat_slider.on_changed(update)
Ereact_slider.on_changed(update)
Eprod_slider.on_changed(update)
w_slider.on_changed(update)
text_box.on_submit(update)

plt.show()
